"""Discover notice PDFs only after checking the official detail identity."""

import hashlib
import re
from email.message import Message
from time import monotonic
from types import SimpleNamespace
from urllib.parse import parse_qs, urlencode, urljoin, urlsplit

from selectolax.parser import HTMLParser

from apps.local_content.http import OfficialSourceError, _canonicalize_path, _decode_html
from apps.local_content.sources.applyhome import (
    _require_public_detail_identity as check_applyhome_identity,
)
from apps.local_content.sources.lh import _require_public_detail_identity as check_lh_identity
from wisdome_writer.infrastructure.http_safety import (
    HttpSafetyError,
    safe_get,
    validated_logical_url,
)

MAX_PDF_BYTES = 16 * 1024 * 1024
MAX_DOCUMENTS = 3
HOSTS = {"www.applyhome.co.kr", "static.applyhome.co.kr", "apply.lh.or.kr"}
AH_DETAILS = {
    "/ai/aia/selectAPTLttotPblancDetail.do",
    "/ai/aia/selectAPTLttotPblancDetailView.do",
    "/ai/aia/selectAPTRemndrLttotPblancDetailView.do",
}
LH_DETAIL = "/lhapply/apply/wt/wrtanc/selectWrtancInfo.do"


def _url(url):
    parts = urlsplit(url)
    if (
        parts.scheme != "https"
        or parts.hostname not in HOSTS
        or parts.port not in (None, 443)
        or parts.username is not None
        or parts.password is not None
        or parts.fragment
    ):
        raise ValueError("unapproved_document_url")
    try:
        path = _canonicalize_path(parts.path)
    except OfficialSourceError:
        raise ValueError("ambiguous_document_path") from None
    if path != parts.path:
        raise ValueError("ambiguous_document_path")
    values = parse_qs(parts.query, keep_blank_values=True, strict_parsing=True)
    if any(len(v) != 1 or not v[0] for v in values.values()):
        raise ValueError("ambiguous_document_query")
    return parts, {k: v[0] for k, v in values.items()}


def _identity(raw):
    source, external = raw["source_key"], raw["external_id"]
    if source == "applyhome":
        match = re.fullmatch(r"applyhome:(apt|remaining):(\d{1,20}):(\d{1,20})", external)
        if not match:
            raise ValueError("unsupported_notice_identity")
        return SimpleNamespace(house_manage_no=match[2], pblanc_no=match[3], title=raw["title"])
    if source == "lh":
        match = re.fullmatch(r"lh:(\d{2}):(\d{10,20}):(\d{2}):(\d{2})", external)
        if not match:
            raise ValueError("unsupported_notice_identity")
        return SimpleNamespace(
            ccr=match[1], pan_id=match[2], upp=match[3], ais=match[4], title=raw["title"]
        )
    raise ValueError("unsupported_document_source")


def validate_detail_url(raw, url):
    identity = _identity(raw)
    parts, query = _url(url)
    if raw["source_key"] == "applyhome":
        if (
            parts.hostname != "www.applyhome.co.kr"
            or parts.path not in AH_DETAILS
            or query.get("houseManageNo") != identity.house_manage_no
            or query.get("pblancNo") != identity.pblanc_no
            or set(query) - {"houseManageNo", "pblancNo", "houseSecd"}
        ):
            raise ValueError("notice_url_identity_mismatch")
    elif (
        parts.hostname != "apply.lh.or.kr"
        or parts.path != LH_DETAIL
        or query.get("panId") != identity.pan_id
        or query.get("ccrCnntSysDsCd") != identity.ccr
        or query.get("uppAisTpCd") != identity.upp
        or query.get("aisTpCd") != identity.ais
        or set(query) - {"panId", "ccrCnntSysDsCd", "uppAisTpCd", "aisTpCd", "mi"}
    ):
        raise ValueError("notice_url_identity_mismatch")


def validate_pdf_url(raw, url):
    identity = _identity(raw)
    parts, query = _url(url)
    if raw["source_key"] == "applyhome":
        if (
            parts.hostname not in {"www.applyhome.co.kr", "static.applyhome.co.kr"}
            or parts.path != "/ai/aia/getAtchmnfl.do"
            or set(query) != {"houseManageNo", "pblancNo", "atchmnflSeqNo", "atchmnflSn"}
            or query["houseManageNo"] != identity.house_manage_no
            or query["pblancNo"] != identity.pblanc_no
            or not all(re.fullmatch(r"\d{1,20}", v) for v in query.values())
        ):
            raise ValueError("pdf_url_identity_mismatch")
    elif (
        parts.hostname != "apply.lh.or.kr"
        or parts.path != "/lhapply/lhFile.do"
        or set(query) != {"fileid"}
        or not re.fullmatch(r"\d{1,20}", query["fileid"])
    ):
        raise ValueError("pdf_url_identity_mismatch")


def discover_pdfs(raw, html, observed_url):
    validate_detail_url(raw, observed_url)
    document, identity = HTMLParser(html), _identity(raw)
    if raw["source_key"] == "applyhome":
        check_applyhome_identity(document, identity, observed_detail_url=observed_url)
    else:
        # Attachment discovery is independent of schedule table parsing.
        check_lh_identity(document, identity)
    refs = []
    for link in document.css("a"):
        label = " ".join(link.text(separator=" ").split())
        if raw["source_key"] == "applyhome":
            if not re.search(r"공고문|모집\s*공고", label):
                continue
            href = link.attributes.get("href", "")
            if "getAtchmnfl.do" not in href:
                continue
            url = urljoin(observed_url, href)
        else:
            if not _notice_container(link):
                continue
            if not re.search(r"\.pdf\s*$", label, re.I) or not re.search(r"공고|모집", label):
                continue
            href = link.attributes.get("href", "")
            match = re.fullmatch(r"\s*javascript:fileDownLoad\(['\"](\d{1,20})['\"]\);?\s*", href)
            if not match:
                continue
            url = "https://apply.lh.or.kr/lhapply/lhFile.do?" + urlencode({"fileid": match[1]})
        validate_pdf_url(raw, url)
        if not any(ref["url"] == url for ref in refs):
            refs.append({"url": url, "label": label})
    if len(refs) > MAX_DOCUMENTS:
        raise ValueError("too_many_notice_pdfs")
    return refs


def _notice_container(link):
    """Only an exact 공고문 dl/table row; not the separate 다운로드 group."""
    node = link.parent
    for _ in range(10):
        if node is None or node.tag in {"body", "html"}:
            return False
        if node.tag in {"dl", "tr"}:
            label = node.css_first("dt" if node.tag == "dl" else "th")
            if label is not None:
                return " ".join(label.text(separator=" ").split()) == "공고문"
        node = node.parent
    return False


def download_notice(raw, *, transport=None, seconds=90, max_requests=12):
    validate_detail_url(raw, raw["canonical_url"])
    deadline, requests = monotonic() + min(seconds, 90), 0

    def claim():
        nonlocal requests
        requests += 1
        if requests > max_requests or monotonic() >= deadline:
            raise ValueError("document_request_budget_exhausted")

    def get(url, *, pdf=False, expected=None):
        def validate(candidate):
            (validate_pdf_url if pdf else validate_detail_url)(raw, candidate)
            if pdf and candidate != expected:
                raise ValueError("pdf_redirect_identity_changed")

        remaining = deadline - monotonic()
        if remaining <= 0:
            raise ValueError("document_request_budget_exhausted")
        response = safe_get(
            url,
            allowed_hosts=HOSTS,
            https_only=True,
            max_bytes=MAX_PDF_BYTES if pdf else 5 * 1024 * 1024,
            timeout=min(remaining, 30),
            max_elapsed_seconds=min(remaining, 30),
            headers={"Accept-Encoding": "identity"},
            before_request=claim,
            url_validator=validate,
            allowed_content_types={"application/pdf", "application/octet-stream"}
            if pdf
            else {"text/html", "application/xhtml+xml"},
            transport=transport,
        )
        if response.status_code != 200:
            raise ValueError("document_http_status_" + str(response.status_code))
        return response

    try:
        detail = get(raw["canonical_url"])
        html = _decode_html(
            detail.content, detail.headers.get("content-type", ""), raw["canonical_url"]
        )
        refs = discover_pdfs(raw, html, validated_logical_url(detail))
        documents = []
        for ref in refs:
            response = get(ref["url"], pdf=True, expected=ref["url"])
            header = Message()
            header["Content-Disposition"] = response.headers.get("content-disposition", "")
            filename = header.get_filename() or ""
            mime = response.headers.get("content-type", "").split(";")[0].lower().strip()
            if (
                not response.content.startswith(b"%PDF-")
                or len(response.content) > MAX_PDF_BYTES
                or (mime == "application/octet-stream" and not filename.lower().endswith(".pdf"))
            ):
                raise ValueError("invalid_official_pdf")
            filename = filename.rsplit("/", 1)[-1].rsplit("\\", 1)[-1][:240]
            documents.append(
                {
                    **ref,
                    "name": filename or ref["label"],
                    "data": response.content,
                    "detail_sha256": hashlib.sha256(detail.content).hexdigest(),
                }
            )
        return documents
    except (HttpSafetyError, OfficialSourceError) as exc:
        raise ValueError("document_network_rejected_" + type(exc).__name__) from None
