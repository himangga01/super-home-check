"""Private immutable PDF versions and persistent per-notice attempt cooldowns."""

import hashlib
import json
import os
import re
import stat
import tempfile
import uuid
from contextlib import contextmanager
from datetime import UTC, datetime, timedelta
from pathlib import Path

from apps.policy_funding.contracts import content_hash

from .sections import SECTION_VERSION, parse_sections
from .sources import MAX_PDF_BYTES, validate_pdf_url

PARSER_VERSION = "housing-official-pdf-v1"
HEX = re.compile(r"[a-f0-9]{64}")
JSON_LIMIT = 12 * 1024 * 1024


def document_root():
    from django.conf import settings

    return Path(
        getattr(
            settings,
            "HOUSING_DOCUMENT_ROOT",
            Path(settings.LOCAL_ARTICLE_ROOT).parent / "housing-documents",
        )
    ).absolute()


def _guard(path, *, directory=None):
    path = Path(path).absolute()
    for item in reversed([path, *path.parents]):
        try:
            info = item.lstat()
        except FileNotFoundError:
            continue
        if stat.S_ISLNK(info.st_mode) or getattr(info, "st_file_attributes", 0) & 0x400:
            raise ValueError("document_path_link_rejected")
        if item != path and not stat.S_ISDIR(info.st_mode):
            raise ValueError("document_parent_not_directory")
        if item == path:
            if directory is True and not stat.S_ISDIR(info.st_mode):
                raise ValueError("document_path_not_directory")
            if directory is False and (not stat.S_ISREG(info.st_mode) or info.st_nlink != 1):
                raise ValueError("document_file_not_regular")
    return path


def _read(path, limit):
    path = _guard(path, directory=False)
    before = path.stat()
    with path.open("rb") as stream:
        opened = os.fstat(stream.fileno())
        if (opened.st_dev, opened.st_ino) != (before.st_dev, before.st_ino) or opened.st_nlink != 1:
            raise ValueError("document_file_changed")
        payload = stream.read(limit + 1)
        after = os.fstat(stream.fileno())
    if len(payload) > limit or (after.st_size, after.st_mtime_ns) != (
        before.st_size,
        before.st_mtime_ns,
    ):
        raise ValueError("document_file_size_or_change")
    _guard(path, directory=False)
    return payload


def _json(payload):
    def pairs(items):
        result = {}
        for key, value in items:
            if key in result:
                raise ValueError("duplicate_document_key")
            result[key] = value
        return result

    return json.loads(
        payload.decode("utf-8"),
        object_pairs_hook=pairs,
        parse_constant=lambda value: (_ for _ in ()).throw(ValueError("invalid_json")),
    )


def _bytes(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode(
        "utf-8"
    )


def _bucket(root, selected, *, create=False):
    identity, digest = selected["id"], selected["base_digest"]
    if not HEX.fullmatch(identity) or not HEX.fullmatch(digest):
        raise ValueError("invalid_document_binding")
    path = _guard(Path(root).absolute() / identity / digest, directory=True)
    if create:
        path.mkdir(parents=True, exist_ok=True)
        _guard(path, directory=True)
    return path


def _atomic(path, payload):
    path = _guard(path, directory=False)
    temp = _guard(path.with_name("." + uuid.uuid4().hex + ".tmp"), directory=False)
    try:
        with temp.open("xb") as stream:
            stream.write(payload)
            stream.flush()
            os.fsync(stream.fileno())
        _guard(path.parent, directory=True)
        _guard(path, directory=False)
        os.replace(temp, path)
    finally:
        if temp.exists():
            temp.unlink()


def read_document(root, selected, *, include_pdf=False):
    try:
        return _read_document(root, selected, include_pdf=include_pdf)
    except (TypeError, KeyError, OverflowError, RecursionError, AttributeError):
        raise ValueError("malformed_document_cache") from None


def _read_document(root, selected, *, include_pdf):
    bucket = _bucket(root, selected)
    pointer = bucket / "current.json"
    if not pointer.exists():
        _guard(pointer, directory=False)
        return None
    current = _json(_read(pointer, 256))
    if (
        not isinstance(current, dict)
        or set(current) != {"version"}
        or not HEX.fullmatch(current["version"])
    ):
        raise ValueError("invalid_document_pointer")
    version = current["version"]
    folder = _guard(bucket / version, directory=True)
    payload = _read(folder / "manifest.json", JSON_LIMIT)
    if hashlib.sha256(payload).hexdigest() != version:
        raise ValueError("document_manifest_hash_mismatch")
    manifest = _json(payload)
    keys = {
        "schema",
        "parser_version",
        "notice_id",
        "notice_digest",
        "fetched_at",
        "canonical_url",
        "documents",
        "pages_sha256",
        "parsed",
        "mode",
    }
    if (
        not isinstance(manifest, dict)
        or set(manifest) != keys
        or manifest["schema"] != 1
        or manifest["parser_version"] != PARSER_VERSION
        or manifest["mode"] != "live"
        or manifest["notice_id"] != selected["id"]
        or manifest["notice_digest"] != selected["base_digest"]
        or manifest["canonical_url"] != selected["raw"]["canonical_url"]
    ):
        raise ValueError("document_manifest_binding_mismatch")
    stamp = datetime.fromisoformat(manifest["fetched_at"])
    if stamp.utcoffset() is None:
        raise ValueError("document_timestamp_missing_timezone")
    documents = manifest["documents"]
    if not isinstance(documents, list) or not 1 <= len(documents) <= 3:
        raise ValueError("invalid_document_inventory")
    expected = {"manifest.json", "pages.json"}
    primary_pdf = None
    for i, doc in enumerate(documents):
        if not isinstance(doc, dict) or set(doc) != {
            "file",
            "url",
            "name",
            "label",
            "sha256",
            "size",
            "page_count",
            "detail_sha256",
        }:
            raise ValueError("invalid_document_metadata")
        name = f"document-{i + 1}.pdf"
        if (
            doc["file"] != name
            or type(doc["page_count"]) is not int
            or not 1 <= doc["page_count"] <= 200
            or not isinstance(doc["name"], str)
            or len(doc["name"]) > 240
            or not HEX.fullmatch(doc["detail_sha256"])
        ):
            raise ValueError("invalid_document_metadata")
        validate_pdf_url(selected["raw"], doc["url"])
        data = _read(folder / name, MAX_PDF_BYTES)
        if (
            not data.startswith(b"%PDF-")
            or len(data) != doc["size"]
            or hashlib.sha256(data).hexdigest() != doc["sha256"]
        ):
            raise ValueError("document_pdf_hash_mismatch")
        if include_pdf and i == 0:
            primary_pdf = data
        expected.add(name)
    if {p.name for p in folder.iterdir()} != expected:
        raise ValueError("unmanifested_document_material")
    page_bytes = _read(folder / "pages.json", JSON_LIMIT)
    if hashlib.sha256(page_bytes).hexdigest() != manifest["pages_sha256"]:
        raise ValueError("document_pages_hash_mismatch")
    pages = _json(page_bytes)
    if (
        not isinstance(pages, list)
        or not 1 <= len(pages) <= 600
        or any(
            not isinstance(p, dict)
            or set(p) != {"page", "text", "document_index"}
            or type(p["document_index"]) is not int
            or not 0 <= p["document_index"] < len(documents)
            or type(p["page"]) is not int
            or not isinstance(p["text"], str)
            for p in pages
        )
    ):
        raise ValueError("invalid_document_page_inventory")
    for i, doc in enumerate(documents):
        numbers = [p["page"] for p in pages if p.get("document_index", 0) == i]
        if numbers != list(range(1, doc["page_count"] + 1)):
            raise ValueError("document_page_inventory_mismatch")
        if sum(len(p["text"]) for p in pages if p["document_index"] == i) > 800000:
            raise ValueError("document_text_profile_limit")
    # Derive from hash-verified pages without rewriting the historical manifest.
    # Parser repairs therefore never require a network retry or a GET mutation.
    derived = parse_sections(pages)
    result = {
        **derived,
        **{k: manifest[k] for k in ("documents", "fetched_at", "parser_version")},
        "version": version,
        "derivation_version": SECTION_VERSION,
        "derivation_hash": content_hash([SECTION_VERSION, derived]),
    }
    if include_pdf:
        result["primary_pdf"] = primary_pdf
    return result


def write_document(root, selected, documents, pages, parsed, *, now=None):
    if (
        selected["base_digest"] != content_hash(selected["raw"])
        or not documents
        or len(documents) > 3
        or parsed != parse_sections(pages)
    ):
        raise ValueError("invalid_document_publication")
    bucket = _bucket(root, selected, create=True)
    timestamp = now or datetime.now(UTC)
    if timestamp.utcoffset() is None:
        raise ValueError("invalid_document_timestamp")
    page_bytes = _bytes(pages)
    if len(page_bytes) > JSON_LIMIT:
        raise ValueError("document_text_limit")
    folder = Path(tempfile.mkdtemp(prefix=".stage-", dir=bucket))
    records = []
    # Failed staging directories are deliberately retained for operator diagnosis.
    for i, doc in enumerate(documents):
        validate_pdf_url(selected["raw"], doc["url"])
        data = doc["data"]
        if len(data) > MAX_PDF_BYTES or not data.startswith(b"%PDF-"):
            raise ValueError("invalid_document_bytes")
        name = f"document-{i + 1}.pdf"
        (folder / name).write_bytes(data)
        records.append(
            dict(
                file=name,
                url=doc["url"],
                name=doc["name"],
                label=doc["label"],
                sha256=hashlib.sha256(data).hexdigest(),
                size=len(data),
                page_count=doc["page_count"],
                detail_sha256=doc["detail_sha256"],
            )
        )
    (folder / "pages.json").write_bytes(page_bytes)
    manifest = dict(
        schema=1,
        parser_version=PARSER_VERSION,
        notice_id=selected["id"],
        notice_digest=selected["base_digest"],
        canonical_url=selected["raw"]["canonical_url"],
        fetched_at=timestamp.isoformat(),
        documents=records,
        pages_sha256=hashlib.sha256(page_bytes).hexdigest(),
        parsed=parsed,
        mode="live",
    )
    payload = _bytes(manifest)
    if len(payload) > JSON_LIMIT:
        raise ValueError("document_manifest_limit")
    version = hashlib.sha256(payload).hexdigest()
    (folder / "manifest.json").write_bytes(payload)
    for child in folder.iterdir():
        with child.open("r+b") as stream:
            os.fsync(stream.fileno())
    target = _guard(bucket / version, directory=True)
    if target.exists():
        raise ValueError("document_version_already_exists")
    os.rename(folder, target)
    _atomic(bucket / "current.json", _bytes({"version": version}))
    return read_document(root, selected)


def read_attempt(root, selected):
    try:
        return _read_attempt(root, selected)
    except (TypeError, KeyError, OverflowError, RecursionError, AttributeError):
        raise ValueError("malformed_document_attempt") from None


def _read_attempt(root, selected):
    path = _bucket(root, selected) / "attempt.json"
    if not path.exists():
        _guard(path, directory=False)
        return None
    data = _json(_read(path, 4096))
    if (
        not isinstance(data, dict)
        or set(data) != {"status", "reason", "attempted_at", "next_attempt_at"}
        or data["status"] not in {"ready", "failed"}
        or not re.fullmatch(r"[a-zA-Z0-9_]{0,160}", data["reason"])
    ):
        raise ValueError("invalid_document_attempt")
    start, end = (datetime.fromisoformat(data[key]) for key in ("attempted_at", "next_attempt_at"))
    if (
        start.utcoffset() is None
        or end.utcoffset() is None
        or not timedelta(0) < end - start <= timedelta(hours=24)
    ):
        raise ValueError("invalid_document_cooldown")
    return data


def write_attempt(root, selected, status, reason, now):
    if status not in {"ready", "failed"} or now.utcoffset() is None:
        raise ValueError("invalid_document_attempt")
    cooldown = timedelta(hours=24) if status == "ready" else timedelta(minutes=15)
    reason = re.sub(r"[^a-zA-Z0-9_]", "_", reason)[:160]
    bucket = _bucket(root, selected, create=True)
    _atomic(
        bucket / "attempt.json",
        _bytes(
            dict(
                status=status,
                reason=reason,
                attempted_at=now.isoformat(),
                next_attempt_at=(now + cooldown).isoformat(),
            )
        ),
    )


@contextmanager
def document_lock(root, selected):
    path = _bucket(root, selected, create=True) / "collection.lock"
    _guard(path, directory=False)
    with path.open("a+b") as stream:
        _guard(path, directory=False)
        if os.fstat(stream.fileno()).st_size == 0:
            stream.write(b"0")
            stream.flush()
        stream.seek(0)
        acquired = False
        try:
            if os.name == "nt":
                import msvcrt

                msvcrt.locking(stream.fileno(), msvcrt.LK_NBLCK, 1)
            else:
                import fcntl

                fcntl.flock(stream.fileno(), fcntl.LOCK_EX | fcntl.LOCK_NB)
            acquired = True
        except OSError:
            pass
        try:
            yield acquired
        finally:
            if acquired:
                stream.seek(0)
                if os.name == "nt":
                    msvcrt.locking(stream.fileno(), msvcrt.LK_UNLCK, 1)
                else:
                    fcntl.flock(stream.fileno(), fcntl.LOCK_UN)
