"""Conservative page/section extraction; never distribute compound conditions."""

import hashlib
import re

MAX_QUOTE = 30000
SECTION_VERSION = "housing-qualification-sections-v3"
SCOPE_WORDS = (
    ("general", "일반공급"),
    ("institutional", "기관추천"),
    ("many_children", "다자녀"),
    ("old_parent", "노부모"),
    ("first_time", "생애최초"),
    ("newborn", "신생아"),
    ("newlywed", "신혼부부"),
    ("youth", "청년"),
    ("elderly", "고령자"),
    ("benefits", "주거급여"),
    ("student", "대학생"),
)
QUALIFICATION = re.compile(r"신청\s*자격|청약\s*자격|입주\s*자격|주택소유.*판정|무주택.*판정")
STOP = re.compile(
    r"공급\s*일정|신청\s*방법|청약\s*신청\s*및|당첨자\s*발표|계약\s*체결|신청\s*서류|구비\s*서류|공급\s*규모|분양\s*가격|임대\s*대상|개인정보|납부\s*계좌"
)


def _heading(line, *, preceding_number=False, leading=False):
    text = " ".join(line.split()).strip()
    if not text or len(text) > 130 or text.startswith(("※", "•", "-", "￭", "*")):
        return None
    if re.search(r"합니다|바랍니다|있습니다|해당하는|참조|확인하시|신청자격[을은이별]", text):
        return None
    numbered = bool(re.match(r"^\d+(?:[-.]\d+)?[.\s)]", text))
    subsection = bool(re.match(r"^\d+[-.]\d+[.\s)]", text))
    plain = re.sub(r"^[\d\s.()\-■□▣]+", "", text)
    major = numbered or preceding_number
    if major and re.fullmatch(r"특별공급\s*(?:\(.*\))?", plain):
        return ("special_common", text)
    if plain.startswith("주택소유") and re.search(r"특별공급.*일반공급.*공통", plain):
        return ("common", text)
    if re.fullmatch(r"특별공급\s*공통사항(?:\(.*)?", plain):
        return ("special_common", text)
    for key, word in SCOPE_WORDS:
        if not plain.startswith(word):
            continue
        if key == "general":
            if major and ("신청자격" in plain or re.fullmatch(r"일반공급\s*(?:\(.*\))?", plain)):
                return (key, text)
        elif subsection or re.match(re.escape(word) + r".*?특별공급\s*(?:\(|$)", plain):
            return (key, text)
    if subsection and re.search(r"계층|특별공급|신청자격", plain):
        return ("unsupported_" + hashlib.sha256(text.encode()).hexdigest()[:12], text)
    # A table label such as '신청자격' inside an active subtype is not a new chapter.
    if QUALIFICATION.search(plain) and (
        major or (leading and plain in {"신청자격", "입주자격", "청약자격"})
    ):
        if plain.startswith("특별공급"):
            return ("special_common", text)
        return ("common", text)
    if major and re.search(r"공통\s*유의사항|단지\s*유의사항", plain):
        return ("context", text)
    if major and re.search(STOP.pattern + r"|공급대상|공급금액|분양대금|참고사항", plain):
        return ("stop", text)
    if re.fullmatch(
        r"(?:주택소유|무주택).*?(?:판정기준|판정 기준|판정방법|확인방법)(?:\(.*\))?", plain
    ):
        return ("definitions", text)
    return None


def parse_sections(pages):
    if (
        not isinstance(pages, list)
        or not 1 <= len(pages) <= 600
        or any(
            not isinstance(p, dict)
            or not isinstance(p.get("text"), str)
            or type(p.get("page")) is not int
            for p in pages
        )
        or sum(len(p["text"]) for p in pages) > 2400000
    ):
        raise ValueError("invalid_document_pages")
    sections, scopes = [], {}
    current, lines, start, end, doc_index = None, [], 0, 0, 0
    recognized = False
    prelude = []
    previous_number = False

    def flush():
        nonlocal lines
        body = "\n".join(lines).strip()
        if current and body:
            key, title = current
            sections.append(
                dict(
                    scope="common" if key == "context" else key,
                    title=title,
                    text=body,
                    page_start=start,
                    page_end=end,
                    document_index=doc_index,
                )
            )
        lines = []

    for page in pages:
        next_doc = page.get("document_index", 0)
        if next_doc != doc_index:
            flush()
            current = None
            doc_index = next_doc
            previous_number = False
        nonempty = [line for line in page["text"].splitlines() if line.strip()]
        first = True
        had_active = current is not None
        for line in nonempty:
            heading = _heading(line, preceding_number=previous_number, leading=first)
            previous_number = bool(re.fullmatch(r"\s*\d{1,2}\s*", line))
            first = False
            if heading:
                if heading[0] == "definitions":
                    heading = ((current[0] if current else "common"), heading[1])
                flush()
                if heading[0] == "stop":
                    current = None
                    continue
                current = heading
                start = page["page"]
                recognized = recognized or heading[0] != "context"
                if heading[0] not in {"common", "context", "special_common"}:
                    label = re.sub(r"^[\d\s.()\-■□▣]+", "", heading[1]).split("(")[0].strip()
                    scopes.setdefault(heading[0], label)
            elif current:
                lines.append(line)
            end = page["page"]
        # Front-page exceptions/relaxed criteria are common source context, not supply tables.
        if (
            page["page"] <= 2
            and not had_active
            and current is None
            and re.search(r"무주택|중복신청|재당첨|입주자격", page["text"])
        ):
            prelude.append(
                dict(
                    scope="common",
                    title="공고 앞부분의 공통 안내와 예외",
                    text=page["text"],
                    page_start=page["page"],
                    page_end=page["page"],
                    document_index=doc_index,
                )
            )
    flush()
    sections = prelude + sections
    for section in sections:
        section["id"] = "s_" + hashlib.sha256(str(section).encode()).hexdigest()[:20]
    choices = [{"key": key, "label": label} for key, label in scopes.items()]
    if not choices:
        choices = [{"key": "common", "label": "공고의 공통 신청자격"}]
    issues = [] if recognized and sections else ["qualification_sections_not_found"]
    if any(s["key"].startswith("unsupported_") for s in choices):
        issues.append("unsupported_supply_scope")
    return dict(sections=sections, scopes=choices, issues=issues)


def document_criteria(document, scope):
    allowed = {s["key"] for s in document["scopes"]}
    if scope not in allowed:
        raise ValueError("unknown_supply_scope")
    included = {"common", scope}
    if scope not in {"general", "common", "youth", "elderly", "benefits", "student"}:
        included.add("special_common")
    rules = []
    for section in document["sections"]:
        if section["scope"] not in included:
            continue
        quote = section["text"]
        unresolved = len(quote) > MAX_QUOTE
        rules.append(
            dict(
                id="p_" + section["id"][2:],
                kind="unresolved" if unresolved else "manual",
                label="해당 유형의 신청자격과 예외를 원문대로 적용했을 때 요건에 맞나요?",
                quote=quote[:1200] if unresolved else quote,
                excluded=False,
                origin="official_pdf",
                unit="",
                bounds=[],
                maximum=0,
                title=section["title"],
                page_start=section["page_start"],
                page_end=section["page_end"],
                document_index=section["document_index"],
            )
        )
    if len(rules) > 16:
        rules = rules[:15]
        issues = ["too_many_qualification_sections"]
    else:
        issues = list(document.get("issues", []))
    if issues or not rules:
        rules = rules[:15]
        rules.append(
            dict(
                id="p_unresolved",
                kind="unresolved",
                label="공고문 추가 확인 필요",
                quote=(
                    "자동으로 구분하지 못한 조건이 있습니다. "
                    "공식 원문의 해당 유형과 예외를 확인해야 합니다."
                ),
                excluded=False,
                origin="official_pdf",
                unit="",
                bounds=[],
                maximum=0,
                title="추가 확인",
                page_start=0,
                page_end=0,
                document_index=0,
            )
        )
    for rule in rules:
        docs = document.get("documents", [])
        index = rule["document_index"]
        if rule["page_start"] and index < len(docs):
            rule.update(document_url=docs[index]["url"], document_name=docs[index]["name"])
    return rules
