"""Source-bound official housing documents, private local analysis only."""
