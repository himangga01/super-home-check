"""Bounded official document acquisition, called only by CLI or authorized POST."""

from datetime import UTC, datetime, timedelta
from pathlib import Path
from time import monotonic

from wisdome_writer.notice_diagnosis.pdf import extract_official_pdf

from .sections import parse_sections
from .sources import download_notice
from .storage import (
    document_lock,
    document_root,
    read_attempt,
    read_document,
    write_attempt,
    write_document,
)


def ensure_document(selected, *, root=None, transport=None, now=None, seconds=90):
    root = document_root() if root is None else root
    now = now or datetime.now(UTC)
    deadline = monotonic() + min(seconds, 90)
    try:
        with document_lock(root, selected) as acquired:
            if not acquired:
                return {"status": "busy", "reason": "document_collection_in_progress"}
            cached = read_document(root, selected)
            if cached and now - datetime.fromisoformat(cached["fetched_at"]) < timedelta(hours=24):
                return {"status": "cached", "document": cached}
            attempt = read_attempt(root, selected)
            if attempt and datetime.fromisoformat(attempt["next_attempt_at"]) > now:
                return {
                    "status": "deferred",
                    "reason": attempt["reason"],
                    "next_attempt_at": attempt["next_attempt_at"],
                }
            try:
                documents = download_notice(selected["raw"], transport=transport, seconds=seconds)
                if not documents:
                    raise ValueError("official_notice_pdf_not_found")
                pages = []
                for index, doc in enumerate(documents):
                    remaining = deadline - monotonic()
                    if remaining <= 0:
                        raise ValueError("document_extraction_budget_exhausted")
                    extracted = extract_official_pdf(doc["data"], timeout=min(30, remaining))
                    doc["page_count"] = len(extracted)
                    pages.extend({**p, "document_index": index} for p in extracted)
                parsed = parse_sections(pages)
                result = write_document(root, selected, documents, pages, parsed, now=now)
                write_attempt(root, selected, "ready", "", now)
                return {"status": "ready", "document": result}
            except (ValueError, OSError) as exc:
                reason = str(exc) if isinstance(exc, ValueError) else "document_storage_error"
                write_attempt(root, selected, "failed", reason, now)
                return {
                    "status": "failed",
                    "reason": reason,
                    "next_attempt_at": (now + timedelta(minutes=15)).isoformat(),
                }
    except (ValueError, OSError):
        return {"status": "failed", "reason": "document_cache_unavailable"}


def collect_saved_run(run, *, max_notices=20, seconds=120, identities=(), root=None):
    """Precollect without modifying the selected housing run or article output."""
    from django.conf import settings

    from apps.local_content.bundles import _parse_strict_json_object
    from apps.local_content.views import _parse_run_name
    from wisdome_writer.notice_diagnosis.sources import notice_id, select_notice
    from wisdome_writer.portal.housing import (
        HOUSING_JSON_MAX_NODES,
        _project_document,
        _ReadOnlyBundleWriter,
    )

    from .storage import _read

    if not settings.IS_LOCAL_RUNTIME or not 1 <= max_notices <= 200 or not 1 <= seconds <= 600:
        raise ValueError("invalid_document_collection_configuration")
    day = _parse_run_name(run)
    if day is None:
        raise ValueError("invalid_housing_run")
    writer = _ReadOnlyBundleWriter(Path(settings.LOCAL_ARTICLE_ROOT))
    payload = writer.read_validated_run_file(day, "notices.json", run_directory=run)
    data = _parse_strict_json_object(
        payload, "housing document collection", max_nodes=HOUSING_JSON_MAX_NODES
    )
    _project_document(data, day)
    report = Path(settings.LOCAL_ARTICLE_ROOT) / run / "acceptance-report.json"
    mode = (
        __import__("json").loads(_read(report, 4 * 1024 * 1024)).get("mode")
        if report.exists()
        else "unknown"
    )
    counts = {s: 0 for s in ("ready", "cached", "failed", "deferred", "busy", "unsupported")}
    result = dict(
        run=run,
        status="completed",
        counts=counts,
        results=[],
        complete=False,
        total=len(data["notices"]),
    )
    if mode != "live":
        result["status"] = "not_live"
        return result
    rows = sorted(
        data["notices"], key=lambda n: (n["published_at"], n["external_id"]), reverse=True
    )
    if identities:
        available = {
            value
            for n in rows
            for value in (notice_id(n["source_key"], n["external_id"]), n["external_id"])
        }
        if set(identities) - available:
            raise ValueError("requested_notice_not_in_saved_run")
        rows = [
            n
            for n in rows
            if notice_id(n["source_key"], n["external_id"]) in identities
            or n["external_id"] in identities
        ]
    result["selected"] = len(rows)
    deadline = monotonic() + seconds
    for raw in rows[:max_notices]:
        remaining = deadline - monotonic()
        if remaining <= 0:
            result["status"] = "budget_exhausted"
            break
        selected = select_notice("housing", notice_id(raw["source_key"], raw["external_id"]), run)
        outcome = (
            ensure_document(selected, root=root, seconds=min(remaining, 90))
            if selected.get("automatic_documents")
            else {"status": "unsupported", "reason": "unsupported_official_notice_identity"}
        )
        counts[outcome["status"]] += 1
        result["results"].append(
            dict(
                id=selected["id"],
                external_id=raw["external_id"],
                title=raw["title"],
                status=outcome["status"],
                reason=outcome.get("reason", ""),
                version=(outcome.get("document") or {}).get("version"),
            )
        )
    result["complete"] = len(result["results"]) == len(rows) and not any(
        counts[k] for k in ("failed", "deferred", "busy", "unsupported")
    )
    result["coverage_limited"] = not result["complete"]
    return result
