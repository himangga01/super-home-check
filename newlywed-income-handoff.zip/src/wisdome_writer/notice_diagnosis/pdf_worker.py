"""Pure text PDF worker; no rendering, scripts, network or HWP support."""

import json
import sys

import fitz


def main():
    official = sys.argv[1:] == ["--official-housing"]
    if sys.argv[1:] and not official:
        return 1
    max_bytes, max_pages, max_chars = (
        (16 * 1024 * 1024, 200, 800000) if official else (8 * 1024 * 1024, 80, 120000)
    )
    data = sys.stdin.buffer.read(max_bytes + 1)
    if len(data) > max_bytes or not data.startswith(b"%PDF-"):
        return 1
    try:
        with fitz.open(stream=data, filetype="pdf") as doc:
            if doc.needs_pass or not 1 <= doc.page_count <= max_pages or doc.xref_length() > 100000:
                return 1
            pages, size = [], 0
            for page in doc:
                if max(page.rect.width, page.rect.height) > 16384:
                    return 1
                text = page.get_text("text", sort=True)
                size += len(text)
                if size > max_chars:
                    return 1
                pages.append(text)
            text = "\n".join(pages)
            if len(text.strip()) < 30 or text.count("\ufffd") > max(1, len(text)) * 0.02:
                return 1
            result = (
                [{"page": i + 1, "text": value} for i, value in enumerate(pages)]
                if official
                else text
            )
            sys.stdout.buffer.write(json.dumps(result, ensure_ascii=False).encode("utf-8"))
        return 0
    except Exception:
        return 1


if __name__ == "__main__":
    raise SystemExit(main())
