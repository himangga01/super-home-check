"""Conservative criterion extraction. Complex clauses stay intact and assisted."""

import hashlib
import re
import unicodedata
from datetime import date

MAX_RULES = 16
ELIGIBLE = r"신청\s*자격|입주\s*자격|지원\s*대상|신청\s*대상|자격\s*요건|지원\s*요건|대출\s*대상"
EXCLUDED = r"(?:신청|지원)\s*(?:제외|제한)(?:\s*대상)?|제외\s*대상|제한\s*사항"
HEADERS = re.compile(
    rf"(?:^|[\n□■○●])\s*[\[(]?(?P<label>{ELIGIBLE}|{EXCLUDED}|지원내용|지원규모|신청기간|접수기간|신청방법|유의사항|제출서류)[\])]?(?:\s*[:：]|\s+)",
    re.M,
)
COMPLEX = re.compile(
    r"또는|혹은|어느\s*하나|중\s*하나|단[,，\s]|다만|예외|제외하고|①|②|가구원|%|퍼센트"
)
OPERATORS = {"이상": "ge", "초과": "gt", "이하": "le", "미만": "lt"}


def _sections(text, origin):
    headers = list(HEADERS.finditer(text))
    sections = []
    for index, match in enumerate(headers):
        label = match["label"]
        if not re.fullmatch(f"{ELIGIBLE}|{EXCLUDED}", label):
            continue
        end = headers[index + 1].start() if index + 1 < len(headers) else len(text)
        sections.append((text[match.end() : end].strip(), bool(re.fullmatch(EXCLUDED, label))))
    if not sections and origin == "provided":
        sections = [(text.strip(), False)]
    if not sections and "☞" in text:
        first = text.split("☞", 2)[1].split("사업신청", 1)[0].strip()
        if any(word in first for word in ("소상공인", "중소기업", "영업", "대상")):
            sections = [(first, False)]
    return sections


def _simple(quote):
    age = re.fullmatch(r"만\s*(\d{1,3})세\s*이상\s*(?:만\s*)?(\d{1,3})세\s*이하[.。]?", quote)
    if age and int(age[1]) <= int(age[2]) <= 130:
        return dict(
            kind="number",
            label="공고 기준일 현재 만 나이",
            unit="세",
            bounds=[["ge", int(age[1])], ["le", int(age[2])]],
            maximum=130,
        )
    age = re.fullmatch(r"만\s*(\d{1,3})세\s*(이상|초과|이하|미만)[.。]?", quote)
    if age and int(age[1]) <= 130:
        return dict(
            kind="number",
            label="공고 기준일 현재 만 나이",
            unit="세",
            bounds=[[OPERATORS[age[2]], int(age[1])]],
            maximum=130,
        )
    duration = re.fullmatch(
        r"(업력|청약통장\s*가입기간)\s*(\d+)\s*(년|개월)\s*(이상|초과|이하|미만)[.。]?", quote
    )
    if duration:
        amount = int(duration[2]) * (12 if duration[3] == "년" else 1)
        return dict(
            kind="number",
            label="공고 기준일 현재 " + duration[1],
            unit="개월",
            bounds=[[OPERATORS[duration[4]], amount]],
            maximum=1800,
        )
    money = re.fullmatch(
        r"(연매출액?|총자산(?:가액)?|자동차가액|월평균소득)\s*([\d,]+)\s*(억원|만원|원)\s*(이상|초과|이하|미만)[.。]?",
        quote,
    )
    if money:
        amount = (
            int(money[2].replace(",", "")) * {"억원": 100000000, "만원": 10000, "원": 1}[money[3]]
        )
        return dict(
            kind="number",
            label="공고의 산정 기준에 따른 " + money[1],
            unit="원",
            bounds=[[OPERATORS[money[4]], amount]],
            maximum=10**15,
        )
    return dict(kind="manual", label="이 조건을 충족하나요?", unit="", bounds=[], maximum=0)


def compile_criteria(text, origin):
    if origin not in {"provided", "official_saved", "housing_saved"}:
        raise ValueError("Unknown text origin")
    if not isinstance(text, str) or len(text) > 120000 or "\x00" in text:
        raise ValueError("Invalid qualification text")
    text = unicodedata.normalize("NFC", text).replace("\r", "")
    sections = _sections(text, origin)
    rules = []
    for section, excluded in sections:
        # Exclusions may combine several facts into one disqualifying condition.
        # Keep their complete wording so negation never distributes over AND/OR.
        complex_section = excluded or bool(COMPLEX.search(section))
        pieces = [section] if complex_section else re.split(r"\n+", section)
        for piece in pieces:
            quote = piece.strip().lstrip("-•* ").strip()
            if not quote:
                continue
            truncated = len(quote) > 1200
            rule = (
                _simple(quote)
                if not (complex_section or excluded or truncated)
                else dict(
                    kind="unresolved" if truncated else "manual",
                    label="이 조건을 충족하나요?",
                    unit="",
                    bounds=[],
                    maximum=0,
                )
            )
            rule.update(quote=quote[:1200], excluded=excluded, origin=origin)
            if excluded:
                rule["label"] = "이 제외·제한사항에 해당하나요?"
            if truncated:
                rule["label"] = "조건이 길어 해당 부분을 나누어 원문을 다시 확인해 주세요."
            rule["id"] = "c_" + hashlib.sha256((str(len(rules)) + quote).encode()).hexdigest()[:16]
            rules.append(rule)
    if len(rules) > MAX_RULES:
        rules = rules[: MAX_RULES - 1] + [
            dict(
                id="c_remaining",
                kind="unresolved",
                label="추가 조건 확인 필요",
                quote="추출 범위를 넘는 조건이 있어 자격 부분을 좁혀 다시 확인해야 합니다.",
                origin=origin,
                excluded=False,
                unit="",
                bounds=[],
                maximum=0,
            )
        ]
    return rules


def evaluate(criteria, answers, complete):
    rows = []
    for rule in criteria:
        value = answers.get(rule["id"])
        status = "unknown"
        if rule["kind"] == "number" and value is not None:
            comparisons = {
                "ge": lambda a, b: a >= b,
                "gt": lambda a, b: a > b,
                "le": lambda a, b: a <= b,
                "lt": lambda a, b: a < b,
            }
            matched = all(comparisons[op](value, threshold) for op, threshold in rule["bounds"])
            status = "met" if matched else "unmet"
        elif rule["kind"] == "manual" and value in {"yes", "no"}:
            matched = (value == "no") if rule["excluded"] else (value == "yes")
            status = "met" if matched else "unmet"
        rows.append(
            {
                **rule,
                "status": status,
                "status_label": {
                    "met": "응답상 충족",
                    "unmet": "조건 불일치",
                    "unknown": "추가 확인",
                }[status],
                "answer": value if value is not None else "미입력",
            }
        )
    counts = {key: sum(r["status"] == key for r in rows) for key in ("met", "unmet", "unknown")}
    status = (
        "unmet"
        if counts["unmet"]
        else "review"
        if not rows or counts["unknown"] or not complete
        else "conditional"
    )
    labels = {
        "unmet": "맞지 않는 조건이 있습니다",
        "review": "신청자격을 더 확인해야 합니다",
        "conditional": "제시된 조건은 충족한 것으로 응답했습니다",
    }
    return dict(
        status=status,
        label=labels[status],
        rows=rows,
        counts=counts,
        complete=bool(complete),
        supplied=any(r["origin"] == "provided" for r in rows),
    )


def period_status(text, today: date, *, single_day=False):
    unknown = dict(code="unknown", label="접수 가능 여부 확인 필요", text=text or "일정 미확인")
    if not isinstance(text, str) or any(w in text for w in ("예산", "상시", "미정", "수시")):
        return unknown
    found = re.findall(r"(?<!\d)(20\d{2})\s*[./-]\s*(\d{1,2})\s*[./-]\s*(\d{1,2})(?!\d)", text)
    explicit_day = single_day and re.fullmatch(
        r"\s*20\d{2}\s*[./-]\s*\d{1,2}\s*[./-]\s*\d{1,2}[.]?\s*(?:\([월화수목금토일]\))?\s*", text
    )
    if len(found) != 2 and not (len(found) == 1 and explicit_day):
        return unknown
    try:
        days = [date(*map(int, item)) for item in found]
    except ValueError:
        return unknown
    start, end = min(days), max(days)
    if len(days) == 2 and days[0] > days[1]:
        return unknown
    code = "ended" if today > end else "upcoming" if today < start else "window"
    return dict(
        code=code,
        label={
            "ended": "공고상 접수기간 종료",
            "upcoming": "공고상 접수 시작 전",
            "window": "공고상 날짜 범위 안 · 마감시각 확인 필요",
        }[code],
        text=text,
    )
