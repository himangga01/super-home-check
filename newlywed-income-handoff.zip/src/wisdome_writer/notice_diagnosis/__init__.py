"""Source-bound, ephemeral eligibility prechecks for selected notices."""
