"""Notice-bound, stateless preliminary qualification checks."""

from functools import wraps

from django.core import signing
from django.http import Http404, HttpResponseBadRequest, HttpResponseNotAllowed
from django.shortcuts import render
from django.utils import timezone

from apps.local_content.views import _require_local_request
from apps.policy_funding.views import policy_page

from .forms import AnswersForm, HousingSourceForm, SourceForm
from .pdf import extract_pdf
from .rules import compile_criteria, evaluate, period_status
from .sources import PATHS, notice_choices, select_notice

SALT = "wisdome.selected-notice-diagnosis.v1"
MAX_STATE = 256 * 1024
ORIGINS = {
    "official_saved": "저장한 공식 페이지 본문",
    "housing_saved": "저장된 청약 자료 · 상세 자격 누락 가능",
    "provided": "사용자 제공 본문·PDF · 공식 원문 대조 필요",
    "official_pdf": "선택한 공고에서 자동 수집한 공식 공고문 PDF",
}
STATE_KEYS = {
    "period_day",
    "v",
    "topic",
    "id",
    "run",
    "digest",
    "stage",
    "criteria",
    "origin",
    "scope",
    "period",
    "answers",
}


def _guard(function):
    secured = policy_page(function, allow_post=True)

    @wraps(function)
    def wrapped(request, *args, **kwargs):
        if kwargs.get("topic") == "housing":
            _require_local_request(request)
        return secured(request, *args, **kwargs)

    return wrapped


def _load_state(request, selected):
    tokens = request.POST.getlist("state")
    if len(tokens) != 1 or len(tokens[0]) > MAX_STATE:
        raise ValueError("Invalid state size")
    state = signing.loads(tokens[0], salt=SALT, max_age=7200)
    if not isinstance(state, dict) or set(state) != STATE_KEYS or state["v"] != 1:
        raise ValueError("Invalid state shape")
    if any(state[key] != selected[key] for key in ("topic", "id", "run", "digest")):
        raise ValueError("Notice changed")
    if (
        state["stage"] not in {"source", "questions", "result"}
        or state["origin"] not in ORIGINS
        or not isinstance(state["criteria"], list)
        or len(state["criteria"]) > 16
        or not isinstance(state["answers"], dict)
        or not isinstance(state["scope"], str)
        or len(state["scope"]) > 120
        or not isinstance(state["period"], str)
        or len(state["period"]) > 2048
        or not isinstance(state["period_day"], bool)
    ):
        raise ValueError("Invalid state values")
    if state["origin"] == "official_pdf" and state["stage"] != "source":
        from wisdome_writer.housing_documents.sections import document_criteria

        if not selected.get("document"):
            raise ValueError("Official document unavailable")
        rebuilt = document_criteria(selected["document"], state["scope"])
        if state["criteria"] != [{"id": r["id"]} for r in rebuilt]:
            raise ValueError("Official criterion version changed")
        state["criteria"] = rebuilt
    return state


def _source_form(selected, *args, **kwargs):
    if selected.get("automatic_documents"):
        return HousingSourceForm(
            *args,
            scopes=(selected.get("document") or {}).get("scopes", ()),
            events=selected["events"],
            **kwargs,
        )
    return SourceForm(*args, events=selected["events"], **kwargs)


def _page(request, selected, state, *, form=None, result=None):
    token_state = state
    if state["origin"] == "official_pdf":
        token_state = {**state, "criteria": [{"id": r["id"]} for r in state["criteria"]]}
    token = signing.dumps(token_state, salt=SALT, compress=False)
    if len(token) > MAX_STATE:
        return HttpResponseBadRequest(
            "조건 본문이 너무 깁니다. 자격 부분을 좁혀 다시 확인해 주세요."
        )
    if form is None:
        form = (
            _source_form(selected, initial={"scope": state["scope"]})
            if state["stage"] == "source"
            else AnswersForm(state["criteria"], initial=state["answers"])
        )
    fields = (
        [{"rule": rule, "field": form[rule["id"]]} for rule in state["criteria"]]
        if state["stage"] == "questions"
        else []
    )
    return render(
        request,
        "notice_diagnosis/detail.html",
        {
            "selected": selected,
            "stage": state["stage"],
            "state_token": token,
            "form": form,
            "manual_form": SourceForm(events=selected["events"], auto_id="fallback_%s")
            if selected.get("automatic_documents")
            else None,
            "manual_mode": bool(
                selected.get("automatic_documents") and isinstance(form, SourceForm)
            ),
            "criteria": state["criteria"],
            "fields": fields,
            "result": result,
            "origin": state["origin"],
            "origin_label": ORIGINS[state["origin"]],
            "scope": state["scope"],
            "scope_label": next(
                (
                    s["label"]
                    for s in (selected.get("document") or {}).get("scopes", [])
                    if s["key"] == state["scope"]
                ),
                state["scope"],
            ),
            "period": period_status(
                state["period"], timezone.localdate(), single_day=state["period_day"]
            ),
            "picker_url": PATHS[selected["topic"]],
        },
    )


@_guard
def picker(request, *, topic):
    if request.method not in {"GET", "HEAD"}:
        return HttpResponseNotAllowed(["GET", "HEAD"])
    query = request.GET.get("q", "").strip()
    if len(query) > 200:
        return HttpResponseBadRequest("검색어는 200자 이내로 입력해 주세요.")
    try:
        rows, message = notice_choices(topic, query)
    except (ValueError, OSError):
        rows, message = [], "저장된 공고를 검증할 수 없습니다. 수집 이력을 확인해 주세요."
    return render(
        request,
        "notice_diagnosis/picker.html",
        {
            "rows": rows,
            "message": message,
            "q": query,
            "topic_label": "청약" if topic == "housing" else "정책자금",
        },
    )


@_guard
def detail(request, identity, *, topic):
    runs = request.GET.getlist("run")
    if len(runs) != 1:
        raise Http404
    selected = select_notice(topic, identity, runs[0])
    state = dict(
        v=1,
        **{key: selected[key] for key in ("topic", "id", "run", "digest")},
        stage="source",
        criteria=[],
        origin=selected["origin"],
        scope="",
        period=selected["period"],
        period_day=False,
        answers={},
    )
    if request.method in {"GET", "HEAD"}:
        return _page(request, selected, state)
    try:
        state = _load_state(request, selected)
        action = request.POST.get("action")
        if action == "fetch" and not selected.get("automatic_documents"):
            raise ValueError("Automatic document action is not supported")
        if action == "source":
            state.update(stage="source", answers={})
            return _page(request, selected, state)
        if action == "edit" and state["stage"] == "result":
            state["stage"] = "questions"
            return _page(request, selected, state)
        if action in {"prepare", "fetch"} and state["stage"] == "source":
            manual = bool(request.POST.get("text") or request.FILES.get("pdf"))
            if selected.get("automatic_documents") and not manual:
                from wisdome_writer.housing_documents import collection

                outcome = collection.ensure_document(selected)
                if outcome["status"] not in {"ready", "cached"}:
                    form = _source_form(selected, request.POST)
                    form.is_valid()
                    message = (
                        "공식 공고문을 자동 분석하지 못했습니다. 잠시 후 다시 시도해 주세요. "
                        "PDF가 없거나 읽을 수 없는 문서는 공식 원문 확인이 필요합니다."
                    )
                    if outcome.get("next_attempt_at"):
                        message += " 다음 자동 수집 가능 시각: " + outcome["next_attempt_at"]
                    form.add_error(None, message)
                    return _page(request, selected, state, form=form)
                selected = select_notice(topic, identity, runs[0])
                state.update(
                    digest=selected["digest"], origin=selected["origin"], criteria=[], answers={}
                )
                if action == "fetch":
                    return _page(request, selected, state)
            form = (
                SourceForm(request.POST, request.FILES, events=selected["events"])
                if manual
                else _source_form(selected, request.POST)
            )
            if not form.is_valid():
                return _page(request, selected, state, form=form)
            text = form.cleaned_data.get("text", "")
            if form.cleaned_data.get("pdf"):
                try:
                    text = extract_pdf(form.cleaned_data["pdf"].read(8 * 1024 * 1024 + 1))
                except ValueError as exc:
                    form.add_error("pdf", str(exc))
                    return _page(request, selected, state, form=form)
            origin = "provided" if text else selected["origin"]
            if origin == "official_pdf":
                from wisdome_writer.housing_documents.sections import document_criteria

                rules = document_criteria(selected["document"], form.cleaned_data["scope"])
            else:
                rules = compile_criteria(text or selected["text"], origin)
            if not rules:
                form.add_error(
                    None,
                    "저장된 자료에 자격 조건이 부족합니다. "
                    "해당 신청유형의 자격·제외 부분 또는 PDF를 추가해 주세요.",
                )
                return _page(request, selected, state, form=form)
            period = selected["period"]
            if form.cleaned_data.get("event"):
                period = selected["events"][int(form.cleaned_data["event"])]["text"]
            state.update(
                stage="questions",
                criteria=rules,
                origin=origin,
                scope=form.cleaned_data["scope"],
                period=period,
                period_day=bool(form.cleaned_data.get("event")),
                answers={},
            )
            return _page(request, selected, state)
        if action == "evaluate" and state["stage"] == "questions":
            form = AnswersForm(state["criteria"], request.POST)
            if not form.is_valid():
                return _page(request, selected, state, form=form)
            result = evaluate(state["criteria"], form.cleaned_data, form.cleaned_data["complete"])
            state.update(stage="result", answers=form.cleaned_data)
            return _page(request, selected, state, result=result)
        raise ValueError("Invalid transition")
    except (signing.BadSignature, ValueError, TypeError, KeyError):
        return HttpResponseBadRequest(
            "진단 상태가 만료되었거나 공고가 변경되었습니다. 공고를 다시 선택해 주세요."
        )
