"""Read only validated immutable records; never fetch a URL supplied by a user."""

import re
from urllib.parse import urlencode

from django.conf import settings
from django.http import Http404

from apps.local_content.bundles import BundleValidationError, _parse_strict_json_object
from apps.local_content.views import _article_root, _parse_run_name
from apps.policy_funding.contracts import content_hash
from apps.policy_funding.storage import list_runs, read_run
from wisdome_writer.portal.housing import (
    HOUSING_JSON_MAX_NODES,
    _project_document,
    _ReadOnlyBundleWriter,
    load_housing_snapshot,
)

PATHS = {"housing": "/housing/diagnosis/", "funding": "/policy-funding/notice-diagnosis/"}


def notice_id(source, external):
    return content_hash([source, external])


def diagnosis_url(topic, identity, run):
    return PATHS[topic] + identity + "/?" + urlencode({"run": run})


def housing_link(row):
    if not all(row.get(key) for key in ("source_key", "external_id", "run_name")):
        return None
    return diagnosis_url(
        "housing", notice_id(row["source_key"], row["external_id"]), row["run_name"]
    )


def _strings(value):
    if not isinstance(value, list) or len(value) > 32:
        raise ValueError("Invalid saved qualification list")
    if any(not isinstance(item, str) or len(item) > 4000 or "\x00" in item for item in value):
        raise ValueError("Invalid saved qualification text")
    return value


def select_notice(topic, identity, run):
    if topic not in PATHS or not re.fullmatch(r"[a-f0-9]{64}", identity or ""):
        raise Http404("공고를 다시 선택해 주세요.")
    if not isinstance(run, str) or _parse_run_name(run) is None:
        raise Http404("검증된 수집 기록을 선택해 주세요.")
    try:
        if topic == "funding":
            saved = read_run(settings.POLICY_FUNDING_ROOT, run)
            if saved["mode"] != "live":
                raise ValueError("Fixture is not an application source")
            row = next((n for n in saved["notices"] if n.stable_id == identity), None)
            if row is None:
                raise ValueError("Notice not in selected run")
            return dict(
                topic=topic,
                id=identity,
                run=run,
                title=row.title,
                issuer=row.issuer,
                url=row.official_url,
                published=str(row.published_on or "미확인"),
                captured=row.fetched_at,
                text=row.evidence_text,
                origin="official_saved",
                digest=content_hash(row.to_dict()),
                period=row.application_period or "",
                events=[],
                limited=True,
            )
        root = _article_root(required=True)
        writer = _ReadOnlyBundleWriter(root)
        payload = writer.read_validated_run_file(
            _parse_run_name(run), "notices.json", run_directory=run
        )
        document = _parse_strict_json_object(
            payload, "selected housing notice", max_nodes=HOUSING_JSON_MAX_NODES
        )
        stamp, projected, complete = _project_document(document, _parse_run_name(run))
        raw = next(
            (
                n
                for n in document["notices"]
                if notice_id(n["source_key"], n["external_id"]) == identity
            ),
            None,
        )
        if raw is None:
            raise ValueError("Housing notice not in selected run")
        row = next(n for n in projected if notice_id(n["source_key"], n["external_id"]) == identity)
        clauses = []
        for field, label in (
            ("eligibility_summary", "신청자격"),
            ("restriction_summary", "신청제외"),
        ):
            material = _strings(raw.get(field, []))
            if material:
                clauses.append(label + ":\n" + "\n".join(material))
        for label, value in raw.get("facts", []):
            if label in {"신청자격", "입주자격", "자격요건", "신청제외", "제한사항"}:
                clauses.append(label + ": " + value)
        text = "\n".join(clauses)
        if len(text) > 40000:
            raise ValueError("Qualification text exceeds limit")
        dates = [raw.get("application_start"), raw.get("application_end")]
        period = " ~ ".join(d for d in dates if d)
        selected = dict(
            topic=topic,
            id=identity,
            run=run,
            title=row["title"],
            issuer=row["publisher"],
            url=row["url"],
            published=row["published_on"],
            captured=stamp,
            text=text,
            origin="housing_saved",
            digest=content_hash(raw),
            period=period,
            events=row["subscription_events"],
            limited=not complete or not text,
            raw=raw,
            base_digest=content_hash(raw),
        )
        from wisdome_writer.housing_documents.sources import validate_detail_url
        from wisdome_writer.housing_documents.storage import (
            document_root,
            read_attempt,
            read_document,
        )

        selected.update(automatic_documents=False, document=None, document_attempt=None)
        try:
            validate_detail_url(raw, raw["canonical_url"])
            selected["automatic_documents"] = True
        except ValueError:
            pass
        if selected["automatic_documents"]:
            try:
                selected["document"] = read_document(document_root(), selected)
                selected["document_attempt"] = read_attempt(document_root(), selected)
            except (ValueError, OSError):
                selected["document_problem"] = "저장된 공고문 자료를 검증할 수 없습니다."
            if selected["document"]:
                selected["origin"] = "official_pdf"
                selected["digest"] = content_hash(
                    [
                        selected["base_digest"],
                        selected["document"]["version"],
                        selected["document"]["derivation_hash"],
                    ]
                )
                selected["text"] = "\n".join(s["title"] for s in selected["document"]["sections"])
        return selected
    except (ValueError, OSError, BundleValidationError) as exc:
        raise Http404("선택 공고의 저장 자료를 검증할 수 없습니다.") from exc


def notice_choices(topic, query=""):
    if topic not in PATHS or not isinstance(query, str) or len(query) > 200:
        raise ValueError("Invalid topic/search")
    if topic == "housing":
        data = load_housing_snapshot(query=query)
        rows = [
            dict(
                title=r["title"],
                issuer=r["publisher"],
                published=r["published_on"],
                run=r["run_name"],
                url=housing_link(r),
            )
            for r in data["notices"]
        ]
        return rows, data["message"]
    rows, seen = [], set()
    for run in list_runs(settings.POLICY_FUNDING_ROOT, limit=100):
        if run["mode"] != "live":
            continue
        for row in run["notices"]:
            if row.stable_id in seen:
                continue
            seen.add(row.stable_id)
            if query.casefold() not in (row.title + " " + row.issuer).casefold():
                continue
            rows.append(
                dict(
                    title=row.title,
                    issuer=row.issuer,
                    published=row.published_on,
                    run=run["run_name"],
                    url=diagnosis_url(topic, row.stable_id, run["run_name"]),
                )
            )
    return rows[
        :100
    ], "검증된 저장 이력의 최신 공고별 자료입니다. 최대 100개 표시하며 검색으로 좁힐 수 있습니다."
