"""No durable upload storage: bounded native text extraction in a timed child."""

import json
import subprocess
import sys
from pathlib import Path


def extract_pdf(data):
    if not isinstance(data, bytes) or not data.startswith(b"%PDF-") or len(data) > 8 * 1024 * 1024:
        raise ValueError("8MiB 이내의 유효한 PDF가 필요합니다.")
    try:
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("pdf_worker.py"))],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=12,
            check=False,
        )
        if result.returncode != 0 or len(result.stdout) > 750000:
            raise ValueError("텍스트 PDF를 읽을 수 없습니다. 자격 부분을 직접 붙여넣어 주세요.")
        text = json.loads(result.stdout.decode("utf-8"))
        if not isinstance(text, str) or not 30 <= len(text.strip()) <= 120000:
            raise ValueError("읽을 수 있는 텍스트가 부족하거나 너무 깁니다.")
        return text
    except (subprocess.TimeoutExpired, OSError, UnicodeError, json.JSONDecodeError) as exc:
        raise ValueError(
            "PDF를 제한 시간 안에 읽지 못했습니다. 자격 부분을 붙여넣어 주세요."
        ) from exc


def extract_official_pdf(data, *, timeout=30):
    """Larger fixed official-only profile; source transport enforces provenance."""
    if not isinstance(data, bytes) or not data.startswith(b"%PDF-") or len(data) > 16 * 1024 * 1024:
        raise ValueError("official_pdf_size_or_signature")
    try:
        result = subprocess.run(
            [sys.executable, str(Path(__file__).with_name("pdf_worker.py")), "--official-housing"],
            input=data,
            stdout=subprocess.PIPE,
            stderr=subprocess.DEVNULL,
            timeout=min(30, max(0.1, timeout)),
            check=False,
        )
        if result.returncode or len(result.stdout) > 5 * 1024 * 1024:
            raise ValueError("official_pdf_unreadable")
        pages = json.loads(result.stdout.decode("utf-8"))
        if (
            not isinstance(pages, list)
            or not 1 <= len(pages) <= 200
            or any(
                not isinstance(p, dict)
                or set(p) != {"page", "text"}
                or p["page"] != i + 1
                or not isinstance(p["text"], str)
                for i, p in enumerate(pages)
            )
            or sum(len(p["text"]) for p in pages) > 800000
        ):
            raise ValueError("official_pdf_invalid_pages")
        return pages
    except (subprocess.TimeoutExpired, OSError, UnicodeError, json.JSONDecodeError):
        raise ValueError("official_pdf_extraction_failed") from None
