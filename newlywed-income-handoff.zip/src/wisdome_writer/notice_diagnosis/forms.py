from django import forms


class SourceForm(forms.Form):
    scope = forms.CharField(
        label="신청할 공급유형·세부자금",
        max_length=120,
        required=False,
        help_text=(
            "예: 일반공급 1순위, 신혼부부 특별공급, 청년고용연계자금. "
            "통합공고는 세부유형을 구분하세요."
        ),
    )
    text = forms.CharField(
        label="추가할 공고문의 자격·제외조건",
        max_length=40000,
        required=False,
        widget=forms.Textarea(attrs={"rows": 7}),
        help_text=(
            "저장된 본문이 부족할 때 해당 신청유형의 자격·제외 부분을 붙여넣으세요. "
            "주민등록번호·연락처는 넣지 마세요."
        ),
    )
    pdf = forms.FileField(
        label="공고문 PDF",
        required=False,
        widget=forms.ClearableFileInput(attrs={"accept": ".pdf"}),
        help_text="선택사항. 8MiB·80쪽 이내 텍스트 PDF. 스캔·암호 PDF와 HWP는 지원하지 않습니다.",
    )
    confirm = forms.BooleanField(
        label="추가한 자료가 선택한 공고와 신청유형에 맞는지 확인했습니다.", required=False
    )

    def __init__(self, *args, events=(), **kwargs):
        super().__init__(*args, **kwargs)
        if events:
            self.fields["event"] = forms.ChoiceField(
                label="확인할 청약 일정",
                required=False,
                choices=[("", "공고의 일반 신청기간")]
                + [(str(i), e["label"] + " · " + e["text"]) for i, e in enumerate(events)],
            )

    def clean(self):
        data = super().clean()
        if data.get("text") and data.get("pdf"):
            raise forms.ValidationError("본문과 PDF 중 하나만 추가해 주세요.")
        if (data.get("text") or data.get("pdf")) and not data.get("confirm"):
            self.add_error("confirm", "자료와 신청유형을 확인해 주세요.")
        upload = data.get("pdf")
        if upload and (upload.size > 8 * 1024 * 1024 or not upload.name.lower().endswith(".pdf")):
            self.add_error("pdf", "8MiB 이내 PDF를 선택해 주세요.")
        return data


class AnswersForm(forms.Form):
    def __init__(self, criteria, *args, **kwargs):
        super().__init__(*args, **kwargs)
        for rule in criteria:
            if rule["kind"] == "number":
                self.fields[rule["id"]] = forms.IntegerField(
                    label=rule["label"] + f" ({rule['unit']})",
                    min_value=0,
                    max_value=rule["maximum"],
                    required=False,
                    help_text=(
                        "공고의 기준일과 산정방식을 적용한 값을 입력하세요. 모르면 비워두세요."
                    ),
                )
            else:
                self.fields[rule["id"]] = forms.ChoiceField(
                    label=rule["label"],
                    required=False,
                    choices=(
                        ("unknown", "확인 필요"),
                        ("yes", "예"),
                        ("no", "아니요"),
                        ("na", "내 유형에 적용되는지 확인 필요"),
                    ),
                )
        self.fields["complete"] = forms.BooleanField(
            required=False,
            label="이 공고의 해당 신청유형과 자격·제외조건 전체를 원문에서 확인했습니다.",
        )


class HousingSourceForm(forms.Form):
    """No required paste/upload in the automatic official housing flow."""

    def __init__(self, *args, scopes=(), events=(), **kwargs):
        super().__init__(*args, **kwargs)
        self.scopes = list(scopes)
        choices = [(s["key"], s["label"]) for s in scopes]
        if len(choices) > 1:
            choices.insert(0, ("", "신청할 유형을 선택하세요"))
        self.fields["scope"] = forms.ChoiceField(
            label="신청할 공급유형",
            choices=choices,
            required=len(scopes) > 1,
            widget=forms.Select if scopes else forms.HiddenInput,
        )
        if events:
            self.fields["event"] = forms.ChoiceField(
                label="확인할 청약 일정",
                required=False,
                choices=[("", "공고의 일반 신청기간")]
                + [(str(i), e["label"] + " · " + e["text"]) for i, e in enumerate(events)],
            )

    def clean_scope(self):
        value = self.cleaned_data.get("scope", "")
        if not value and len(self.scopes) == 1:
            return self.scopes[0]["key"]
        return value
