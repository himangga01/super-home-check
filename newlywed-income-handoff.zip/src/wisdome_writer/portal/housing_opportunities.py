"""Read-only article discovery and reviewed project profiles in the local portal."""

import re
from datetime import datetime

from django.conf import settings
from django.http import Http404, HttpResponseBadRequest, HttpResponseNotAllowed
from django.shortcuts import render

from apps.local_content.dates import SEOUL
from apps.local_content.housing_discovery import load_discovery_inventory, load_projects
from apps.local_content.views import _page_response, _require_local_request

from .housing import load_housing_snapshot


def _identity(title):
    return re.sub(r"\s+", "", title).casefold()


def opportunities(request, slug=None):
    _require_local_request(request)
    if request.method not in {"GET", "HEAD"}:
        return HttpResponseNotAllowed(["GET", "HEAD"])
    query = request.GET.get("q", "").strip()
    if len(query) > 200 or len(request.GET.getlist("q")) > 1:
        return HttpResponseBadRequest("검색어는 하나만, 200자 이내로 입력해 주세요.")
    projects = load_projects()
    project = None
    if slug is not None:
        project = next((p for p in projects if p["slug"] == slug), None)
        if project is None:
            raise Http404
        references = {s["id"]: s for s in project["sources"]}
        project["unit_total"] = sum(row["count"] for row in project["unit_counts"])
        for fact in project["facts"] + project["schedule"]:
            fact["references"] = [references[key] for key in fact["sources"]]
        saved = load_housing_snapshot(query=project["title"])
        aliases = {_identity(a) for a in project["aliases"]}
        project["official_matches"] = [
            row
            for row in saved["notices"]
            if _identity(row["title"]) in aliases
            and row["url"]
            and row.get("category") == project["notice_match"]["category"]
            and row.get("published_on", "") >= project["notice_match"]["published_from"]
        ]
        project["official_inventory_available"] = saved["available"]
    data = load_discovery_inventory(settings.HOUSING_DISCOVERY_ROOT, query=query)
    rows = []
    for item in data["items"]:
        title = _identity(item["title"])
        matching = [p for p in projects if any(_identity(a) in title for a in p["aliases"])]
        if project is not None and project not in matching:
            continue
        rows.append(
            {
                **item,
                "projects": matching,
                "published_on": datetime.fromisoformat(item["published_at"])
                .astimezone(SEOUL)
                .date()
                if item["published_at"]
                else None,
            }
        )
    response = _page_response(
        render(
            request,
            "portal/housing_opportunities.html",
            {
                "project": project,
                "projects": projects,
                "data": data,
                "rows": rows,
                "q": query,
            },
        )
    )
    response["Content-Security-Policy"] = response["Content-Security-Policy"].replace(
        "form-action 'none'",
        "form-action 'self'",
    )
    return response
