from django.urls import path

from wisdome_writer.notice_diagnosis import views as notice_diagnosis

from . import views
from .housing_opportunities import opportunities

urlpatterns = [
    path("", views.home, name="portal-home"),
    path("housing/income/", views.housing_income, name="housing-income"),
    path("housing/", views.housing, name="housing-overview"),
    path("housing/opportunities/", opportunities, name="housing-opportunities"),
    path("housing/opportunities/<slug:slug>/", opportunities, name="housing-opportunity-detail"),
    path(
        "housing/diagnosis/",
        notice_diagnosis.picker,
        {"topic": "housing"},
        name="housing-diagnosis",
    ),
    path(
        "housing/diagnosis/<str:identity>/",
        notice_diagnosis.detail,
        {"topic": "housing"},
        name="housing-notice-diagnosis",
    ),
    path("housing/notices/", views.housing, {"section": "notices"}, name="housing-notices"),
    path("housing/sources/", views.housing, {"section": "sources"}, name="housing-sources"),
    path("ai/", views.ai_information, name="ai-overview"),
    path("ai/news/", views.ai_information, {"section": "news"}, name="ai-news"),
    path("ai/trends/", views.ai_information, {"section": "trends"}, name="ai-trends"),
    path("ai/hot-issues/", views.ai_information, {"section": "hot_issues"}, name="ai-hot-issues"),
    path("ai/tips/", views.ai_information, {"section": "tips"}, name="ai-tips"),
    path("ai/sources/", views.ai_information, {"section": "sources"}, name="ai-sources"),
    path("ai/history/", views.ai_information, {"section": "history"}, name="ai-history"),
    path("semiconductor/", views.semiconductor, name="semiconductor-overview"),
    path(
        "semiconductor/news/", views.semiconductor, {"section": "news"}, name="semiconductor-news"
    ),
    path(
        "semiconductor/articles/",
        views.semiconductor,
        {"section": "articles"},
        name="semiconductor-articles",
    ),
    path(
        "semiconductor/sources/",
        views.semiconductor,
        {"section": "sources"},
        name="semiconductor-sources",
    ),
]
