"""Server-rendered topic inventories; collection remains an explicit operation."""

from django.conf import settings
from django.http import HttpResponseBadRequest, HttpResponseNotAllowed, HttpResponseRedirect
from django.shortcuts import render

from apps.local_content.views import _page_response, _require_local_request
from apps.policy_funding.views import policy_page
from wisdome_writer.notice_diagnosis.sources import housing_link
from wisdome_writer.portal.periods import as_local_date, period_context, selection_from_query


def load_housing_snapshot(query="", period=None, stage="all"):
    from .housing import load_housing_snapshot as load

    return load(query=query, period=period, stage=stage)


def load_ai_inventory(*, period=None, category="", query="", provider=""):
    from apps.ai_information.query import load_ai_inventory as load

    return load(
        settings.AI_INFORMATION_ROOT,
        period=period,
        category=category,
        query=query,
        provider=provider,
    )


@policy_page
def home(request):
    return render(request, "portal/home.html")


def housing_income(request):
    _require_local_request(request)
    if request.method not in {"HEAD", "GET"}:
        return HttpResponseNotAllowed(["GET", "HEAD"])
    return HttpResponseRedirect(settings.STATIC_URL + "income/index.html")


def housing(request, section="overview"):
    _require_local_request(request)
    if request.method not in {"GET", "HEAD"}:
        return HttpResponseNotAllowed(["GET", "HEAD"])
    query = request.GET.get("q", "").strip()
    if len(query) > 200:
        return HttpResponseBadRequest("검색어는 200자 이내로 입력해 주세요.")
    try:
        period = selection_from_query(
            request.GET, default_basis="schedule", allowed_bases=("schedule",)
        )
        stage = request.GET.get("stage", "all")
        if stage not in {"all", "special", "first"} or len(request.GET.getlist("stage")) > 1:
            raise ValueError("청약 단계는 특별공급·1순위 중에서 선택해 주세요.")
    except ValueError as exc:
        return HttpResponseBadRequest(str(exc))
    if section == "sources":
        context = {"section": section}
    else:
        data = (
            load_housing_snapshot(query=query, period=period, stage=stage)
            if period.active or stage != "all"
            else load_housing_snapshot(query=query)
        )
        rows = [{**row, "diagnosis_url": housing_link(row)} for row in data["notices"]]
        context = {"section": section, "data": data, "rows": rows, "q": query}
        context.update(
            period_selection=period,
            period_ui=period_context(
                request,
                period,
                basis_labels={
                    "schedule": "특별공급·1순위 접수 일정",
                },
                available_years=data.get("available_years", ()),
            ),
            selected_stage=stage,
        )
    response = _page_response(render(request, "portal/housing.html", context))
    response["Content-Security-Policy"] = response["Content-Security-Policy"].replace(
        "form-action 'none'", "form-action 'self'"
    )
    return response


AI_CATEGORIES = {
    "news": "AI 뉴스",
    "trends": "트렌드",
    "hot_issues": "핫이슈",
    "tips": "꿀팁",
}


@policy_page
def ai_information(request, section="overview"):
    _require_local_request(request)
    query = request.GET.get("q", "").strip()
    provider = request.GET.get("provider", "")
    requested_category = request.GET.get("category", "")
    category = section if section in AI_CATEGORIES else requested_category
    if (
        len(query) > 200
        or len(provider) > 100
        or requested_category not in {"", *AI_CATEGORIES}
        or any(len(request.GET.getlist(key)) > 1 for key in ("q", "provider", "category"))
    ):
        return HttpResponseBadRequest("검색 조건을 확인해 주세요.")
    try:
        period = selection_from_query(request.GET, allowed_bases=("published",))
        data = load_ai_inventory(period=period, category=category, query=query, provider=provider)
    except ValueError:
        return HttpResponseBadRequest("날짜와 출처 조건을 확인해 주세요.")
    except OSError:
        data = {"items": [], "sources": [], "source_outcomes": [], "total": None}
        data["message"] = "저장된 AI 자료를 불러올 수 없습니다."
    rows = [
        {
            **item,
            "publication_day": as_local_date(item.get("published_at")),
            "capture_day": as_local_date(item.get("captured_at")),
            "category_labels": [AI_CATEGORIES[key] for key in item["categories"]],
        }
        for item in data["items"][:100]
    ]
    source_names = {source["source_id"]: source["name"] for source in data["sources"]}
    statuses = {
        "completed": "수집 완료",
        "partial": "일부 수집",
        "failed": "접근 확인 필요",
        "deferred": "다음 수집 대기",
        "disabled": "수집 제외",
    }
    outcomes = [
        {
            "name": source_names.get(item["source_id"], item["source_id"]),
            "count": item.get("count", 0),
            "status": statuses.get(item["status"], "확인 필요"),
        }
        for item in data.get("source_outcomes", ())
    ]
    period_ui = period_context(
        request,
        period,
        basis_labels={"published": "원문 발표일"},
        available_years=data.get("available_years", ()),
    )
    period_ui["preserved"].extend(
        {"name": key, "value": request.GET[key]}
        for key in ("provider", "category")
        if key in request.GET
    )
    category_query = request.GET.copy()
    category_query.pop("category", None)
    suffix = "?" + category_query.urlencode() if category_query else ""
    categories = [
        {
            "key": key,
            "label": label,
            "href": "/ai/" + key.replace("_", "-") + "/" + suffix,
            "active": category == key,
        }
        for key, label in AI_CATEGORIES.items()
    ]
    headings = {
        "overview": "AI 소식부터 활용법까지, 한곳에서.",
        "news": "새로 나온 AI 소식",
        "trends": "AI 변화의 흐름",
        "hot_issues": "지금 살펴볼 AI 이슈",
        "tips": "직접 활용해 볼 AI 꿀팁",
        "sources": "AI 정보를 전하는 공식 출처",
        "history": "AI 정보 수집 기록",
    }
    return render(
        request,
        "portal/ai.html",
        {
            "section": section,
            "heading": headings[section],
            "q": query,
            "provider": provider,
            "category": category,
            "category_label": AI_CATEGORIES.get(category),
            "categories": categories,
            "data": data,
            "rows": rows,
            "latest_capture_day": as_local_date(data.get("latest_capture")),
            "period_selection": period,
            "period_ui": period_ui,
            "source_outcome_display": outcomes,
            "display_limited": len(data["items"]) > 100,
        },
    )


@policy_page
def semiconductor(request, section="overview"):
    """Redirect retired bookmarks without reading or relabelling their old archive."""
    _require_local_request(request)
    destination = {"news": "/ai/news/", "sources": "/ai/sources/"}.get(section, "/ai/")
    query = request.GET.copy()
    for key in list(query):
        if key not in {"year", "month", "q"}:
            query.pop(key)
    suffix = "?" + query.urlencode() if query else ""
    return HttpResponseRedirect(destination + suffix)
