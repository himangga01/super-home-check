import {profiles,compare} from './rules.mjs';
const pdfLib=()=>import('./vendor/pdf.min.mjs');
const workerURL=new URL('./vendor/pdf.worker.min.mjs',import.meta.url).href;
const $=id=>document.getElementById(id), num=(el,min,max)=>{let n=Number(el.value);if(el.value.trim()===''||!Number.isSafeInteger(n)||n<min||n>max)throw Error('금액(원 단위 정수)과 근무월수(1~12)를 확인하세요.');return n};
let type='',generation=0,busy=0;
function resetResult(){$('result').textContent='';$('confirm').checked=false}
function manualMode(){return !type||$('size').selectedIndex===6}
function layout(){$('manual').hidden=!manualMode(); resetResult()}
function row(role='본인'){
 const f=document.createElement('fieldset'); f.innerHTML='<label>구분 <select class="role"><option>본인</option><option>배우자</option><option>기타 세대원</option></select></label><label>원천징수영수증 PDF <input class="pdf" type="file" accept=".pdf"></label><small class="msg"></small><label>입력 방식 <select class="mode"><option value="annual">세전 총급여 ÷ 근무월수</option><option value="monthly">공고 기준으로 확인한 월소득 직접 입력</option></select></label><label><span class="label">해당 연도 비과세 제외 총급여</span> (원) <input class="amount" type="number" min="0"></label><label class="period">해당 총급여의 근무월수 <input class="months" type="number" min="1" max="12"></label><button class="remove">삭제</button>';
 const q=s=>f.querySelector(s),m=q('.mode');q('.role').value=role;let seq=0;
 function toggle(){const monthly=m.value==='monthly';q('.label').textContent=monthly?'월평균 인정소득':'해당 연도 비과세 제외 총급여';q('.period').hidden=monthly;q('.amount').value='';q('.months').value='';resetResult()}
 m.onchange=()=>{seq++;q('.pdf').value='';q('.msg').textContent='';toggle()};q('.remove').onclick=()=>{seq++;f.remove();resetResult()};
 q('.pdf').onchange=async ev=>{let token=++seq,file=ev.target.files[0];q('.amount').value='';q('.months').value='';q('.msg').textContent='';resetResult();if(!file)return;
 busy++;let doc;try{if(file.size>12*1024*1024)throw Error();const lib=await pdfLib();lib.GlobalWorkerOptions.workerSrc=workerURL;
 doc=await lib.getDocument({data:new Uint8Array(await file.arrayBuffer()),isEvalSupported:false,useSystemFonts:true}).promise;
 const found=new Set();for(let i=1;i<=Math.min(3,doc.numPages);i++){
 const content=await(await doc.getPage(i)).getTextContent();const rows=new Map();
 for(const t of content.items){if(!t.str)continue;const k=Math.round(t.transform[5]/2);if(!rows.has(k))rows.set(k,[]);rows.get(k).push(t)}
 for(const ts of rows.values()){const line=ts.sort((a,b)=>a.transform[4]-b.transform[4]).map(t=>t.str).join(' ').replace(/총\s*급\s*여(?:\s*액)?/g,'총급여');const match=line.match(/(?:㉑|[（(]?21[）).]?|총급여)\s*(?:총급여)?\s*[:：]?\s*([0-9]{1,3}(?:,\d{3})+|[0-9]{5,})(?:\s*원)?\s*$/);if(match&&line.includes('총급여'))found.add(match[1].replaceAll(',',''))}}
 if(token!==seq||!f.isConnected)return;if(found.size!==1)throw Error();m.value='annual';toggle();q('.amount').value=[...found][0];q('.msg').textContent='총급여 후보를 읽었습니다. 귀속연도와 21번 총급여를 원본과 대조하고 근무월수를 입력하세요.';
 }catch{if(token===seq&&f.isConnected)q('.msg').textContent='자동 판독하지 못했습니다. 암호·스캔·복잡한 표는 원본에서 21번 총급여를 직접 입력하세요.'}finally{busy--;if(doc)await doc.destroy()}};
 if(type==='bu'){m.value='monthly';m.disabled=true;q('.pdf').disabled=true;toggle()}$('people').append(f)
}
$('notice').onchange=async ev=>{const token=++generation;$('dual').checked=false;$('limit').value='';type='';layout();$('people').replaceChildren();row();let f=ev.target.files[0];$('noticeStatus').textContent='';if(!f)return;busy++;try{if(f.size>24*1024*1024)throw Error();const hash=Array.from(new Uint8Array(await crypto.subtle.digest('SHA-256',await f.arrayBuffer())),v=>v.toString(16).padStart(2,'0')).join('');if(token!==generation)return;
 const profile=profiles[hash];if(!profile){
 const lib=await pdfLib();lib.GlobalWorkerOptions.workerSrc=workerURL;
 const doc=await lib.getDocument({data:new Uint8Array(await f.arrayBuffer()),isEvalSupported:false,useSystemFonts:true}).promise;
 let hints=[];try{for(let i=1;i<=Math.min(doc.numPages,100);i++){if(token!==generation)return;const page=await doc.getPage(i);const text=(await page.getTextContent()).items.map(x=>x.str||'').join('').replace(/\s/g,'');if(text.includes('신혼부부')&&/월평균소득|소득기준/.test(text))hints.push(i);page.cleanup()}}finally{await doc.destroy()}
 if(token===generation)$('noticeStatus').textContent='미등록 공고입니다. '+(hints.length?'신혼부부·소득 관련 문구가 함께 있는 PDF 쪽: '+hints.join(', ')+'. ':'')+'원본에서 해당 단계와 가구의 상한을 직접 입력하세요.';return;
 }type=profile[1];$('noticeStatus').textContent=profile[0]+' · 검증된 공고 '+profile[2]+'쪽 기준. '+(type==='bu'?'출산가구 완화 전 기본표입니다. 원징 대신 사회보장정보시스템 기준 월소득을 확인해 입력하세요. 부동산·자동차 기준은 별도입니다.':'2025년도 소득 기준. 상시근로자 기본 사례에 적용합니다.');$('people').replaceChildren();row();layout()
 }catch{if(token===generation)$('noticeStatus').textContent='이 버전의 소득표는 검증되지 않았습니다. 신혼부부 특공 표에서 상한을 직접 확인해 입력하세요.'}finally{busy--}};
$('dual').onchange=()=>{if($('dual').checked&&![...document.querySelectorAll('.role')].some(e=>e.value==='배우자'))row('배우자');resetResult()};$('size').onchange=layout;$('add').onclick=()=>row('기타 세대원');$('clear').onclick=()=>location.reload();
document.addEventListener('input',e=>{if(e.target!==$('confirm'))resetResult()});
$('calc').onclick=()=>{try{if(busy)throw Error('문서를 읽는 중입니다.');if(!$('confirm').checked)throw Error('원본과 입력값을 확인한 뒤 확인란을 선택하세요.');
 const entries=[...document.querySelectorAll('fieldset')].map(f=>{const q=s=>f.querySelector(s);return {role:q('.role').value,amount:num(q('.amount'),0,1e12),months:q('.mode').value==='monthly'?1:num(q('.months'),1,12)}});
 const dual=$('dual').checked;let pair=entries.filter(x=>x.role!=='기타 세대원');if(entries.filter(x=>x.role==='본인').length!==1||entries.filter(x=>x.role==='배우자').length>1||dual!==(pair.filter(x=>x.amount>0).length===2))throw Error('본인 1명과 배우자의 소득 유무가 맞벌이 선택과 일치하는지 확인하세요.');
 if(entries.length>($('size').selectedIndex+3)&&$('size').selectedIndex!==6)throw Error('입력한 인원이 가구원 수보다 많습니다.');
 // 27720 is divisible by every integer month count 1..12: compare exact rationals.
 const monthly=x=>x.amount*(27720/x.months);if(entries.some(x=>!Number.isSafeInteger(monthly(x))))throw Error('입력 금액 범위를 확인하세요.');
 const sum=entries.reduce((n,x)=>n+monthly(x),0);if(!Number.isSafeInteger(sum))throw Error('합산액 범위를 확인하세요.');
 const total=sum/27720,limit=manualMode()?num($('limit'),1,1e12):0;
 $('result').textContent='가구 월평균소득: '+total.toLocaleString('ko-KR',{maximumFractionDigits:2})+'원\n'+compare(type,$('size').selectedIndex,dual,total,pair.map(x=>monthly(x)/27720),limit);
 }catch(e){$('result').textContent=e.message}};
row();layout();
