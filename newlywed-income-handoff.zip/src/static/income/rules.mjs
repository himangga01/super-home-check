const bounds={
100:[7533763,8802202,9326985,9906263,10485541,11064819],
120:[9040516,10562642,11192382,11887516,12582649,13277783],
130:[9793892,11442863,12125081,12878142,13631203,14384265],
140:[10547268,12323083,13057779,13868768,14679757,15490747],
160:[12054021,14083523,14923176,15850021,16800866,17703710],
200:[15067526,17604404,18653970,19812526,20971082,22129638]};
export const profiles={
'33d292bef834e3b8c545418a44af58d3ed5655543c677ee07597611e78eda382':['잠실 래미안아이파크 계약취소주택 재공급','jam','8~9'],
'd283f0460ece9fb29ccbbdd968cec5eaa48bff49b7a5f0d0a4fe3ece12e99780':['해링턴 플레이스 문래 민영분양','mun','13~14'],
'b8b15599545e8be87b5d3413e04823a46b6e8867d3bee411a2c52d1b9d944927':['부천대장 A2 공공분양','bu','14~16·22']};
export function compare(type,idx,dual,total,spouses,manual){
 const max=p=>bounds[p][idx],fmt=n=>n.toLocaleString('ko-KR')+'원';
 if(!type||idx===6)return total<=manual?'직접 입력한 상한 이하 (소득만 단순 비교)':'직접 입력한 상한 초과';
 const lines=[];function stage(label,p,eligible){lines.push(label+' '+p+'% ('+fmt(max(p))+')');if(eligible)return lines.join('\n')+'\n→ '+label+' 소득 범위';}
 if(type==='jam')return stage('잠실',dual?160:140,total<=max(dual?160:140))||lines.join('\n')+' 초과: 공고상 부동산가액 3억 3,100만 원 이하 경로 별도 확인';
 const lower=dual?120:100, mid=type==='mun'?(dual?160:140):(dual?140:130);
 const first=stage('우선 단계',lower,total<=max(lower)&&(type!=='mun'||!dual||Math.min(...spouses)<=max(100)));if(first)return first;
 const second=stage('일반 단계',mid,total<=max(mid)&&(type!=='mun'||(total>max(lower)&&(!dual||Math.min(...spouses)<=max(140)))));if(second)return second;
 if(type==='bu')return stage('추첨 단계',dual?200:130,total<=max(dual?200:130))||lines.join('\n')+'\n→ 기본 소득 상한 초과';
 return lines.join('\n')+'\n→ 일반 단계 상한 초과: 추첨 단계 부동산 요건 별도 확인';
}
