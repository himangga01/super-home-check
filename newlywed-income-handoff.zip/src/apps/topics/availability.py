"""Current collection availability, separate from historical topic identities."""

RETIRED_COLLECTION_TOPICS = frozenset({"semiconductor_news"})


def require_collection_topic(topic_code: str) -> None:
    if topic_code in RETIRED_COLLECTION_TOPICS:
        raise ValueError("This collection topic is retired. Use the AI information workspace.")
