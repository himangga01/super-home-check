"""Local AI news and practical-information collection."""
