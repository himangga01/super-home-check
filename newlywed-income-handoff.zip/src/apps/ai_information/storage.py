"""Hash-validated immutable AI runs with frozen source profiles."""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from collections import Counter
from datetime import date, datetime

from apps.local_content.bundles import ArticleBundleWriter, _parse_strict_json_object
from wisdome_writer.portal.news_archive import SEOUL, _ReadOnlyWriter

from .catalog import CATEGORIES, validate_catalog, validate_url
from .feeds import CLASSIFICATION_BASIS, publication_is_future

RUN_NAME = re.compile(r"(\d{4}-\d{2}-\d{2})(?:--run-[a-f0-9]{12})?")
ITEM_KEYS = {
    "title",
    "url",
    "source_id",
    "publisher",
    "published_at",
    "source_date_text",
    "captured_at",
    "categories",
    "summary",
    "classification_basis",
    "provenance",
    "rights_status",
}
OUTCOME_KEYS = {"source_id", "status", "request_count", "count", "error_code", "coverage_limited"}


def encoded(value):
    return json.dumps(
        value, ensure_ascii=False, sort_keys=True, separators=(",", ":"), allow_nan=False
    ).encode()


def digest(value):
    return hashlib.sha256(encoded(value)).hexdigest()


def aware(value):
    if not isinstance(value, str) or len(value) > 40:
        raise ValueError("invalid_ai_timestamp")
    parsed = datetime.fromisoformat(value)
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("invalid_ai_timestamp")
    return parsed


def save_run(root, *, sources, items, outcomes, captured_at, mode, limits):
    writer = ArticleBundleWriter(root)
    day = captured_at.astimezone(SEOUL).date()
    lease = writer.reserve_run_directory(day, workflow_id=uuid.uuid4().hex)
    records = {
        "schema_version": 1,
        "topic": "ai_information",
        "run_name": lease.name,
        "mode": mode,
        "items": items,
    }
    observation = {
        "schema_version": 1,
        "topic": "ai_information",
        "run_name": lease.name,
        "mode": mode,
        "captured_at": captured_at.isoformat(),
        "catalog": list(sources),
        "records_hash": digest(records),
        "source_outcomes": outcomes,
        "coverage_limited": True,
        "limits": limits,
    }
    return writer.write_run(
        day,
        "# AI information collection\n\nBounded official-source metadata.\n",
        run_directory=lease,
        run_files={"notices.json": encoded(records), "raw-observations.json": encoded(observation)},
    )


def read_run(root, name):
    if not isinstance(name, str) or not (match := RUN_NAME.fullmatch(name)):
        raise ValueError("invalid_ai_run_name")
    day = date.fromisoformat(match[1])
    writer = _ReadOnlyWriter(root)
    records = _parse_strict_json_object(
        writer.read_validated_run_file(day, "notices.json", run_directory=name), "AI records"
    )
    obs = _parse_strict_json_object(
        writer.read_validated_run_file(day, "raw-observations.json", run_directory=name),
        "AI observations",
    )
    if set(records) != {"schema_version", "topic", "run_name", "mode", "items"} or set(obs) != {
        "schema_version",
        "topic",
        "run_name",
        "mode",
        "captured_at",
        "catalog",
        "records_hash",
        "source_outcomes",
        "coverage_limited",
        "limits",
    }:
        raise ValueError("invalid_ai_inventory_schema")
    for document in (records, obs):
        if (
            type(document["schema_version"]) is not int
            or document["schema_version"] != 1
            or document["topic"] != "ai_information"
            or document["run_name"] != name
            or not isinstance(document["mode"], str)
            or document["mode"] not in {"live", "fixture"}
        ):
            raise ValueError("invalid_ai_inventory_identity")
    if (
        records["mode"] != obs["mode"]
        or obs["records_hash"] != digest(records)
        or obs["coverage_limited"] is not True
    ):
        raise ValueError("invalid_ai_inventory_hash")
    captured = aware(obs["captured_at"])
    if captured.astimezone(SEOUL).date() != day:
        raise ValueError("invalid_ai_run_date")
    sources = {s["source_id"]: s for s in validate_catalog(obs["catalog"])}
    limits = obs["limits"]
    if (
        not isinstance(limits, dict)
        or set(limits) != {"max_items", "max_requests", "max_seconds"}
        or type(limits["max_items"]) is not int
        or not 1 <= limits["max_items"] <= 300
        or type(limits["max_requests"]) is not int
        or not 1 <= limits["max_requests"] <= 30
        or type(limits["max_seconds"]) is not int
        or not 1 <= limits["max_seconds"] <= 900
        or not isinstance(records["items"], list)
        or len(records["items"]) > limits["max_items"]
    ):
        raise ValueError("invalid_ai_limits")
    seen, counts = set(), Counter()
    for item in records["items"]:
        if (
            not isinstance(item, dict)
            or set(item) != ITEM_KEYS
            or not isinstance(item["source_id"], str)
            or item["source_id"] not in sources
        ):
            raise ValueError("invalid_ai_item")
        source = sources[item["source_id"]]
        if (
            not source["enabled"]
            or item["publisher"] != source["publisher"]
            or item["provenance"] != obs["mode"]
            or item["rights_status"] != "internal_metadata"
            or item["classification_basis"] != CLASSIFICATION_BASIS
        ):
            raise ValueError("invalid_ai_item_origin")
        for key, maximum in (("title", 500), ("summary", 240), ("source_date_text", 100)):
            if (
                not isinstance(item[key], str)
                or len(item[key]) > maximum
                or any(ord(c) < 32 for c in item[key])
            ):
                raise ValueError("invalid_ai_item_text")
        if not item["title"]:
            raise ValueError("invalid_ai_item_title")
        validate_url(
            item["url"], hosts=source["article_hosts"], paths=source["article_paths"], fragment=True
        )
        tags = item["categories"]
        if (
            not isinstance(tags, list)
            or not tags
            or any(not isinstance(t, str) for t in tags)
            or len(tags) != len(set(tags))
            or not set(tags) <= set(CATEGORIES)
        ):
            raise ValueError("invalid_ai_categories")
        observed = aware(item["captured_at"])
        if observed > captured:
            raise ValueError("invalid_ai_capture")
        published = item["published_at"]
        if published is not None:
            if not isinstance(published, str):
                raise ValueError("invalid_ai_publication")
            if len(published) != 10:
                aware(published)
            if publication_is_future(published, observed):
                raise ValueError("invalid_ai_future_publication")
        identity = (item["source_id"], item["url"])
        if identity in seen:
            raise ValueError("duplicate_ai_item")
        seen.add(identity)
        counts[item["source_id"]] += 1
    outcomes = obs["source_outcomes"]
    if not isinstance(outcomes, list) or len(outcomes) != len(sources):
        raise ValueError("invalid_ai_outcomes")
    seen_sources = set()
    for row in outcomes:
        if (
            not isinstance(row, dict)
            or not OUTCOME_KEYS <= set(row)
            or set(row) - OUTCOME_KEYS - {"error_counts"}
            or not isinstance(row["source_id"], str)
            or row["source_id"] not in sources
            or row["source_id"] in seen_sources
            or not isinstance(row["status"], str)
            or row["status"] not in {"completed", "partial", "failed", "deferred", "disabled"}
            or type(row["count"]) is not int
            or row["count"] != counts[row["source_id"]]
            or type(row["request_count"]) is not int
            or not 0 <= row["request_count"] <= limits["max_requests"]
            or row["coverage_limited"] is not True
            or row["error_code"] is not None
            and (
                not isinstance(row["error_code"], str)
                or not re.fullmatch(r"[a-z0-9_]{1,100}", row["error_code"])
            )
        ):
            raise ValueError("invalid_ai_source_outcome")
        errors = row.get("error_counts", {})
        if (
            not isinstance(errors, dict)
            or len(errors) > 20
            or any(
                not isinstance(key, str)
                or not re.fullmatch(r"[a-z0-9_]{1,100}", key)
                or type(value) is not int
                or not 1 <= value <= 2000
                for key, value in errors.items()
            )
        ):
            raise ValueError("invalid_ai_source_error_counts")
        if row["status"] in {"failed", "deferred", "disabled"} and row["count"]:
            raise ValueError("invalid_ai_failure_count")
        if row["status"] == "completed" and row["error_code"] is not None:
            raise ValueError("invalid_ai_success_error")
        seen_sources.add(row["source_id"])
    if sum(row["request_count"] for row in outcomes) > limits["max_requests"]:
        raise ValueError("invalid_ai_request_total")
    return {**obs, "items": records["items"]}
