"""Official-feed HTTPS, runtime robots and persisted source polling reservations."""

from __future__ import annotations

import math
import os
import uuid
from email.utils import parsedate_to_datetime
from urllib.parse import urlsplit
from urllib.robotparser import RobotFileParser

from django.conf import settings

from apps.local_content.bundles import _parse_strict_json_object
from wisdome_writer.infrastructure.http_safety import safe_get, validated_logical_url
from wisdome_writer.portal.news_archive import (
    ExclusiveLock,
    NewsAccessError,
    _read_file,
    _safe_root,
)

FEED_MIMES = {
    "application/rss+xml",
    "application/atom+xml",
    "application/xml",
    "text/xml",
    "text/plain",
}


class FeedFetcher:
    def __init__(self, source, *, state_root, budget, transport=None):
        if not settings.IS_LOCAL_RUNTIME:
            raise ValueError("AI collection requires local runtime")
        self.source, self.budget, self.transport = source, budget, transport
        self.request_count = 0
        self.diagnostic_response = None
        root = _safe_root(state_root, create=True)
        self.lock = ExclusiveLock(root / (source["source_id"] + ".lock"))
        self.ledger = root / (source["source_id"] + ".json")
        self.state = None

    def _save(self):
        import json

        temporary = self.ledger.with_name(self.ledger.name + "." + uuid.uuid4().hex + ".tmp")
        with temporary.open("xb") as stream:
            stream.write(json.dumps(self.state, allow_nan=False).encode())
            stream.flush()
            os.fsync(stream.fileno())
        if self.ledger.exists():
            _read_file(self.ledger)
        os.replace(temporary, self.ledger)

    def _reserve(self):
        self.lock.acquire()
        try:
            state = (
                _parse_strict_json_object(_read_file(self.ledger), "AI poll ledger")
                if self.ledger.exists()
                else {"last_request": None, "poll_until": 0}
            )
            if set(state) != {"last_request", "poll_until"}:
                raise ValueError("invalid_ai_poll_state")
            for key, value in state.items():
                if key == "last_request" and value is None:
                    continue
                if type(value) not in {float, int} or not math.isfinite(value) or value < 0:
                    raise ValueError("invalid_ai_poll_state")
            now = self.budget.clock.time()
            if state["poll_until"] > now:
                raise NewsAccessError("source_poll_interval_reserved")
            self.state = {**state, "poll_until": now + self.source["poll_seconds"]}
            self._save()
        except BaseException:
            self.lock.close()
            raise

    def _claim(self):
        last = self.state["last_request"]
        delay = 0 if last is None else max(0, last + 1 - self.budget.clock.time())
        if delay >= self.budget.remaining():
            raise NewsAccessError("source_time_budget_exhausted")
        if delay:
            self.budget.clock.sleep(delay)
        self.budget.claim()
        self.request_count += 1
        self.state["last_request"] = self.budget.clock.time()
        self._save()

    def _backoff(self, response):
        if response.status_code not in {429, 503}:
            return
        value = response.headers.get("Retry-After", "").strip()
        if not value or len(value) > 100:
            return
        now = self.budget.clock.time()
        try:
            if value.isascii() and value.isdigit():
                until = now + int(value)
            else:
                parsed = parsedate_to_datetime(value)
                if parsed.tzinfo is None:
                    return
                until = parsed.timestamp()
        except (ValueError, TypeError, OverflowError):
            return
        if math.isfinite(until) and until > self.state["poll_until"]:
            self.state["poll_until"] = until
            self._save()

    def get(self):
        self._reserve()
        entry = self.source["entry_url"]
        origin = urlsplit(entry)
        robots_url = "https://" + origin.netloc + "/robots.txt"
        robots = None
        for url, is_robots in ((robots_url, True), (entry, False)):

            def validate(target, expected=url, policy=robots):
                if target != expected:
                    raise ValueError("unreviewed_feed_redirect")
                if policy is not None and not policy.can_fetch("WisdomeAIResearch", target):
                    raise NewsAccessError("source_robots_denied")

            validate(url)
            remaining = min(25.0, self.budget.remaining())
            response = safe_get(
                url,
                max_bytes=128 * 1024 if is_robots else 4 * 1024 * 1024,
                timeout=remaining,
                max_elapsed_seconds=remaining,
                allowed_hosts={origin.hostname},
                https_only=True,
                max_redirects=0,
                url_validator=validate,
                before_request=self._claim,
                headers={"User-Agent": "WisdomeAIResearch/1.0", "Accept-Encoding": "identity"},
                allowed_content_types=(
                    {"text/plain", "text/html"}
                    if is_robots
                    else FEED_MIMES | {"text/html", "application/json"}
                ),
                transport=self.transport,
            )
            self.diagnostic_response = {
                "stage": "robots" if is_robots else "feed",
                "status": response.status_code,
                "content_type": response.headers.get("Content-Type", "").split(";", 1)[0][:80],
                "content": response.content,
            }
            if is_robots and response.status_code == 404:
                continue
            self._backoff(response)
            if response.status_code != 200:
                raise NewsAccessError("source_http_" + str(response.status_code))
            if validated_logical_url(response) != url:
                raise ValueError("source_identity_changed")
            if is_robots:
                if b"<html" in response.content.lower() or b"<!doctype" in response.content.lower():
                    raise NewsAccessError("source_robots_invalid")
                robots = RobotFileParser()
                robots.parse(response.content.decode("utf-8", errors="strict").splitlines())
            else:
                mime = response.headers.get("Content-Type", "").split(";", 1)[0].strip().lower()
                if mime not in FEED_MIMES:
                    raise NewsAccessError("source_feed_mime_rejected")
                return response.content
        raise ValueError("feed_not_read")

    def close(self):
        self.lock.close()
