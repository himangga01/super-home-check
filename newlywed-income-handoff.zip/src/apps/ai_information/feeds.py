"""Bounded RSS/Atom metadata extraction with explicit thematic classification."""

from __future__ import annotations

import re
from datetime import UTC, date, datetime, timedelta
from email.utils import parsedate_to_datetime
from urllib.parse import urljoin

from defusedxml import ElementTree
from defusedxml.common import DefusedXmlException
from lxml import html

from .catalog import validate_url

CLASSIFICATION_BASIS = "원문 제목·요약의 키워드로 분류한 주제이며 인기 순위가 아닙니다."
RULES = {
    "trends": (
        r"trend|research|report|survey|benchmark|state of|ecosystem|adoption|"
        r"트렌드|동향|연구|보고서"
    ),
    "hot_issues": (
        r"launch|introduc|release|announc|deprecat|retir|security|safety|policy|"
        r"pricing|available|출시|발표|보안|정책|가격"
    ),
    "tips": (
        r"\bhow\b|tutorial|guide|\btips?\b|cookbook|best practices|getting started|"
        r"learn|build|workflow|활용|꿀팁|가이드|튜토리얼|방법"
    ),
}


def publication_is_future(value, observed):
    if len(value) == 10:
        # A day-only source has no known zone. Allow the latest calendar date
        # possible anywhere on Earth rather than inventing midnight UTC.
        latest_day = (observed.astimezone(UTC) + timedelta(hours=14)).date()
        return date.fromisoformat(value) > latest_day
    return datetime.fromisoformat(value) > observed


def publication_sort_key(item):
    value = item["published_at"]
    if value is None:
        return ("", "", item["url"])
    if len(value) == 10:
        return (value, "", item["url"])
    instant = datetime.fromisoformat(value).astimezone(UTC)
    return (instant.date().isoformat(), instant.isoformat(), item["url"])


def plain_text(value: str, limit: int) -> str:
    if not value:
        return ""
    try:
        node = html.fromstring("<div>" + value[:100000] + "</div>")
        for child in node.xpath(".//script|.//style"):
            child.drop_tree()
        value = node.text_content()
    except (ValueError, TypeError):
        value = ""
    return " ".join(value.replace("<", "‹").replace(">", "›").split())[:limit]


def publication(value, precision):
    if not value:
        return None
    value = value.strip()
    try:
        if re.fullmatch(r"\d{4}-\d{2}-\d{2}", value):
            return date.fromisoformat(value).isoformat()
        try:
            parsed = datetime.fromisoformat(value.replace("Z", "+00:00"))
        except ValueError:
            parsed = parsedate_to_datetime(value)
        if parsed.tzinfo is None:
            return None
        return parsed.date().isoformat() if precision == "day" else parsed.isoformat()
    except (ValueError, TypeError, OverflowError):
        return None


def parse_feed(
    source, payload: bytes, *, captured_at: datetime, mode: str, errors=None
) -> list[dict]:
    if len(payload) > 4 * 1024 * 1024:
        raise ValueError("feed_size_exceeded")
    try:
        root = ElementTree.fromstring(payload)
    except (ElementTree.ParseError, DefusedXmlException) as exc:
        raise ValueError("feed_xml_invalid") from exc
    if root.tag.rsplit("}", 1)[-1].lower() not in {"rss", "feed", "rdf"}:
        raise ValueError("invalid_feed_root")
    entries = [
        node for node in root.iter() if node.tag.rsplit("}", 1)[-1].lower() in {"entry", "item"}
    ]
    if len(entries) > 2000:
        raise ValueError("feed_entry_bound_exceeded")
    items, seen = [], set()
    for entry in entries:
        try:
            item = _entry(source, entry, captured_at=captured_at, mode=mode)
        except ValueError as exc:
            if errors is None:
                raise
            errors.append(str(exc))
            continue
        if item["url"] not in seen:
            seen.add(item["url"])
            items.append(item)
    return items


def _entry(source, entry, *, captured_at, mode):
    fields = {}
    links = []
    permalink = None
    for child in entry:
        name = child.tag.rsplit("}", 1)[-1].lower()
        if name == "link" and child.get("rel", "alternate") == "alternate":
            links.append(child.get("href") or child.text or "")
        if name == "guid" and child.get("isPermaLink", "true").lower() == "true":
            permalink = child.text
        fields.setdefault(name, "".join(child.itertext()).strip())
    if not links and permalink:
        links.append(permalink)
    if not links or not links[0].strip():
        raise ValueError("feed_missing_source_link")
    url = urljoin(source["entry_url"], links[0].strip())
    validate_url(url, hosts=source["article_hosts"], paths=source["article_paths"], fragment=True)
    title = plain_text(fields.get("title", ""), 500)
    if not title:
        raise ValueError("feed_missing_title")
    raw_date = " ".join(
        (fields.get("pubdate") or fields.get("published") or fields.get("date") or "").split()
    )[:100]
    published = publication(raw_date, source["date_precision"])
    if published and publication_is_future(published, captured_at):
        raise ValueError("future_publication_requires_review")
    summary = plain_text(fields.get("summary") or fields.get("description", ""), 240)
    combined = title + " " + summary
    categories = ["news"] + [
        key for key, pattern in RULES.items() if re.search(pattern, combined, re.I)
    ]
    return {
        "title": title,
        "url": url,
        "source_id": source["source_id"],
        "publisher": source["publisher"],
        "published_at": published,
        "source_date_text": raw_date,
        "captured_at": captured_at.isoformat(),
        "categories": categories,
        "summary": summary,
        "classification_basis": CLASSIFICATION_BASIS,
        "provenance": mode,
        "rights_status": source["rights_status"],
    }
