"""Reviewed public feed profiles, also frozen inside each immutable observation."""

from __future__ import annotations

import re
from pathlib import Path
from urllib.parse import urlsplit

from django.conf import settings

from apps.local_content.bundles import _parse_strict_json_object

CATEGORIES = {"news": "뉴스", "trends": "트렌드", "hot_issues": "핫이슈", "tips": "꿀팁"}
SOURCE_KEYS = {
    "source_id",
    "name",
    "publisher",
    "entry_url",
    "article_hosts",
    "article_paths",
    "enabled",
    "access_note",
    "poll_seconds",
    "date_precision",
    "rights_status",
}


def validate_url(value: str, *, hosts, paths=None, fragment=False) -> str:
    if not isinstance(value, str) or not 1 <= len(value) <= 2000:
        raise ValueError("invalid_source_url")
    parts = urlsplit(value)
    if (
        parts.scheme != "https"
        or parts.hostname not in hosts
        or parts.username
        or parts.password
        or parts.port not in {None, 443}
        or (parts.fragment and not fragment)
        or any(ord(c) < 33 for c in value)
        or "\\" in value
        or (paths is not None and not any(parts.path.startswith(p) for p in paths))
    ):
        raise ValueError("invalid_source_url")
    return value


def validate_catalog(sources) -> tuple[dict, ...]:
    if not isinstance(sources, (list, tuple)) or not 1 <= len(sources) <= 20:
        raise ValueError("invalid_ai_catalog")
    seen = set()
    for source in sources:
        if not isinstance(source, dict) or set(source) != SOURCE_KEYS:
            raise ValueError("invalid_ai_source")
        key = source["source_id"]
        if (
            not isinstance(key, str)
            or not re.fullmatch(r"[a-z][a-z0-9_]{0,60}", key)
            or key in seen
        ):
            raise ValueError("invalid_ai_source_identity")
        seen.add(key)
        for field in ("name", "publisher", "access_note"):
            if not isinstance(source[field], str) or not 1 <= len(source[field]) <= 500:
                raise ValueError("invalid_ai_source_text")
        if (
            type(source["enabled"]) is not bool
            or type(source["poll_seconds"]) is not int
            or not 60 <= source["poll_seconds"] <= 86400
            or not isinstance(source["date_precision"], str)
            or source["date_precision"] not in {"day", "instant"}
            or source["rights_status"] != "internal_metadata"
        ):
            raise ValueError("invalid_ai_source_policy")
        for field in ("article_hosts", "article_paths"):
            if not isinstance(source[field], list) or not 1 <= len(source[field]) <= 8:
                raise ValueError("invalid_ai_url_profile")
        if any(
            not isinstance(h, str) or not re.fullmatch(r"[a-z0-9.-]+\.[a-z]+", h)
            for h in source["article_hosts"]
        ):
            raise ValueError("invalid_ai_hosts")
        if any(
            not isinstance(p, str) or not p.startswith("/") or len(p) > 200
            for p in source["article_paths"]
        ):
            raise ValueError("invalid_ai_paths")
        validate_url(source["entry_url"], hosts=source["article_hosts"])
    return tuple(sources)


def load_catalog(path: Path | None = None) -> tuple[dict, ...]:
    path = path or settings.REPOSITORY_ROOT / "config/ai-information/sources.json"
    data = _parse_strict_json_object(Path(path).read_bytes(), "AI catalog")
    if (
        set(data) != {"schema_version", "sources"}
        or type(data["schema_version"]) is not int
        or data["schema_version"] != 1
    ):
        raise ValueError("invalid_ai_catalog")
    return validate_catalog(data["sources"])
