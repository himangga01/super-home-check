"""Read-only local inventory, preserving evidence across bounded collections."""

from __future__ import annotations

import os

from django.conf import settings

from wisdome_writer.portal.news_archive import _safe_root
from wisdome_writer.portal.periods import PeriodSelection, as_local_date

from .catalog import CATEGORIES, load_catalog
from .storage import RUN_NAME, aware, read_run


def load_ai_inventory(root, *, period=None, category="", query="", provider=""):
    if not settings.IS_LOCAL_RUNTIME:
        raise ValueError("AI inventory requires local runtime")
    if (
        not isinstance(category, str)
        or category
        and category not in CATEGORIES
        or not isinstance(query, str)
        or len(query) > 200
        or not isinstance(provider, str)
        or len(provider) > 60
    ):
        raise ValueError("invalid_ai_query")
    period = period or PeriodSelection()
    if period.basis != "published":
        raise ValueError("AI periods use source publication dates")
    sources = load_catalog()
    if provider and provider not in {s["source_id"] for s in sources}:
        raise ValueError("unknown_ai_provider")
    root = _safe_root(root)
    result = {
        "items": [],
        "sources": list(sources),
        "source_outcomes": [],
        "runs": [],
        "available_years": [],
        "unknown_date_count": 0,
        "coverage_limited": True,
        "latest_capture": None,
        "total": 0,
        "invalid_run_count": 0,
        "history_limited": False,
        "mode": "live",
        "available": True,
        "category_counts": dict.fromkeys(CATEGORIES, 0),
    }
    if not root.exists():
        return result
    names = []
    with os.scandir(root) as entries:
        for count, entry in enumerate(entries, 1):
            if count > 2048:
                result["history_limited"] = True
                break
            if RUN_NAME.fullmatch(entry.name):
                names.append(entry.name)
    runs = []
    for name in names:
        try:
            run = read_run(root, name)
            if run["mode"] == "live":
                runs.append(run)
        except (ValueError, OSError):
            result["invalid_run_count"] += 1
    runs.sort(key=lambda run: (aware(run["captured_at"]), run["run_name"]), reverse=True)
    all_items, selected, outcomes = {}, {}, {}
    historical_sources = {s["source_id"]: s for s in sources}
    for run in runs:
        result["runs"].append(
            {
                "run_name": run["run_name"],
                "captured_at": run["captured_at"],
                "count": len(run["items"]),
                "source_outcomes": run["source_outcomes"],
            }
        )
        for source in run["catalog"]:
            historical_sources.setdefault(source["source_id"], source)
        for row in run["source_outcomes"]:
            outcomes.setdefault(row["source_id"], {**row, "captured_at": run["captured_at"]})
        for item in run["items"]:
            identity = (item["source_id"], item["url"])
            all_items.setdefault(identity, item)
            if period.matches(item["published_at"]):
                selected.setdefault(identity, {**item, "run_name": run["run_name"]})
    terms = query.strip().casefold()
    visible = [
        item
        for item in selected.values()
        if (not category or category in item["categories"])
        and (not provider or item["source_id"] == provider)
        and (
            not terms
            or terms in (item["title"] + " " + item["publisher"] + " " + item["summary"]).casefold()
        )
    ]
    visible.sort(
        key=lambda item: (
            str(as_local_date(item["published_at"]) or ""),
            item["captured_at"],
            item["url"],
        ),
        reverse=True,
    )
    years = {
        as_local_date(item["published_at"]).year
        for item in all_items.values()
        if item["published_at"]
    }
    result.update(
        items=visible,
        sources=list(historical_sources.values()),
        source_outcomes=list(outcomes.values()),
        available_years=sorted(years),
        unknown_date_count=sum(item["published_at"] is None for item in all_items.values()),
        latest_capture=runs[0]["captured_at"] if runs else None,
        total=None if result["history_limited"] or result["invalid_run_count"] else len(visible),
    )
    result["category_counts"] = {
        key: sum(key in item["categories"] for item in selected.values()) for key in CATEGORIES
    }
    result["available"] = bool(runs) or not result["invalid_run_count"]
    return result
