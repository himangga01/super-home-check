"""Explicit local collection with truthful bounded source outcomes."""

from __future__ import annotations

import hashlib
import json
import re
from collections import Counter
from datetime import UTC, datetime

from django.conf import settings

from wisdome_writer.infrastructure.http_safety import HttpSafetyError
from wisdome_writer.portal.news_archive import ExclusiveLock, RequestBudget, _safe_root

from .catalog import load_catalog
from .feeds import parse_feed, publication_sort_key
from .storage import read_run, save_run
from .transport import FeedFetcher


def _error_code(exc):
    candidate = getattr(exc, "code", str(exc))
    if isinstance(candidate, str) and re.fullmatch(r"[a-z0-9_]{1,100}", candidate):
        return candidate
    return "source_" + type(exc).__name__.lower()


def _save_diagnostic(root, source, response, payload, mode):
    """Keep bounded replay evidence outside public immutable inventories."""
    if response is None:
        response = {"stage": "feed", "status": None, "content_type": None, "content": payload}
    content = response["content"]
    if not isinstance(content, bytes) or len(content) > 4 * 1024 * 1024:
        return
    path = _safe_root(root, create=True)
    body_path = path / (source["source_id"] + ".bin")
    with body_path.open("xb") as stream:
        stream.write(content)
    metadata = {
        "mode": mode,
        "recorded_at": datetime.now(UTC).isoformat(),
        "source_id": source["source_id"],
        "entry_url": source["entry_url"],
        "stage": response["stage"],
        "status": response["status"],
        "content_type": response["content_type"],
        "size_bytes": len(content),
        "sha256": hashlib.sha256(content).hexdigest(),
    }
    with body_path.with_suffix(".json").open("x", encoding="utf-8") as stream:
        json.dump(metadata, stream, ensure_ascii=False, indent=2)


def collect_ai_information(
    root,
    *,
    source_ids=None,
    max_items=140,
    max_seconds=180,
    fetcher_factory=None,
    now=None,
    diagnostic_root=None,
):
    if not settings.IS_LOCAL_RUNTIME:
        raise ValueError("AI collection requires local runtime")
    if (
        type(max_items) is not int
        or not 1 <= max_items <= 300
        or type(max_seconds) is not int
        or not 1 <= max_seconds <= 900
    ):
        raise ValueError("invalid_ai_collection_limits")
    sources = load_catalog()
    if source_ids:
        selected = set(source_ids)
        if not selected <= {s["source_id"] for s in sources}:
            raise ValueError("unknown_ai_source")
        sources = tuple(s for s in sources if s["source_id"] in selected)
    fixture = fetcher_factory is not None
    factory = fetcher_factory if fixture else FeedFetcher
    if not callable(factory):
        raise ValueError("invalid_ai_fetcher")
    mode = "fixture" if fixture else "live"
    captured = now or datetime.now(UTC)
    if captured.tzinfo is None:
        raise ValueError("invalid_ai_capture")
    if now is not None and not fixture:
        raise ValueError("live_capture_time_cannot_be_overridden")
    if diagnostic_root is not None:
        diagnostic_root = _safe_root(diagnostic_root)
        state_root = _safe_root(settings.LOCAL_STATE_ROOT)
        if not diagnostic_root.is_relative_to(state_root) or diagnostic_root == state_root:
            raise ValueError("AI diagnostics require a private state subdirectory")
    budget = RequestBudget(30, max_seconds)
    root = _safe_root(root, create=True)
    # A proportional per-source cap lets every selected provider participate.
    per_source = max(1, max_items // len(sources))
    items, outcomes = [], []
    with ExclusiveLock(root / ".collection.lock"):
        for source in sources:
            fetcher = None
            payload = None
            outcome = {
                "source_id": source["source_id"],
                "status": "completed",
                "count": 0,
                "request_count": 0,
                "error_code": None,
                "coverage_limited": True,
                "error_counts": {},
            }
            if not source["enabled"]:
                outcome["status"] = "disabled"
            elif len(items) >= max_items:
                outcome.update(status="deferred", error_code="record_limit_reached")
            else:
                try:
                    budget.remaining()
                    fetcher = factory(
                        source,
                        state_root=settings.LOCAL_STATE_ROOT / "ai-information-http",
                        budget=budget,
                    )
                    payload = fetcher.get()
                    observed = captured if fixture else datetime.now(UTC)
                    rejected = []
                    parsed = parse_feed(
                        source, payload, captured_at=observed, mode=mode, errors=rejected
                    )
                    parsed.sort(key=publication_sort_key, reverse=True)
                    outcome["error_counts"] = dict(
                        Counter(_error_code(ValueError(code)) for code in rejected)
                    )
                    accepted = parsed[: min(per_source, max_items - len(items))]
                    items.extend(accepted)
                    outcome["count"] = len(accepted)
                    if len(parsed) > len(accepted):
                        outcome.update(status="partial", error_code="record_limit_reached")
                    if rejected:
                        outcome.update(
                            status="partial" if accepted else "failed",
                            error_code="source_entries_rejected",
                        )
                except (ValueError, HttpSafetyError, OSError) as exc:
                    code = _error_code(exc)
                    outcome.update(
                        status="deferred" if code == "source_poll_interval_reserved" else "failed",
                        error_code=code,
                    )
                finally:
                    if fetcher is not None:
                        outcome["request_count"] = fetcher.request_count
                        try:
                            if diagnostic_root is not None:
                                _save_diagnostic(
                                    diagnostic_root,
                                    source,
                                    getattr(fetcher, "diagnostic_response", None),
                                    payload,
                                    mode,
                                )
                        finally:
                            fetcher.close()
            outcomes.append(outcome)
        finished = captured if fixture else datetime.now(UTC)
        path = save_run(
            root,
            sources=sources,
            items=items,
            outcomes=outcomes,
            captured_at=finished,
            mode=mode,
            limits={"max_items": max_items, "max_requests": 30, "max_seconds": max_seconds},
        )
        read_run(root, path.name)
        return path
