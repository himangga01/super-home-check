"""Ephemeral signed POST wizard; no session/database/external writes."""

from django import forms
from django.conf import settings
from django.core import signing
from django.http import HttpResponseBadRequest
from django.shortcuts import render
from django.utils import timezone

from apps.policy_funding.grant_diagnosis import NOTICE_URL, PDF_URL, diagnose
from apps.policy_funding.grant_forms import FORMS, STAGE_TITLES
from apps.policy_funding.grant_refresh import grant_snapshot
from apps.policy_funding.views import policy_page

STATE_SALT = "policy-funding.business-grant.v1"
STATE_MAX_AGE = 7200
STATE_MAX_SIZE = 16384


def _read_state(value):
    if not value or len(value) > STATE_MAX_SIZE:
        raise ValueError("Invalid state size")
    state = signing.loads(value, salt=STATE_SALT, max_age=STATE_MAX_AGE)
    if not isinstance(state, dict) or set(state) != {"stage", "answers"}:
        raise ValueError("Invalid state shape")
    if type(state["stage"]) is not int or not 0 <= state["stage"] < len(FORMS):
        raise ValueError("Invalid stage")
    if not isinstance(state["answers"], dict):
        raise ValueError("Invalid answers")
    known = {name for form in FORMS for name in form.base_fields}
    if set(state["answers"]) - known:
        raise ValueError("Unexpected answers")
    return state


def _post_answers(post, form_class):
    data = {}
    for name, field in form_class.base_fields.items():
        value = (
            post.getlist(name)
            if isinstance(field, forms.MultipleChoiceField)
            else post.get(name, "")
        )
        items = value if isinstance(value, list) else [value]
        if len(items) > 10 or any(len(item) > 1000 for item in items):
            raise ValueError("Oversize answer")
        data[name] = value
    return data


def _page(request, stage, answers, form=None, result=None):
    state_token = signing.dumps({"stage": stage, "answers": answers}, salt=STATE_SALT)
    if len(state_token) > STATE_MAX_SIZE:
        return HttpResponseBadRequest("응답이 너무 깁니다. 처음부터 다시 진단해 주세요.")
    return render(
        request,
        "policy_funding/diagnosis.html",
        {
            "form": form if form is not None else FORMS[stage](initial=answers),
            "stage": stage,
            "stage_number": stage + 1,
            "stage_title": STAGE_TITLES[stage],
            "stages": STAGE_TITLES,
            "state_token": state_token,
            "result": result,
            "notice_url": NOTICE_URL,
            "pdf_url": PDF_URL,
            "grant_update": grant_snapshot(
                settings.POLICY_FUNDING_ROOT, as_of=timezone.localdate()
            ),
        },
    )


@policy_page(allow_post=True)
def diagnosis(request):
    if request.method != "POST":
        return _page(request, 0, {})
    try:
        state = _read_state(request.POST.get("state", ""))
        action = request.POST.get("action")
        if action not in {"next", "back", "edit"}:
            raise ValueError("Invalid action")
        stage, answers = state["stage"], state["answers"]
        if action == "edit":
            return _page(request, stage, answers)
        current = _post_answers(request.POST, FORMS[stage])
        answers = {**answers, **current}
        if action == "back":
            return _page(request, max(0, stage - 1), answers)
        form = FORMS[stage](current)
        if not form.is_valid():
            return _page(request, stage, answers, form=form)
        if stage < len(FORMS) - 1:
            return _page(request, stage + 1, answers)
        cleaned = {}
        for form_class in FORMS:
            previous = form_class(answers)
            if not previous.is_valid():
                raise ValueError("Incomplete earlier stage")
            cleaned.update(previous.cleaned_data)
        return _page(request, stage, answers, result=diagnose(cleaned))
    except (signing.BadSignature, ValueError, TypeError):
        return HttpResponseBadRequest(
            "진단 응답을 확인할 수 없거나 2시간이 지났습니다. 처음부터 다시 진단해 주세요."
        )
