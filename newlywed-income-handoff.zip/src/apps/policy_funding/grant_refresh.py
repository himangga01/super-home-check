"""Bounded source parsing for the two grant tracks; no eligibility lookup."""

import re
from datetime import date, datetime
from urllib.parse import parse_qs, urlsplit

from apps.policy_funding.catalog import source_by_id
from apps.policy_funding.parsing import NoticeLink, _date, _text, _tree, parse_bizinfo_detail
from apps.policy_funding.storage import list_runs
from apps.policy_funding.transport import OfficialFundingFetcher

SOURCE_ID = "bizinfo_business_grants"
TARGET_IDS = ("PBLN_000000000121227", "PBLN_000000000120120")
BASE_URL = "https://www.bizinfo.go.kr/sii/siia/selectSIIA200Detail.do?pblancId="


def parse_target_grant(body: str, url: str, *, fetched_at: datetime):
    source_by_id(SOURCE_ID).validate_url(url)
    parts = urlsplit(url)
    query = parse_qs(parts.query, strict_parsing=True)
    identities = query.get("pblancId")
    if (
        parts.path != "/sii/siia/selectSIIA200Detail.do"
        or set(query) != {"pblancId"}
        or not identities
        or len(identities) != 1
        or identities[0] not in TARGET_IDS
    ):
        raise ValueError("Unexpected business grant identity")
    tree = _tree(body)
    title = _text(tree.css_first("h2.title"))
    if not all(term in title for term in ("2026", "소상공인 도약", "로컬기업", "강한소상공인")):
        raise ValueError("Not the reviewed grant program")
    published = _date(_text(tree.css_first(".top_info > ul > li")))
    row = parse_bizinfo_detail(
        body,
        NoticeLink(identities[0], title, url, published),
        fetched_at=fetched_at,
        listing_state="unknown",
        source_id=SOURCE_ID,
    )
    if row.issuer != "중소벤처기업부":
        raise ValueError("Unexpected grant issuer")
    return row


def collect_target_grants(limits, *, fetcher=None):
    from apps.policy_funding.collectors import CollectionOutcome

    fetcher = (
        fetcher
        if fetcher is not None
        else OfficialFundingFetcher(
            source_by_id(SOURCE_ID), max_requests=6, max_seconds=limits.seconds
        )
    )
    rows, errors = [], []
    for identity in TARGET_IDS[: limits.notices]:
        requested = BASE_URL + identity
        try:
            page = fetcher.get(requested)
            if page.url != requested:
                raise ValueError("Business-grant redirect changed identity")
            rows.append(parse_target_grant(page.text, page.url, fetched_at=page.fetched_at))
        except Exception as exc:
            errors.append(f"detail:{identity}:{type(exc).__name__}")
    status = "partial" if errors and rows else "failed" if errors else "completed"
    return CollectionOutcome(
        SOURCE_ID, tuple(rows), status, tuple(errors), fetcher.request_count, True
    )


def _period_label(period, as_of):
    matches = re.findall(r"\b20\d{2}[.\-/]\s*\d{1,2}[.\-/]\s*\d{1,2}\b", period or "")
    if len(matches) != 2:
        return "신청기간 확인 필요"
    try:
        start, end = (_date(value) for value in matches)
        if start > end:
            return "신청기간 확인 필요"
        return (
            "공고상 접수기간 종료"
            if as_of > end
            else "공고상 접수기간 전"
            if as_of < start
            else "공고상 접수기간 중"
        )
    except ValueError:
        return "신청기간 확인 필요"


def grant_snapshot(root, *, as_of: date):
    try:
        for run in list_runs(root, limit=100):
            if run["mode"] != "live":
                continue
            outcomes = [item for item in run["source_outcomes"] if item["source_id"] == SOURCE_ID]
            if not outcomes:
                continue
            rows = [row for row in run["notices"] if row.source_id == SOURCE_ID]
            return dict(
                available=bool(rows),
                status=outcomes[0]["status"],
                as_of=run["run_date"],
                captured_at=run["captured_at"],
                run_name=run["run_name"],
                notices=[
                    dict(notice=row, period_label=_period_label(row.application_period, as_of))
                    for row in rows
                ],
                coverage_limited=True,
            )
    except (ValueError, OSError):
        return dict(available=False, status="unavailable", notices=[])
    return dict(available=False, status="not_collected", notices=[])
