"""Recipient-side store support; supplied consultant claims never become rules."""

import json
import re
from datetime import date
from pathlib import Path
from urllib.parse import parse_qs, urlsplit

SOURCE_ID = "bizinfo_store_support"
KINDS = {"store_security", "smart_store", "facility_improvement", "in_kind_support"}
DEFAULT_KEYWORDS = ("무인점포", "스마트상점", "경영환경개선", "희망팩")
DETAIL_BASE = "https://www.bizinfo.go.kr/sii/siia/selectSIIA200Detail.do?pblancId="
REFERENCES = (
    Path(__file__).resolve().parents[3] / "config/policy-funding/store-support-references.json"
)


class NotStoreRecipientNotice(ValueError):
    """Intentional scope exclusion, not a malformed official response."""


def store_support_kinds(title, evidence):
    heading = re.sub(r"\s+", "", title)
    material = re.sub(r"\s+", "", title + evidence).casefold()
    body = re.sub(r"\s+", "", evidence).casefold()
    if re.search(
        r"(?:스마트기술을공급하는|기술공급|솔루션공급)(?:기업|업체)(?:을|를|만)?모집"
        r"|(?:^|[.!?。:;]|☞)(?:소상공인점주|점주|점포운영자)(?:는|은|가|이)?"
        r"(?:신청|지원)?대상이(?:아니|아님|아닙)"
        r"|(?:융자|대출)(?:로지원|방식으로지원|형|자금을지원)",
        body,
    ):
        return ()
    if any(
        term in heading
        for term in (
            "공급기업",
            "공급업체",
            "공급사",
            "수행기관",
            "운영기관",
            "컨소시엄",
            "입찰",
            "조달",
            "보도자료",
            "업무협약",
            "성과공유",
            "기술기업모집",
            "가맹본부",
            "연구개발",
            "기술개발",
            "융자",
            "대출",
        )
    ):
        return ()
    if not any(term in heading for term in ("지원", "모집", "보급", "신청", "참여", "공고")):
        return ()
    if not any(
        term in heading
        for term in (
            "점포",
            "매장",
            "상점",
            "소상공인",
            "경영환경개선",
            "희망팩",
            "안심보안",
            "출입인증",
        )
    ):
        return ()
    kinds = set()
    if "스마트상점" in material:
        kinds.add("smart_store")
    if any(term in material for term in ("경영환경개선", "점포환경개선", "시설개선")):
        kinds.add("facility_improvement")
    security_terms = ("안심보안", "출입인증", "cctv", "방범", "보안장비", "범죄예방")
    excluded = {
        term
        for term in security_terms
        if re.search(
            re.escape(term) + r"(?:장치|장비|기기|설치|무료|무상|는|은|도|의|지원|대상|에서)*"
            r"(?:제외|미지원|불가|하지않|아님|아닙)",
            body,
        )
    }
    if any(term in material for term in ("점포", "매장", "소상공인", "상점")) and any(
        term in material and term not in excluded for term in security_terms
    ):
        kinds.add("store_security")
    provisions = list(re.finditer(r"무상지원|무료설치|현물지원", body))
    negative_after = re.compile(
        r"(?:은|는|을|를|이|가|지원|대상|에서)*"
        r"(?:하지않|되지않|아니|아님|아닙|불가|제외|미지원|없)"
    )
    positive_provision = any(not negative_after.match(body[item.end() :]) for item in provisions)
    if not provisions:
        positive_provision = any(term in heading for term in ("무상지원", "무료설치", "현물지원"))
    if (
        kinds
        and positive_provision
        and any(term in material for term in ("무상지원", "무료설치", "현물지원"))
        and any(term in material for term in ("장치", "장비", "제품"))
    ):
        kinds.add("in_kind_support")
    return tuple(sorted(kinds))


def display_kinds(notice):
    """Revalidate derived labels without changing immutable earlier observations."""
    if notice.source_id == SOURCE_ID:
        overview = next(
            (
                line.removeprefix("사업개요:").strip()
                for line in notice.evidence_text.splitlines()
                if line.startswith("사업개요:")
            ),
            notice.evidence_text,
        )
        return store_support_kinds(notice.title, overview)
    return notice.kinds


def reviewed_notice_ids(path=None):
    value = json.loads((path or REFERENCES).read_text(encoding="utf-8"))
    if (
        set(value) != {"schema_version", "source_id", "reviewed_notice_ids"}
        or value["schema_version"] != 1
        or value["source_id"] != SOURCE_ID
    ):
        raise ValueError("Invalid store reference configuration")
    ids = value["reviewed_notice_ids"]
    if (
        not isinstance(ids, list)
        or not 1 <= len(ids) <= 5
        or any(not isinstance(i, str) or not re.fullmatch(r"PBLN_\d{8,30}", i) for i in ids)
        or len(set(ids)) != len(ids)
    ):
        raise ValueError("Invalid reviewed store identities")
    return tuple(ids)


def parse_reviewed_store_notice(body, url, *, fetched_at):
    from apps.policy_funding.catalog import source_by_id
    from apps.policy_funding.parsing import NoticeLink, _date, _text, _tree, parse_bizinfo_detail

    source_by_id(SOURCE_ID).validate_url(url)
    parts = urlsplit(url)
    query = parse_qs(parts.query, strict_parsing=True)
    if (
        parts.path != "/sii/siia/selectSIIA200Detail.do"
        or set(query) != {"pblancId"}
        or len(query["pblancId"]) != 1
        or query["pblancId"][0] not in reviewed_notice_ids()
    ):
        raise ValueError("Unreviewed store reference identity")
    tree = _tree(body)
    title = _text(tree.css_first("h2.title"))
    published = _date(_text(tree.css_first(".top_info > ul > li")))
    return parse_bizinfo_detail(
        body,
        NoticeLink(query["pblancId"][0], title, url, published),
        source_id=SOURCE_ID,
        fetched_at=fetched_at,
        listing_state="unknown",
    )


def application_window_note(period, *, as_of):
    tokens = re.findall(r"\b(20\d{2})[.\-/]\s*(\d{1,2})[.\-/]\s*(\d{1,2})\b", period or "")
    if len(tokens) == 2:
        try:
            start, end = (date(*map(int, token)) for token in tokens)
            if start <= end and as_of > end:
                return "공고에 적힌 접수기간이 종료됐습니다. 새 모집 여부는 원문에서 확인하세요."
            if start <= end and as_of < start:
                return "공고에 적힌 접수 시작일 전입니다. 변경 여부는 원문에서 확인하세요."
        except ValueError:
            pass
    return "현재 접수 여부·잔여 예산은 원문에서 확인하세요."
