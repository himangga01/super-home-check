"""Transparent advisory fit, separate from official application/selection."""

NOTICE_URL = (
    "https://www.bizinfo.go.kr/sii/siia/selectSIIA200Detail.do?pblancId=PBLN_000000000121227"
)
PDF_URL = "https://gbyouth.go.kr/jfile/readFile.tc?fileId=JF00000100034&fileSeq=2"
LABELS = {
    "candidate": "검토 후보",
    "prepare": "준비 보완 필요",
    "verify": "신청자격 확인 필요",
    "restricted": "기본 제한사항 확인",
}


def diagnose(answers: dict) -> dict:
    """Evaluate validated self-report, never certify official eligibility."""
    a = answers
    restrictions, checks, preparation = [], [], []
    if a["business_type"] == "prospective":
        restrictions.append("신청일 현재 사업자등록과 정상 영업이 필요합니다.")
    if a["operating"] != "open":
        restrictions.append("휴·폐업 상태는 2026년 공고의 기본 신청요건에 맞지 않습니다.")
    for key, label in (
        ("nonprofit", "비영리 사업자·법인·단체·조합"),
        ("excluded", "지원제외 업종"),
        ("sanctions", "정부지원사업 참여제한"),
        ("wage_arrears", "공개 체불사업주 명단"),
    ):
        if a[key] == "yes":
            restrictions.append(f"{label} 해당 여부와 공고의 신청제외 요건을 확인하세요.")
        elif a[key] == "unknown":
            checks.append(f"{label} 해당 여부를 증빙으로 확인하세요.")
    for key, label in (("tax", "국세·지방세 체납 규제"), ("debt", "금융거래·채무불이행 규제")):
        if a[key] == "restricted":
            restrictions.append(f"{label}: 공고의 예외와 마감일까지 충족해야 할 증빙을 확인하세요.")
        elif a[key] != "clear":
            checks.append(f"{label}: 예외 인정·유효일·증빙을 주관기관에 확인하세요.")
    if a["certificate"] != "issued":
        checks.append("소상공인확인서 발급 가능 여부·업종별 매출·근로자 기준을 확인하세요.")
    if a["employees"] == "10_plus" or (
        a["employees"] == "5_9" and a["sector"] not in {"manufacturing", "food_manufacturing"}
    ):
        checks.append(
            "응답한 근로자 수와 주업종 기준을 대조하세요. 평균 인원·산정 제외 근로자, "
            "확인서 유효성·소상공인 지위 유지 예외를 확인해야 하며 "
            "인원만으로 탈락을 확정하지 않습니다."
        )
    if a["concurrent"] != "no":
        checks.append("현재 수행 과제와 공고 참고6의 동시 수행 금지 사업을 대조하세요.")
    if a["history"] in {"unknown", "other"}:
        checks_text = "과거 지원의 사업명·연도·트랙과 두 사업의 재참여 제한을 대조하세요."
        if a["history"] == "unknown":
            checks.append(checks_text)
        else:
            preparation.append(checks_text)
    local = bool(set(a["resources"]) & {"product", "culture", "tourism", "partners"})
    strong = bool(set(a["difference"]) & {"own_brand", "innovation"})
    if not local:
        preparation.append("지역 자원·문화와 상품의 연결, 지역경제 기여를 구체화하세요.")
    if a["brand"] in {"none", "planned"}:
        preparation.append("자체 제품·브랜드의 차별성과 고객 수요 근거를 준비하세요.")
    if a["development"] in {"idea", "plan", "developing"}:
        preparation.append("시제품·고객 반응·판매 실적 등 사업화 근거를 보완하세요.")
    if a["growth"] == "none":
        preparation.append("목표 고객·판로·일정·성장 목표를 구체화하세요.")
    if a["matching"] != "ready":
        preparation.append(
            "로컬기업 자부담 20% 이상의 조달 계획과 현금·현물 인정 증빙을 준비하세요."
        )
    if "rent_debt" in a["purposes"]:
        preparation.append(
            "정부 사업화자금으로 일반 임대료·기존 대출상환을 계획하지 마세요. "
            "로컬기업 자부담 임차비 인정은 별도 기준입니다."
        )
    if set(a["purposes"]) <= {"other", "rent_debt"}:
        preparation.append(
            "신제품·브랜드·마케팅 등 공고상 사업화 목적에 맞는 예산을 다시 작성하세요."
        )
    tracks = []
    for key, name, fit, restricted_history in (
        ("local", "로컬기업 육성사업", local, "local_2020_2025"),
        ("strong", "강한소상공인 성장지원사업", strong, "strong_restricted"),
    ):
        own_restrictions = list(restrictions)
        if a["history"] in {restricted_history, "both_restricted"}:
            own_restrictions.append(
                "선택한 과거 선정 이력은 이 사업의 2026년 재참여 제한 확인 대상입니다."
            )
        needs_preparation = (
            not fit
            or a["growth"] == "none"
            or a["development"] in {"idea", "plan", "developing"}
            or set(a["purposes"]) <= {"other", "rent_debt"}
            or (key == "local" and a["matching"] != "ready")
        )
        status = (
            "restricted"
            if own_restrictions
            else "verify"
            if checks
            else "prepare"
            if needs_preparation
            else "candidate"
        )
        reason = "지역 자원 활용 응답이 있습니다." if local else "지역 자원 활용 근거를 보완하세요."
        if key == "strong":
            reason = (
                "자체 브랜드·혁신 응답이 있습니다."
                if strong
                else "차별화와 성장 모델을 보완하세요."
            )
        tracks.append(
            dict(
                key=key,
                name=name,
                status=status,
                label=LABELS[status],
                reason=reason,
                restrictions=own_restrictions,
            )
        )
    return dict(
        tracks=tracks,
        checks=checks,
        preparation=list(dict.fromkeys(preparation)),
        summary=(
            "입력한 응답을 바탕으로 사업 방향과 준비사항을 안내합니다. "
            "공식 신청자격 판정이나 심사 점수가 아닙니다."
        ),
        description=a["description"],
    )
