"""Validated advisory questionnaire; never performs a business lookup."""

from datetime import date

from django import forms

from apps.policy_funding.catalog import REGIONS

STAGE_TITLES = ("사업 기본정보", "사업 경쟁력", "자금 활용과 성장 계획", "신청자격 확인사항")


def choice(label, options, help_text=""):
    return forms.ChoiceField(
        label=label,
        choices=(("", "선택해 주세요"), *options),
        help_text=help_text,
    )


def multiple(label, options):
    return forms.MultipleChoiceField(
        label=label,
        choices=options,
        widget=forms.CheckboxSelectMultiple,
        help_text="해당하는 항목을 모두 선택하세요.",
    )


YES_NO_UNKNOWN = (("no", "아니요"), ("yes", "예"), ("unknown", "확인 필요"))


class BasicForm(forms.Form):
    business_type = choice(
        "사업자 유형",
        (
            ("individual", "개인사업자"),
            ("corporate", "법인사업자"),
            ("prospective", "예비창업자"),
        ),
    )
    operating = choice(
        "사업 운영 상태",
        (
            ("open", "정상 영업 중"),
            ("paused", "휴업 중"),
            ("closed", "폐업 상태"),
        ),
    )
    province = choice(
        "사업장 시·도",
        tuple(
            (key, label) for key, label in REGIONS.items() if key not in {"national", "unspecified"}
        ),
    )
    district = forms.CharField(label="사업장 시·군·구", max_length=50)
    sector = choice(
        "주요 업종",
        (
            ("food", "음식점·카페"),
            ("food_manufacturing", "식품 제조·가공"),
            ("manufacturing", "일반 제조업"),
            ("retail", "도소매·온라인판매"),
            ("beauty", "뷰티·화장품"),
            ("tourism", "관광·숙박·체험"),
            ("culture", "공방·문화콘텐츠"),
            ("other", "기타"),
        ),
    )
    start_year = forms.IntegerField(label="사업 시작 연도", min_value=1900, required=False)
    start_month = forms.ChoiceField(
        label="사업 시작 월",
        required=False,
        choices=(("", "선택해 주세요"), *((str(i), f"{i}월") for i in range(1, 13))),
    )
    employees = choice(
        "상시근로자 수",
        (
            ("0", "0명"),
            ("1_4", "1~4명"),
            ("5_9", "5~9명"),
            ("10_plus", "10명 이상"),
        ),
        "대표자 제외. 이 응답만으로 소상공인 자격을 확정하지 않습니다.",
    )
    sales = choice(
        "최근 연간 매출",
        (
            ("none", "매출 없음"),
            ("under50", "5,000만원 미만"),
            ("50_100", "5,000만원~1억원 미만"),
            ("100_300", "1억원~3억원 미만"),
            ("300_500", "3억원~5억원 미만"),
            ("500_plus", "5억원 이상"),
        ),
        "업종별 매출 기준과 소상공인확인서를 함께 확인해야 합니다.",
    )

    def clean(self):
        data = super().clean()
        year, month = data.get("start_year"), data.get("start_month")
        if data.get("business_type") != "prospective":
            if not year:
                self.add_error("start_year", "등록 사업자는 시작 연도를 입력해 주세요.")
            if not month:
                self.add_error("start_month", "등록 사업자는 시작 월을 선택해 주세요.")
        if bool(year) != bool(month):
            self.add_error("start_year", "시작 연도와 월을 함께 입력해 주세요.")
        if year and month and (year, int(month)) > (date.today().year, date.today().month):
            self.add_error("start_year", "사업 시작일은 미래일 수 없습니다.")
        return data


class CompetitivenessForm(forms.Form):
    difference = multiple(
        "사업의 차별화 요소",
        (
            ("local_product", "지역 특산물·농수산물 활용"),
            ("local_culture", "지역 문화·관광자원 활용"),
            ("own_brand", "자체 제품·브랜드"),
            ("innovation", "새로운 기술·서비스·사업모델"),
            ("ordinary", "일반 상품·서비스 판매"),
            ("other", "기타"),
        ),
    )
    brand = choice(
        "자체 제품·브랜드 보유",
        (
            ("selling", "자체 브랜드 제품 판매 중"),
            ("prototype", "제품·시제품 개발 중"),
            ("planned", "브랜드 개발 예정"),
            ("none", "해당 없음"),
        ),
    )
    resources = multiple(
        "지역 자원 활용",
        (
            ("product", "지역 특산물"),
            ("culture", "지역 문화·역사"),
            ("tourism", "지역 관광자원"),
            ("partners", "지역 생산자·기업 협업"),
            ("planned", "활용 계획만 있음"),
            ("none", "해당 없음"),
        ),
    )
    development = choice(
        "사업화 진행 수준",
        (
            ("selling", "제품 출시 후 매출 발생"),
            ("prototype", "시제품 완성"),
            ("developing", "제품 개발 중"),
            ("plan", "구체적인 사업계획"),
            ("idea", "아이디어 단계"),
        ),
    )
    description = forms.CharField(
        label="차별성을 설명해 주세요",
        max_length=300,
        widget=forms.Textarea(attrs={"rows": 4}),
        help_text="300자 이내. 이름·연락처·사업자등록번호 등은 입력하지 마세요.",
    )

    def clean(self):
        data = super().clean()
        for field, exclusive in (("difference", {"ordinary"}), ("resources", {"none", "planned"})):
            selected = set(data.get(field, ()))
            if len(selected) > 1 and selected & exclusive:
                self.add_error(
                    field, "해당 없음·일반 판매·계획만 있음은 다른 항목과 함께 선택할 수 없습니다."
                )
        return data


class GrowthForm(forms.Form):
    purposes = multiple(
        "사업화 자금 사용 목적",
        (
            ("development", "신제품 개발"),
            ("prototype", "시제품 제작"),
            ("upgrade", "제품·서비스 고도화"),
            ("branding", "브랜드·패키지 개발"),
            ("marketing", "마케팅·판로개척"),
            ("local", "지역 자원 기반 상품"),
            ("rent_debt", "일반 임대료·기존 대출상환"),
            ("other", "기타"),
        ),
    )
    growth = choice(
        "성장 계획",
        (
            ("product", "신규 제품 출시"),
            ("online", "온라인 판매 확대"),
            ("offline", "유통망 확대"),
            ("export", "수출·해외 진출"),
            ("franchise", "지점·프랜차이즈 확대"),
            ("tourism", "지역 관광·체험 확대"),
            ("none", "구체적인 계획 없음"),
        ),
    )
    budget = choice(
        "예상 총 사업비",
        (
            ("under1000", "1,000만원 미만"),
            ("1000_3000", "1,000만~3,000만원"),
            ("3000_5000", "3,000만~5,000만원"),
            ("5000_10000", "5,000만~1억원"),
            ("10000_plus", "1억원 이상"),
        ),
        "희망 지원금이나 예상 승인금액이 아닙니다.",
    )
    matching = choice(
        "로컬기업 자부담 준비",
        (
            ("ready", "확보 가능"),
            ("partial", "일부 확보"),
            ("not_ready", "준비되지 않음"),
            ("unknown", "조건 확인 필요"),
        ),
        "2026년 로컬기업은 총 사업비의 자부담 20% 이상. 현금·현물 인정 기준을 확인하세요.",
    )


class EligibilityForm(forms.Form):
    history = choice(
        "과거 사업화 지원 이력",
        (
            ("none", "선정 이력 없음"),
            ("local_2020_2025", "2020~2025 로컬크리에이터 개인 선정·지원"),
            (
                "strong_restricted",
                "2022 강한 전체 / 2023 라이프스타일·로컬브랜드 / 2024~2025 트랙Ⅰ 선정",
            ),
            ("both_restricted", "위 로컬기업·강한소상공인 제한 이력 모두 해당"),
            ("other", "위 항목 이외의 정부 지원"),
            ("unknown", "연도·유형 확인 필요"),
        ),
        "선정받은 사업명·연도·트랙을 확인해 주세요.",
    )
    tax = choice(
        "국세·지방세 체납 규제",
        (
            ("clear", "현재 없음"),
            ("restricted", "현재 규제 중"),
            ("exception", "징수·처분 유예 또는 변제 등 예외 확인 필요"),
            ("unknown", "확인 필요"),
        ),
        "법인은 대표자도 포함. 예외 인정과 증빙은 공식 공고를 따릅니다.",
    )
    debt = choice(
        "채무불이행 등 금융거래 규제",
        (
            ("clear", "현재 없음"),
            ("restricted", "현재 규제 중"),
            ("exception", "채무조정·회생·면책 등 예외 확인 필요"),
            ("unknown", "확인 필요"),
        ),
        "과거 연체를 상환한 경우와 현재 규제를 구분하세요. 보증보험 발급은 별도 확인합니다.",
    )
    concurrent = choice(
        "다른 정부 사업화 과제를 현재 수행 중인가요?",
        YES_NO_UNKNOWN,
        "동시 수행 금지 사업은 공고 참고6에서 확인합니다.",
    )
    certificate = choice(
        "소상공인확인서",
        (
            ("issued", "발급되어 있으며 유효성 확인 예정"),
            ("not_issued", "아직 발급받지 않음"),
            ("unknown", "발급 가능 여부 확인 필요"),
        ),
    )
    nonprofit = choice("비영리 사업자·법인·단체·조합인가요?", YES_NO_UNKNOWN)
    excluded = choice(
        "공고상 지원제외 업종에 해당하나요?",
        YES_NO_UNKNOWN,
        "간단한 업종 선택만으로 판단할 수 없습니다. 공고 참고3의 세부 업종코드를 확인하세요.",
    )
    sanctions = choice("정부지원사업 참여제한 제재를 받고 있나요?", YES_NO_UNKNOWN)
    wage_arrears = choice("공개 체불사업주 명단에 해당하나요?", YES_NO_UNKNOWN)


FORMS = (BasicForm, CompetitivenessForm, GrowthForm, EligibilityForm)
