"""Separate official notice facts from plain educational explanation."""

from datetime import datetime
from zoneinfo import ZoneInfo

from apps.policy_funding.contracts import KINDS, FundingNotice
from apps.policy_funding.education import learning_content
from apps.policy_funding.parsing import BIZINFO_SUPPORT_KINDS
from apps.policy_funding.store_support import KINDS as STORE_KINDS
from apps.policy_funding.store_support import SOURCE_ID as STORE_SOURCE
from apps.policy_funding.store_support import application_window_note, display_kinds


def explain_notice(notice: FundingNotice) -> dict:
    effective_kinds = display_kinds(notice)
    excluded_store_record = notice.source_id == STORE_SOURCE and not effective_kinds
    kind = (
        "agency"
        if "agency_loan" in notice.kinds
        else "direct"
        if "direct_loan" in notice.kinds
        else None
    )
    guide = learning_content()
    support_labels = [
        KINDS[value]
        for value in effective_kinds
        if value in set(BIZINFO_SUPPORT_KINDS.values()) | STORE_KINDS
    ]
    nonfinancial = bool(support_labels) or excluded_store_record
    purpose = "guidance"
    if any(term in notice.title for term in ("만기연장", "상환유예", "상환연장")):
        purpose = "repayment_relief"
    elif any(term in notice.title for term in ("변경", "수정", "개정")):
        purpose = "amendment"
    elif any(term in notice.title for term in ("접수", "신청", "모집", "융자사업", "지원 계획")):
        purpose = "application"
    summaries = {
        "repayment_relief": (
            "기존 대출의 만기나 상환 일정을 조정하는 안내입니다. "
            "신규 대출이나 빚 면제와는 다릅니다."
        ),
        "amendment": (
            "기존 지원사업의 조건을 바꾸는 공고입니다. 바뀐 항목과 적용일을 원문에서 확인하세요."
        ),
        "guidance": (
            "정책자금 이용과 관련된 안내입니다. 새로 신청하는 "
            "공고인지, 기존 이용자를 위한 내용인지 확인하세요."
        ),
    }
    return {
        "title": notice.title,
        "issuer": notice.issuer,
        "source_note": (
            "점주 대상 지원 공고로 분류되지 않는 기록입니다. "
            "과거 수집 원문은 보존하며 신청 대상을 원문에서 확인하세요."
            if excluded_store_record
            else "소진공 원 게시판의 대체 수집 출처인 기업마당 공식 재공고입니다. "
            "원 게시판의 개별 일정 전체를 수집한 결과는 아닙니다."
            if notice.source_id == "bizinfo_semas"
            else "점포 지원 공고와 과거 참고 공고를 함께 수집한 출처입니다. "
            "지원한도·자부담·설치품목·A/S·신청 경로는 각 공고 원문을 확인하세요."
            if notice.source_id == STORE_SOURCE
            else None
        ),
        "application_status_note": application_window_note(
            notice.application_period, as_of=datetime.now(ZoneInfo("Asia/Seoul")).date()
        )
        if notice.source_id == STORE_SOURCE
        else None,
        "application_period": notice.application_period or "원 공고에서 확인하세요",
        "approved_amount": None,
        "loan_rate": None,
        "kind_labels": [KINDS[kind] for kind in effective_kinds] or ["신청 대상 확인 필요"],
        "purpose": purpose,
        "listing_label": {
            "open_list": "공식 접수중 목록에서 확인",
            "ended_list": "공식 마감 목록에서 확인",
            "unknown": "목록 접수 상태 미확인",
        }[notice.listing_state],
        "date_label": "기업마당 등록일"
        if notice.source_id.startswith("bizinfo_")
        else "소진공 등록일",
        "plain_summary": (
            "점주 대상 지원 공고로 분류되지 않는 기록입니다. 원문의 신청 대상을 확인하세요."
            if excluded_store_record
            else f"{', '.join(support_labels)} 사업 공고입니다. "
            "지원내용과 참여요건을 원문에서 확인하세요."
            if nonfinancial
            else summaries[purpose]
            if purpose != "application"
            else (
                "정책기관의 지원대상 확인 뒤 은행에서 심사받는 대리대출 공고입니다."
                if kind == "agency"
                else "정책기관이 직접 심사하고 빌려주는 직접대출 공고입니다."
                if kind == "direct"
                else (
                    "이 공고는 사업에 필요한 자금이나 보증·비용 지원을 "
                    "안내합니다. 지원 방식을 원문에서 확인하세요."
                )
            )
        ),
        "journey": guide["journeys"].get(kind, []) if purpose == "application" else [],
        "confirmation_note": (
            "공고를 확인하거나 신청했다고 참여기업 선정이나 지원이 확정되는 것은 아닙니다."
            if nonfinancial
            else "지원대상 확인서는 대출 승인이 아닙니다. 공고의 최대 "
            "한도도 내게 확정된 금액이 아닙니다."
        ),
        "unknown_terms_note": (
            "사업별 대상·선정절차·지원방식이 다릅니다. 연구개발·컨설팅·행사 참여는 "
            "현금 지급과 다를 수 있으니 원 공고를 확인하세요."
            if nonfinancial
            else "개인별 승인금액·실제 금리·보증여력은 이 화면에서 판단하지 않습니다. 자금별"
            " 원 공고와 보증기관·은행 심사로 확인하세요."
        ),
        "availability_note": (
            "수집 당시 공식 목록과 공고의 표시입니다. 예산 "
            "잔액이나 지금 신청 가능한지는 공식 접수 화면에서 다시"
            " 확인하세요."
        ),
        "terms_label": "선정·지원 조건" if nonfinancial else "개인별 금액·금리",
        "terms_value": "사업별 심사·협약·지원방식을 원 공고에서 확인"
        if nonfinancial
        else "기관·은행 심사와 약정에서 확인",
        "checklist": []
        if excluded_store_record
        else [
            "사업장 소재지와 업종, 기업 규모를 확인하세요.",
            "공고에서 요구하는 참여신청서와 증빙자료를 준비하세요.",
            "자부담, 지원 한도와 비용 지급 시점을 확인하세요.",
            "접수 마감일, 제출 방법과 사업 수행 일정을 확인하세요.",
        ]
        if nonfinancial
        else guide["checklist"],
        "comparison": []
        if excluded_store_record
        else [
            "컨설팅·행사·연구개발 등 실제 제공되는 지원 내용",
            "자부담과 부가세, 지원금 지급 시점",
            "참여요건과 중복 지원 제한, 협약상 의무",
            "필요한 결과물과 사업 완료 기한",
        ]
        if nonfinancial
        else guide["comparison"],
    }


def _md(value: str) -> str:
    for symbol in ("\\", "[", "]", "*", "_", "#", "`"):
        value = value.replace(symbol, "\\" + symbol)
    return value


def render_notice(notice: FundingNotice) -> str:
    info = explain_notice(notice)
    lines = [
        f"# {_md(notice.title)}",
        "",
        info["plain_summary"],
        "",
        f"- 공고 기관: {_md(notice.issuer)}",
        (
            f"- {info['date_label']}: "
            f"{notice.published_on.isoformat() if notice.published_on else '원문에서 확인'}"
        ),
        f"- 수집 당시 상태: {info['listing_label']}",
        f"- 수집 시각: {notice.fetched_at.isoformat()}",
        f"- 신청기간 원문: {_md(info['application_period'])}",
        f"- 출처: [공식 공고]({notice.official_url})",
        "",
        "## 먼저 알아둘 점",
        "",
        info["confirmation_note"],
        "",
        info["unknown_terms_note"],
        "",
        info["availability_note"],
        "",
    ]
    if info["application_status_note"]:
        lines += [info["application_status_note"], ""]
    if info["journey"]:
        lines += ["## 쉬운 진행 순서", ""]
        lines.extend(
            f"{index}. {step['title']}: {step['explanation']}"
            for index, step in enumerate(info["journey"], 1)
        )
    lines += [
        "",
        "## 공고에서 확인한 내용",
        "",
        _md(notice.evidence_text),
        "",
        "## 준비할 자료",
        "",
    ]
    lines.extend(f"- {item}" for item in info["checklist"])
    if notice.origin_url:
        lines += ["", f"원 발행기관 안내: [기관 원문]({notice.origin_url})"]
    if info["source_note"]:
        lines += ["", info["source_note"]]
    if notice.application_url:
        lines += ["", f"신청 경로: [공식 신청 사이트]({notice.application_url})"]
    if notice.provenance == "fixture":
        lines.insert(2, "검증용 자료입니다. 실제 최신 접수 상태를 뜻하지 않습니다.")
    return "\n".join(lines) + "\n"


def render_guide() -> str:
    content = learning_content()
    rows = [
        "# 처음 배우는 소상공인 정책자금",
        "",
        "확인서는 대출 승인이 아닙니다. 최대 한도는 내게 확정된 돈이 아닙니다.",
        "",
    ]
    rows += ["## 대표님, 헷갈리는 부분부터 같이 볼까요?", ""]
    for answer in content["plain_answers"]:
        rows += [
            f"### {answer['question']}",
            "",
            answer["answer"],
            "",
            answer["example"],
            "",
            f"[관련 공식 안내]({answer['reference']})",
            "",
        ]
    for kind, title in (("agency", "대리대출"), ("direct", "직접대출"), ("grant", "지원금")):
        rows.extend([f"## {title} 진행 순서", ""])
        rows.extend(
            f"{i}. {step['title']} — {step['explanation']}"
            for i, step in enumerate(content["journeys"][kind], 1)
        )
        rows.append("")
    rows += ["## 쉬운 용어 사전", ""]
    for term in content["glossary"]:
        rows += [
            f"### {term['term']}",
            "",
            term["plain"],
            "",
            term["example"],
            "",
            f"[공식 설명 참고]({term['reference']})",
            "",
        ]
    rows += [
        "## 비교할 것",
        "",
        *[f"- {item}" for item in content["comparison"]],
        "",
        content["regional_note"],
        "",
        content["safety_note"],
        "",
    ]
    return "\n".join(rows)
