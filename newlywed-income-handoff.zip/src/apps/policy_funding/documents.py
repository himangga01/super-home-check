"""Optional official Bizinfo PDF evidence, bounded by the collection's deadline.

No PDF bytes are published. Page-labelled text excerpts and document hashes are
stored in the immutable notice evidence. HTML application/publication fields
are preserved, including unknown or budget-dependent dates.
"""

import hashlib
import re
from dataclasses import replace

from apps.policy_funding.parsing import clean_text
from wisdome_writer.notice_diagnosis.pdf import extract_official_pdf


def enrich_notice_from_pdfs(notice, fetcher):
    references = [item for item in notice.attachments if re.search(r"\.pdf\b", item[0], re.I)]
    if not references:
        return notice, ()
    evidence = notice.evidence_text
    errors = []
    for label, url in references[:2]:
        try:
            data = fetcher.get_pdf(url)
            remaining = fetcher.remaining_seconds()
            if remaining <= 0:
                raise ValueError("Official document deadline exhausted")
            pages = extract_official_pdf(data, timeout=remaining)
        except Exception as exc:
            errors.append(type(exc).__name__)
            continue
        header = (
            f"\n\n공식 PDF 첨부: {label}\nURL: {url}\nSHA256: {hashlib.sha256(data).hexdigest()}\n"
        )
        budget = min(14000, 39000 - len(evidence) - len(header))
        if budget < 100:
            errors.append("evidence_budget_exhausted")
            break
        excerpts = ""
        for page in pages:
            text = f"[page={page['page']}] {clean_text(page['text'])}\n"
            if len(excerpts) + len(text) > budget:
                excerpts += (
                    text[: max(0, budget - len(excerpts) - 30)] + "\n[이하 분량 제한으로 생략]\n"
                )
                break
            excerpts += text
        evidence += header + excerpts
    return replace(notice, evidence_text=evidence), tuple(errors)
