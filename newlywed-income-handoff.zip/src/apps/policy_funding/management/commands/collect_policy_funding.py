"""Collect official funding notices or explicitly labeled offline parser fixtures."""

import json
from datetime import UTC, date, datetime
from pathlib import Path
from zoneinfo import ZoneInfo

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.policy_funding.catalog import REGIONS
from apps.policy_funding.collectors import CollectionLimits, CollectionOutcome, collection_state
from apps.policy_funding.parsing import (
    parse_bizinfo_detail,
    parse_bizinfo_list,
    parse_ols_detail,
    parse_ols_list,
)
from apps.policy_funding.storage import read_run
from apps.policy_funding.workflow import publish_collection, run_collection


class Command(BaseCommand):
    help = "Collect bounded official policy-funding notices and write validated Korean guides."

    def add_arguments(self, parser):
        parser.add_argument(
            "--sources",
            nargs="+",
            choices=(
                "semas_agency",
                "semas_direct",
                "bizinfo_finance",
                "bizinfo_business_grants",
                "bizinfo_support",
                "bizinfo_semas",
                "bizinfo_store_support",
            ),
        )
        parser.add_argument("--pages", type=int, default=1, choices=range(1, 6))
        parser.add_argument("--max-notices", type=int, default=20, choices=range(1, 101))
        parser.add_argument("--seconds", type=int, default=90, choices=range(1, 301))
        parser.add_argument(
            "--documents",
            action="store_true",
            help="Read up to two official PDFs per Bizinfo notice within the shared budget",
        )
        parser.add_argument(
            "--notice-ids",
            nargs="+",
            help="Up to twenty exact Bizinfo IDs, filtered after official list discovery",
        )
        parser.add_argument(
            "--keywords",
            nargs="+",
            help="Up to ten distinct Bizinfo title searches; explicitly select Bizinfo sources",
        )
        parser.add_argument(
            "--as-of", dest="as_of", help="KST run date, YYYY-MM-DD; does not change source dates"
        )
        parser.add_argument("--output", help="Independent policy output root")
        parser.add_argument(
            "--region",
            choices=(*REGIONS, "national", "unspecified"),
            help=(
                "Post-collection region filter;"
                " regional choices include "
                "national-institution notices"
            ),
        )
        parser.add_argument(
            "--fixture",
            action="store_true",
            help="Use only repository parser fixtures; never live acceptance",
        )

    def handle(self, *args, **options):
        try:
            day = (
                date.fromisoformat(options["as_of"])
                if options["as_of"]
                else datetime.now(ZoneInfo("Asia/Seoul")).date()
            )
            root = Path(options["output"] or settings.POLICY_FUNDING_ROOT)
            if options["fixture"]:
                if options["keywords"] or options["documents"] or options["notice_ids"]:
                    raise ValueError("Keyword/document searches are unavailable in fixture mode")
                chosen = tuple(options["sources"] or ("semas_agency", "bizinfo_finance"))
                if "semas_direct" in chosen:
                    raise ValueError(
                        "No direct-loan fixture is registered; use "
                        "a live collector or capture an approved "
                        "fixture"
                    )
                if {
                    "bizinfo_business_grants",
                    "bizinfo_support",
                    "bizinfo_semas",
                    "bizinfo_store_support",
                } & set(chosen):
                    raise ValueError(
                        "No CLI support/business-grant fixture is registered; use a live collection"
                    )
                fixtures = settings.REPOSITORY_ROOT / "tests/fixtures/policy_funding"
                stamp = datetime.combine(day, datetime.min.time(), tzinfo=UTC)
                notices, outcomes = [], []
                for source in chosen:
                    if source == "semas_agency":
                        links, _ = parse_ols_list(
                            json.loads((fixtures / "ols-list.json").read_text(encoding="utf-8"))
                        )
                        rows = tuple(
                            parse_ols_detail(
                                (fixtures / f"ols-{link.external_id}.html").read_text(
                                    encoding="utf-8"
                                ),
                                link,
                                source_id=source,
                                fetched_at=stamp,
                            )
                            for link in links
                        )
                    else:
                        link = parse_bizinfo_list(
                            (fixtures / "bizinfo-list-N.html").read_text(encoding="utf-8")
                        )[0]
                        rows = (
                            parse_bizinfo_detail(
                                (fixtures / "bizinfo-detail.html").read_text(encoding="utf-8"),
                                link,
                                fetched_at=stamp,
                                listing_state="open_list",
                            ),
                        )
                    notices.extend(rows)
                    outcomes.append(CollectionOutcome(source, rows, "completed", (), 0, True))
                path = publish_collection(
                    root,
                    tuple(notices),
                    tuple(outcomes),
                    run_date=day,
                    mode="fixture",
                    region=options["region"],
                )
            else:
                selected = tuple(
                    options["sources"]
                    or (
                        "semas_agency",
                        "semas_direct",
                        "bizinfo_finance",
                        "bizinfo_support",
                        "bizinfo_store_support",
                    )
                )
                if (options["keywords"] or options["notice_ids"]) and not set(selected) <= {
                    "bizinfo_finance",
                    "bizinfo_support",
                    "bizinfo_semas",
                    "bizinfo_store_support",
                }:
                    raise ValueError("Keywords require explicit Bizinfo finance/support sources")
                path = run_collection(
                    root,
                    sources=selected,
                    run_date=day,
                    region=options["region"],
                    limits=CollectionLimits(
                        options["pages"],
                        options["max_notices"],
                        options["seconds"],
                        keywords=tuple(options["keywords"] or ()),
                        documents=options["documents"],
                        notice_ids=tuple(options["notice_ids"] or ()),
                    ),
                )
            result = read_run(root, path.name)
        except (ValueError, OSError) as exc:
            raise CommandError(str(exc)) from exc
        self.stdout.write(
            json.dumps(
                {
                    "run": str(path),
                    "mode": result["mode"],
                    "notice_count": len(result["notices"]),
                    "source_outcomes": result["source_outcomes"],
                    "collection_state": collection_state(result["source_outcomes"]),
                    "coverage_note": (
                        "소진공 원 게시판은 점검 경로로 이동 중입니다. "
                        "공식 재공고를 별도 출처로 수집했으며 원 게시판 전체를 대체하지 않습니다."
                        if collection_state(result["source_outcomes"]) == "degraded"
                        else None
                    ),
                    "changes": result["changes"],
                    "coverage_limited": True,
                    "selection": result.get("selection"),
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        if collection_state(result["source_outcomes"]) == "partial":
            raise CommandError(
                "Collection has source failures; the immutable run records the actual coverage"
            )
