"""Funding page guards; source collection remains an explicit CLI operation."""

import ipaddress
from functools import wraps
from urllib.parse import urlencode

from django.conf import settings
from django.core.exceptions import PermissionDenied
from django.http import Http404, HttpResponseBadRequest, HttpResponseNotAllowed
from django.shortcuts import render

from apps.policy_funding.catalog import REGIONS, load_catalog
from apps.policy_funding.collectors import SEMAS_BOARDS
from apps.policy_funding.consultant_case import reviewed_consultant_case
from apps.policy_funding.contracts import KINDS
from apps.policy_funding.education import learning_content
from apps.policy_funding.rendering import explain_notice
from apps.policy_funding.storage import latest_notices, list_runs, period_notices, read_run
from apps.policy_funding.store_support import SOURCE_ID as STORE_SOURCE
from apps.policy_funding.store_support import display_kinds
from apps.policy_funding.verification import verify_provided_case
from wisdome_writer.portal.periods import period_context, selection_from_query


def policy_page(function=None, *, allow_post=False):
    if function is None:
        return lambda view: policy_page(view, allow_post=allow_post)

    @wraps(function)
    def wrapped(request, *args, **kwargs):
        methods = ["GET", "HEAD", "POST"] if allow_post else ["GET", "HEAD"]
        if request.method not in methods:
            return HttpResponseNotAllowed(methods)
        if settings.IS_LOCAL_RUNTIME:
            try:
                allowed = ipaddress.ip_address(request.META.get("REMOTE_ADDR", "")).is_loopback
            except ValueError:
                allowed = False
        else:
            allowed = (
                request.user.is_authenticated and request.user.is_active and request.user.is_staff
            )
        if not allowed:
            raise PermissionDenied("Policy pages require local loopback or authorized staff")
        response = function(request, *args, **kwargs)
        response["Content-Security-Policy"] = (
            "default-src 'self'; script-src 'none'; style-src 'self'; img-src 'self'; "
            "object-src 'none'; base-uri 'none'; frame-ancestors 'none'; form-action 'self'"
        )
        response["Cache-Control"] = "no-store"
        response["X-Content-Type-Options"] = "nosniff"
        # Chrome sends Origin:null for a no-referrer non-CORS POST. Preserve
        # same-origin CSRF provenance without exposing referrers to external sites.
        response["Referrer-Policy"] = "same-origin" if allow_post else "no-referrer"
        return response

    return wrapped


def _base():
    return {"regions": REGIONS, "kinds": KINDS}


def _semas_availability(runs, mode):
    latest = {}
    for run in runs:
        if run["mode"] != mode:
            continue
        for source in run["source_outcomes"]:
            identity = source["source_id"]
            if identity in SEMAS_BOARDS and identity not in latest:
                latest[identity] = {
                    **source,
                    "run_name": run["run_name"],
                    "captured_at": run["captured_at"],
                    "name": "소진공 대리대출" if identity == "semas_agency" else "소진공 직접대출",
                }
    return [
        latest[identity]
        for identity in sorted(latest)
        if latest[identity]["status"] in {"temporarily_unavailable", "failed", "partial"}
    ]


def _list_query(request, mode):
    parameters = {"mode": mode}
    parameters.update(
        (key, request.GET[key])
        for key in ("year", "month", "basis", "q", "region", "kind")
        if key in request.GET
    )
    return urlencode(parameters)


@policy_page
def index(request):
    mode = request.GET.get("mode", "live")
    region, kind = request.GET.get("region", ""), request.GET.get("kind", "")
    query = request.GET.get("q", "").strip()
    if (
        mode not in {"live", "fixture"}
        or region
        and region not in REGIONS
        or kind
        and kind not in KINDS
        or len(query) > 200
    ):
        return HttpResponseBadRequest("검색 조건을 확인해 주세요.")
    try:
        period = selection_from_query(request.GET, allowed_bases=("published",))
    except ValueError as exc:
        return HttpResponseBadRequest(str(exc))
    try:
        runs = list_runs(settings.POLICY_FUNDING_ROOT)
        period_data = period_notices(settings.POLICY_FUNDING_ROOT, period, mode=mode)
        rows = period_data["notices"]
    except (ValueError, OSError):
        raise Http404("검증할 수 없는 정책자금 저장 경로입니다.") from None
    filtered = [
        row
        for row in rows
        if (row.source_id != STORE_SOURCE or display_kinds(row))
        and (not region or region in row.regions or "national" in row.regions)
        and (not kind or kind in display_kinds(row))
        and (
            not query
            or query.casefold()
            in (row.title + " " + row.issuer + " " + row.evidence_text).casefold()
        )
    ]
    filtered.sort(
        key=lambda row: (row.published_on.isoformat() if row.published_on else "", row.title),
        reverse=True,
    )
    cards = [
        {
            "notice": row,
            "run_name": period_data["notice_runs"][row.stable_id],
            "explanation": explain_notice(row),
            "region_labels": [
                REGIONS.get(key, "지역 확인 필요" if key == "unspecified" else "전국 기관")
                for key in row.regions
            ],
        }
        for row in filtered[:100]
    ]
    return render(
        request,
        "policy_funding/index.html",
        {
            **_base(),
            "notices": cards,
            "total": len(filtered),
            "runs": runs[:5],
            "semas_availability": _semas_availability(runs, mode),
            "mode": mode,
            "list_query": _list_query(request, mode),
            "q": query,
            "selected_region": region,
            "selected_kind": kind,
            "connected_source_count": sum(source.enabled for source in load_catalog()),
            "glossary_count": len(learning_content()["glossary"]),
            "period_selection": period,
            "period_ui": period_context(
                request,
                period,
                basis_labels={
                    "published": "공고 게시·등록일",
                },
                available_years=period_data["available_years"],
            ),
            "unknown_date_count": period_data["unknown_date_count"],
            "coverage_run_count": period_data["coverage_run_count"],
        },
    )


@policy_page
def guide(request):
    return render(
        request,
        "policy_funding/guide.html",
        {
            **_base(),
            "guide": learning_content(),
            "case": verify_provided_case(latest_notices(settings.POLICY_FUNDING_ROOT)),
            "consultant_case": reviewed_consultant_case(),
        },
    )


@policy_page
def sources(request):
    return render(request, "policy_funding/sources.html", {**_base(), "sources": load_catalog()})


@policy_page
def glossary(request):
    return render(request, "policy_funding/glossary.html", {"guide": learning_content()})


@policy_page
def history(request):
    try:
        period = selection_from_query(
            request.GET, default_basis="collected", allowed_bases=("collected",)
        )
    except ValueError as exc:
        return HttpResponseBadRequest(str(exc))
    try:
        runs = [
            run
            for run in list_runs(settings.POLICY_FUNDING_ROOT, limit=100)
            if period.matches(run["captured_at"])
        ][:30]
    except (ValueError, OSError):
        raise Http404("검증할 수 없는 정책자금 저장 경로입니다.") from None
    return render(
        request,
        "policy_funding/history.html",
        {
            "runs": runs,
            "period_selection": period,
            "period_ui": period_context(request, period, basis_labels={"collected": "수집 날짜"}),
        },
    )


@policy_page
def detail(request, notice_id):
    mode = request.GET.get("mode", "live")
    if mode not in {"live", "fixture"}:
        return HttpResponseBadRequest("실행 유형을 확인해 주세요.")
    selected_run = request.GET.get("run")
    try:
        if selected_run:
            snapshot = read_run(settings.POLICY_FUNDING_ROOT, selected_run)
            if snapshot["mode"] != mode:
                raise ValueError("Policy run mode differs")
            rows = snapshot["notices"]
        else:
            rows = latest_notices(settings.POLICY_FUNDING_ROOT, mode=mode)
    except (ValueError, OSError):
        raise Http404 from None
    row = next((item for item in rows if item.stable_id == notice_id), None)
    if row is None:
        raise Http404
    diagnosis_url = None
    if mode == "live":
        from wisdome_writer.notice_diagnosis.sources import diagnosis_url as build_diagnosis_url

        if not selected_run:
            selected_run = next(
                (
                    run["run_name"]
                    for run in list_runs(settings.POLICY_FUNDING_ROOT)
                    if run["mode"] == "live"
                    and any(
                        item.stable_id == row.stable_id and item.content_hash == row.content_hash
                        for item in run["notices"]
                    )
                ),
                None,
            )
        if selected_run:
            diagnosis_url = build_diagnosis_url("funding", row.stable_id, selected_run)
    return render(
        request,
        "policy_funding/detail.html",
        {
            **_base(),
            "notice": row,
            "diagnosis_url": diagnosis_url,
            "explanation": explain_notice(row),
            "guide": learning_content(),
            "mode": mode,
            "list_url": "/policy-funding/?" + _list_query(request, mode),
        },
    )


@policy_page
def run_detail(request, run_name):
    try:
        run = read_run(settings.POLICY_FUNDING_ROOT, run_name)
    except (ValueError, OSError):
        raise Http404 from None
    return render(request, "policy_funding/run.html", {**_base(), "run": run})
