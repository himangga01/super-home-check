"""Bounded collectors with explicit source failures and incomplete coverage."""

from __future__ import annotations

import json
import re
from dataclasses import dataclass, replace
from itertools import product
from urllib.parse import parse_qs, urlsplit

from apps.policy_funding.catalog import source_by_id
from apps.policy_funding.contracts import FundingNotice
from apps.policy_funding.parsing import (
    _tree,
    parse_bizinfo_detail,
    parse_bizinfo_list,
    parse_ols_detail,
    parse_ols_list,
)
from apps.policy_funding.store_support import (
    DEFAULT_KEYWORDS,
    DETAIL_BASE,
    NotStoreRecipientNotice,
    parse_reviewed_store_notice,
    reviewed_notice_ids,
)
from apps.policy_funding.store_support import (
    SOURCE_ID as STORE_SOURCE,
)
from apps.policy_funding.transport import OfficialFundingFetcher, OfficialSourceUnavailable

SEMAS_BOARDS = {"semas_agency", "semas_direct"}
SEMAS_MIRROR = "bizinfo_semas"


@dataclass(frozen=True)
class CollectionLimits:
    pages: int = 1
    notices: int = 20
    seconds: int = 90
    keywords: tuple[str, ...] = ()
    documents: bool = False
    notice_ids: tuple[str, ...] = ()

    def __post_init__(self):
        if not (
            type(self.pages) is int
            and 1 <= self.pages <= 5
            and type(self.notices) is int
            and 1 <= self.notices <= 100
            and type(self.seconds) is int
            and 1 <= self.seconds <= 300
        ):
            raise ValueError("Invalid policy collection limits")
        if (
            not isinstance(self.keywords, tuple)
            or len(self.keywords) > 10
            or any(
                not isinstance(term, str)
                or not term.strip()
                or term != term.strip()
                or len(term) > 80
                or any(ord(c) < 32 for c in term)
                for term in self.keywords
            )
            or len(set(self.keywords)) != len(self.keywords)
        ):
            raise ValueError("Invalid title-search keywords")
        if type(self.documents) is not bool:
            raise ValueError("Invalid document selection")
        if (
            not isinstance(self.notice_ids, tuple)
            or len(self.notice_ids) > 20
            or any(
                not isinstance(value, str) or not re.fullmatch(r"PBLN_\d{8,30}", value)
                for value in self.notice_ids
            )
            or len(set(self.notice_ids)) != len(self.notice_ids)
        ):
            raise ValueError("Invalid Bizinfo notice selection")


@dataclass(frozen=True)
class CollectionOutcome:
    source_id: str
    notices: tuple[FundingNotice, ...]
    status: str
    errors: tuple[str, ...]
    request_count: int
    coverage_limited: bool


def collect_source(source_id: str, limits: CollectionLimits, *, fetcher=None) -> CollectionOutcome:
    source = source_by_id(source_id)
    if not source.enabled:
        return CollectionOutcome(source_id, (), "discovery_only", (), 0, True)
    if source_id == "bizinfo_business_grants":
        from apps.policy_funding.grant_refresh import collect_target_grants

        return collect_target_grants(limits, fetcher=fetcher)
    if source_id == SEMAS_MIRROR and not limits.keywords:
        limits = replace(limits, keywords=("소상공인 정책자금", "소상공인정책자금"))
    if source_id == STORE_SOURCE and not limits.keywords:
        limits = replace(limits, keywords=DEFAULT_KEYWORDS)
    if (limits.keywords or limits.notice_ids) and source.adapter != "bizinfo":
        raise ValueError("Title searches require a Bizinfo listing source")
    partitions = ("N", "Y") if source.adapter == "bizinfo" else (None,)
    queries = tuple(product(limits.keywords or (None,), partitions))
    fetcher = (
        fetcher
        if fetcher is not None
        else OfficialFundingFetcher(
            source,
            max_requests=min(
                150,
                limits.notices * (3 if limits.documents else 1) + limits.pages * len(queries) + 6,
            ),
            max_seconds=limits.seconds,
        )
    )
    notices, errors, seen = [], [], set()
    seed_attempted = 0
    if source_id == STORE_SOURCE:
        reference_ids = [
            identity
            for identity in reviewed_notice_ids()
            if not limits.notice_ids or identity in limits.notice_ids
        ]
        for identity in reference_ids[: limits.notices]:
            seed_attempted += 1
            seen.add(identity)
            requested = DETAIL_BASE + identity
            try:
                page = fetcher.get(requested)
                if page.url != requested:
                    raise ValueError("Store reference redirect changed identity")
                notice = parse_reviewed_store_notice(
                    page.text, page.url, fetched_at=page.fetched_at
                )
                if limits.documents:
                    from apps.policy_funding.documents import enrich_notice_from_pdfs

                    notice, doc_errors = enrich_notice_from_pdfs(notice, fetcher)
                    errors.extend(f"document:{identity}:{error}" for error in doc_errors)
                notices.append(notice)
            except Exception as exc:
                errors.append(f"reference:{identity}:{type(exc).__name__}")
    discovery_budget = limits.notices - seed_attempted
    carry = 0
    for partition_index, (keyword, partition) in enumerate(queries):
        partition_budget = (
            discovery_budget // len(queries)
            + (1 if partition_index < discovery_budget % len(queries) else 0)
            + carry
        )
        carry = 0
        if not partition_budget:
            continue
        attempted = 0
        for page_number in range(1, limits.pages + 1):
            try:
                if source.adapter == "bizinfo":
                    params = {
                        "rows": "15",
                        "cpage": str(page_number),
                        "orderGb": "1",
                        "sort": "desc",
                        "schEndAt": partition,
                    }
                    if source_id in {"bizinfo_finance", SEMAS_MIRROR}:
                        params["hashCode"] = "01"
                    if keyword is not None:
                        params.update(
                            keyword=keyword,
                            condition="searchPblancNm",
                            condition1="AND",
                            rescan="N",
                        )
                    page = fetcher.get(
                        source.entry_url,
                        params=params,
                    )
                    links = parse_bizinfo_list(page.text, source_id=source_id)
                    row_count = len(_tree(page.text).css(".table_Type_1 tbody tr"))
                    total_pages = limits.pages if row_count >= 15 else page_number
                else:
                    page = fetcher.post(
                        "https://ols.semas.or.kr/ols/man/SMAN051M/search.do",
                        data={
                            "bltwtrClcd": "",
                            "bltwtrTitNm": "",
                            "searchStd": "1",
                            "pageNo": str(page_number),
                            "type": "2" if source_id == "semas_agency" else "1",
                        },
                    )
                    links, total_pages = parse_ols_list(json.loads(page.text))
            except OfficialSourceUnavailable:
                errors.append("upstream:semas_maintenance")
                return CollectionOutcome(
                    source_id,
                    tuple(notices),
                    "partial" if notices or len(errors) > 1 else "temporarily_unavailable",
                    tuple(errors),
                    fetcher.request_count,
                    True,
                )
            except Exception as exc:
                errors.append(
                    f"list:{keyword or 'all'}:{partition or 'all'}:"
                    f"{page_number}:{type(exc).__name__}"
                )
                break
            for link in links:
                if limits.notice_ids and link.external_id not in limits.notice_ids:
                    continue
                if link.external_id in seen:
                    continue
                if attempted >= partition_budget:
                    break
                seen.add(link.external_id)
                attempted += 1
                try:
                    detail = fetcher.get(link.official_url)
                    source.validate_url(detail.url)
                    requested, received = urlsplit(link.official_url), urlsplit(detail.url)
                    identity_key = "pblancId" if source.adapter == "bizinfo" else "bltwtrSeq"
                    if (
                        requested.hostname != received.hostname
                        or requested.path != received.path
                        or parse_qs(received.query).get(identity_key) != [link.external_id]
                        or source.adapter == "ols"
                        and parse_qs(received.query).get("bbsTypeCd") != ["01"]
                    ):
                        raise ValueError("Official detail redirect changed notice identity")
                    if source.adapter == "bizinfo":
                        notice = parse_bizinfo_detail(
                            detail.text,
                            link,
                            fetched_at=detail.fetched_at,
                            listing_state="open_list" if partition == "N" else "ended_list",
                            source_id=source_id,
                        )
                        if source_id == SEMAS_MIRROR and (
                            notice.issuer != "중소벤처기업부"
                            or not re.search(
                                r"(?:^|\n)사업수행기관:\s*소상공인시장진흥공단(?:\s|$)",
                                notice.evidence_text,
                            )
                        ):
                            continue
                    else:
                        notice = parse_ols_detail(
                            detail.text, link, source_id=source_id, fetched_at=detail.fetched_at
                        )
                    if limits.documents and source.adapter == "bizinfo":
                        from apps.policy_funding.documents import enrich_notice_from_pdfs

                        try:
                            notice, document_errors = enrich_notice_from_pdfs(notice, fetcher)
                            errors.extend(
                                f"document:{link.external_id}:{error}" for error in document_errors
                            )
                        except Exception as exc:
                            errors.append(f"document:{link.external_id}:{type(exc).__name__}")
                    notices.append(notice)
                except NotStoreRecipientNotice:
                    continue
                except Exception as exc:
                    errors.append(f"detail:{link.external_id}:{type(exc).__name__}")
            if page_number >= total_pages or attempted >= partition_budget:
                break
        carry = partition_budget - attempted
    status = "partial" if errors and notices else "failed" if errors else "completed"
    return CollectionOutcome(
        source_id, tuple(notices), status, tuple(errors), fetcher.request_count, True
    )


def collection_state(outcomes):
    """A successful mirror is degraded coverage; never call original boards recovered."""
    problems = [
        row for row in outcomes if row["status"] in {"partial", "failed", "temporarily_unavailable"}
    ]
    if not problems:
        return "completed"
    mirror_ok = any(
        row["source_id"] == SEMAS_MIRROR
        and row["status"] == "completed"
        and row["count"] > 0
        and not row["errors"]
        for row in outcomes
    )
    if mirror_ok and all(
        row["source_id"] in SEMAS_BOARDS
        and row["status"] == "temporarily_unavailable"
        and row["errors"] == ["upstream:semas_maintenance"]
        and row["count"] == 0
        for row in problems
    ):
        return "degraded"
    return "partial"
