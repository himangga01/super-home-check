from django.urls import path

from apps.policy_funding import views
from apps.policy_funding.grant_views import diagnosis
from wisdome_writer.notice_diagnosis import views as notice_diagnosis

urlpatterns = [
    path(
        "notice-diagnosis/",
        notice_diagnosis.picker,
        {"topic": "funding"},
        name="funding-diagnosis-picker",
    ),
    path(
        "notice-diagnosis/<str:identity>/",
        notice_diagnosis.detail,
        {"topic": "funding"},
        name="funding-notice-diagnosis",
    ),
    path("", views.index, name="policy-funding-index"),
    path("diagnosis/", diagnosis, name="policy-funding-diagnosis"),
    path("guide/", views.guide, name="policy-funding-guide"),
    path("glossary/", views.glossary, name="policy-funding-glossary"),
    path("history/", views.history, name="policy-funding-history"),
    path("sources/", views.sources, name="policy-funding-sources"),
    path("notices/<str:notice_id>/", views.detail, name="policy-funding-detail"),
    path("runs/<str:run_name>/", views.run_detail, name="policy-funding-run"),
]
