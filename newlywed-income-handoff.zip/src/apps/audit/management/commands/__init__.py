"""Audit application command implementations."""
