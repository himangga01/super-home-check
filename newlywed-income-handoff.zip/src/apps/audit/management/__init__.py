"""Audit application management commands."""
