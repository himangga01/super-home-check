"""Django business applications."""

