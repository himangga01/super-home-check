"""Collect article metadata that can reveal upcoming or overlooked housing calls."""

import json

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.local_content.housing_discovery import collect_housing_discovery


class Command(BaseCommand):
    help = "Collect bounded housing news candidates, separate from official notices."

    def add_arguments(self, parser):
        parser.add_argument("--days", type=int, default=30, choices=range(1, 31))
        parser.add_argument("--max-items", type=int, default=90, choices=range(1, 151))
        parser.add_argument("--max-seconds", type=int, default=120, choices=range(1, 301))
        parser.add_argument(
            "--housing-run", help="Existing validated official housing run for blog comparison."
        )

    def handle(self, *args, **options):
        if not settings.IS_LOCAL_RUNTIME:
            raise CommandError("housing discovery requires local runtime")
        try:
            report = collect_housing_discovery(
                settings.HOUSING_DISCOVERY_ROOT,
                days=options["days"],
                max_items=options["max_items"],
                max_seconds=options["max_seconds"],
                housing_run=options["housing_run"],
            )
        except (ValueError, OSError) as exc:
            raise CommandError("housing discovery could not complete") from exc
        self.stdout.write(json.dumps(report, ensure_ascii=False))
        if not report["complete"]:
            raise CommandError("housing news discovery is partial; inspect source outcomes")
