"""Collect official AI source metadata into the independent local archive."""

import json
import uuid
from collections import Counter

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from apps.ai_information.collector import collect_ai_information
from apps.ai_information.storage import read_run


class Command(BaseCommand):
    help = "Collect bounded official AI news, trend topics, issues and practical tips."

    def add_arguments(self, parser):
        parser.add_argument("--sources", nargs="+")
        parser.add_argument("--max-items", type=int, default=140)
        parser.add_argument("--seconds", type=int, default=180)
        parser.add_argument(
            "--diagnostics",
            action="store_true",
            help="Save bounded private source responses for parser diagnosis",
        )

    def handle(self, *args, **options):
        if not settings.IS_LOCAL_RUNTIME:
            raise CommandError("collect_ai_information requires local runtime")
        root = settings.AI_INFORMATION_ROOT
        diagnostic_root = (
            settings.LOCAL_STATE_ROOT / "ai-information-diagnostics" / uuid.uuid4().hex
            if options["diagnostics"]
            else None
        )
        try:
            path = collect_ai_information(
                root,
                source_ids=options["sources"],
                max_items=options["max_items"],
                max_seconds=options["seconds"],
                diagnostic_root=diagnostic_root,
            )
            run = read_run(root, path.name)
        except (ValueError, OSError) as exc:
            raise CommandError("AI collection failed: " + type(exc).__name__) from None
        partial = any(
            row["status"] in {"failed", "partial", "deferred"} for row in run["source_outcomes"]
        )
        self.stdout.write(
            json.dumps(
                {
                    "run_name": path.name,
                    "count": len(run["items"]),
                    "mode": run["mode"],
                    "collection_state": "partial" if partial else "completed",
                    "category_counts": dict(
                        Counter(c for item in run["items"] for c in item["categories"])
                    ),
                    "source_outcomes": run["source_outcomes"],
                    "coverage_limited": True,
                    "diagnostics": str(diagnostic_root) if diagnostic_root else None,
                },
                ensure_ascii=False,
                indent=2,
            )
        )
        if partial:
            raise CommandError("AI collection saved with partial coverage; inspect source outcomes")
