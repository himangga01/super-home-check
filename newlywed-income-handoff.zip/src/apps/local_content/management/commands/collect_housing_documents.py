"""Backfill official PDFs for a validated saved local housing run."""

import json

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from wisdome_writer.housing_documents.collection import collect_saved_run


class Command(BaseCommand):
    help = "Automatically collect and analyse official PDFs linked to saved housing notices."

    def add_arguments(self, parser):
        parser.add_argument("--run", required=True)
        parser.add_argument("--max-notices", type=int, default=20)
        parser.add_argument("--seconds", type=int, default=120)
        parser.add_argument("--notice-id", action="append", default=[])

    def handle(self, *args, **options):
        if not settings.IS_LOCAL_RUNTIME:
            raise CommandError("Official housing documents require local runtime")
        try:
            result = collect_saved_run(
                options["run"],
                max_notices=options["max_notices"],
                seconds=options["seconds"],
                identities=tuple(options["notice_id"]),
            )
        except (ValueError, OSError):
            raise CommandError("Saved housing run or document configuration is invalid") from None
        self.stdout.write(json.dumps(result, ensure_ascii=False, sort_keys=True))
