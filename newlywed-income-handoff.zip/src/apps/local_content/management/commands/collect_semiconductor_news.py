"""Compatibility entry point for the retired local semiconductor collector."""

from datetime import datetime

from django.conf import settings
from django.core.management.base import BaseCommand, CommandError

from wisdome_writer.portal.news_archive import SEOUL


class Command(BaseCommand):
    help = "Retired. Use collect_ai_information for the AI information workspace."

    def add_arguments(self, parser):
        now = datetime.now(SEOUL)
        parser.add_argument("--year", type=int, default=now.year)
        parser.add_argument("--month", type=int, default=now.month)
        parser.add_argument("--max-items", type=int, default=60)
        parser.add_argument("--seconds", type=int, default=180)

    def handle(self, *args, **options):
        if not settings.IS_LOCAL_RUNTIME:
            raise CommandError("collect_semiconductor_news requires local runtime")
        raise CommandError(
            "반도체 뉴스 수집은 종료되었습니다. collect_ai_information 명령을 사용하세요."
        )
