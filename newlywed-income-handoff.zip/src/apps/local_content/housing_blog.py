"""Bounded structured facts from Bureview RSS and validated ApplyHome documents."""

from __future__ import annotations

import io
import re
import unicodedata
from datetime import date, datetime, timedelta
from decimal import Decimal

import pdfplumber
from lxml import html
from lxml.etree import LxmlError
from pdfminer.pdfexceptions import PDFException

SOURCE_ID = "housing_breview"
STATUS = "블로그 분석 후보 · 공식 공고 대조 필요"
CONTENT = "{http://purl.org/rss/1.0/modules/content/}encoded"
POST = re.compile(
    r"^\d{1,2}\.\d{1,2}(?:\s*[-~]\s*(?:\d{1,2}\.)?\d{1,2})?\s+(줍줍|청약)!\s*(.+?)(?:\s+분양가\b|\s+청약일정\b|$)"
)
ROUNDUP = re.compile(r"^\d{1,2}월.{0,40}(?:청약|줍줍).{0,30}단지")
TYPE = re.compile(r"\d{2,3}[A-Z0-9-]*")
ADDRESS = re.compile(r"(\d{1,4})\s*동\s*(\d{1,4})\s*호")
PDF_AMOUNT = re.compile(r"\d{1,3}(?:,\d{3}){2,3}")
MONEY = r"(?:\d{1,5}(?:\.\d{1,5})?\s*억(?:\s*\d[\d,]{0,7}\s*만\s*원)?|\d[\d,]{0,14}\s*(?:만\s*)?원)"
PRICE = re.compile(
    rf"(?<!\w)(?P<unit>\d{{2,3}}[A-Z0-9-]*)\s*(?:㎡\s*)?(?:타입)?\s*\((?P<detail>[^)]{{1,80}})\)\s*[:：]\s*(?P<amount>{MONEY})(?:\s*\((?P<floor>\d{{1,2}}층)\))?"
)
CLAIM_DATE = re.compile(r"(?:(\d{4})\s*년\s*)?(?:(\d{1,2})\s*월\s*)?(\d{1,2})\s*일")
OFFICIAL_DATE = re.compile(r"(?<!\d)(\d{4})\.(\d{1,2})\.(\d{1,2})(?!\d)")
LABEL = re.compile(
    r"((?:최초\s*)?(?:입주자\s*)?모집공고일|청약접수|당첨자\s*발표일|계약일|"
    r"입주예정일|견본주택\s*오픈|최초\s*준공일)\s*[:：]"
)
TOPICS = (
    "역세권",
    "초등학교",
    "공원",
    "학원가",
    "리모델링",
    "후분양",
    "커뮤니티",
    "상권",
    "교통",
    "소음",
    "한강",
    "탄천",
    "입주권",
)
ALIASES = {
    "이천중리지구b3블록금성백조예미지": "이천역예미지센트럴파크",
    "고덕대광로제비앙모아엘가": "평택고덕국제신도시a55대광로제비앙모아엘가",
    "부천대장하우스토리디센트": "부천대장하우스토리디센트부천대장지구a2bl공공분양주택",
}


def _compact(value):
    return re.sub(r"[^0-9a-z가-힣]", "", unicodedata.normalize("NFKC", value).casefold())


def _name(value):
    return _compact(re.sub(r"\s*\(\d+차\)\s*$", "", value))


def _money(value):
    value = re.sub(r"[\s,]", "", value)
    if "억" in value:
        top, tail = value.split("억", 1)
        whole = Decimal(top) * 100_000_000
        if tail:
            return int(whole) + int(tail.removesuffix("만원")) * 10_000, 10_000
        return int(whole), max(
            1, int(Decimal(100_000_000).scaleb(Decimal(top).as_tuple().exponent))
        )
    return (
        (int(value.removesuffix("만원")) * 10_000, 10_000)
        if value.endswith("만원")
        else (int(value.removesuffix("원")), 1)
    )


def _address(value):
    match = ADDRESS.search(value)
    return f"{match[1]}동{match[2]}호" if match else None


def _sections(markup):
    sections = {}
    heading = ""
    tree = html.fragment_fromstring(markup, create_parent="div")
    for element in tree.xpath(".//h2|.//h3|.//h4|.//p|.//li[not(.//p)]"):
        text = " ".join(" ".join(element.itertext()).split())
        if element.tag.startswith("h"):
            heading = _compact(text)
        elif heading and text:
            sections.setdefault(heading, []).append(text)
    return sections


def _claim_dates(value, published):
    dates = []
    year, month = published.year, None
    for match in CLAIM_DATE.finditer(value):
        if match[1]:
            year = int(match[1])
        if match[2]:
            month = int(match[2])
            if not match[1] and month == 1 and published.month == 12:
                year = published.year + 1
        if month is not None:
            try:
                dates.append(date(year, month, int(match[3])).isoformat())
            except ValueError:
                return []
    return sorted(set(dates))


def _schedule(lines, published):
    text = " ".join(lines)
    labels = list(LABEL.finditer(text))
    result = {}
    for i, match in enumerate(labels):
        field = _compact(match[1])
        value = text[match.end() : labels[i + 1].start() if i + 1 < len(labels) else len(text)]
        dates = _claim_dates(value, published)
        if "모집공고" in field:
            # Bureview's historical 모집공고일 also appears without the word 최초.
            key = (
                "original_notice"
                if "최초" in field or (dates and dates[0] < published.replace(day=1).isoformat())
                else "notice"
            )
        else:
            key = {
                "청약접수": "application",
                "당첨자발표일": "winner",
                "계약일": "contract",
                "입주예정일": "occupancy",
                "견본주택오픈": "model_home",
                "최초준공일": "completion",
            }[field]
        if key == "occupancy" and not dates:
            month = re.search(r"(\d{4})\s*년\s*(\d{1,2})\s*월", value)
            if month and 1 <= int(month[2]) <= 12:
                result[key] = [f"{month[1]}-{int(month[2]):02d}"]
        if dates:
            result[key] = dates
        if key == "application":
            for part in re.split(r"[,/]", value):
                phase = (
                    "special" if "특별공급" in part else "general" if "일반공급" in part else None
                )
                if phase and dates:
                    # An omitted month in the second phase inherits the first phase's month.
                    parsed = _claim_dates(part, published) or _claim_dates(
                        f"{int(dates[0][5:7])}월 {part}", published
                    )
                    if parsed:
                        result[phase] = parsed
    return result


def _valuation(lines):
    text = " ".join(lines)
    result = {}
    for name, label in (
        ("asking_price_krw", "호가"),
        ("comparison_value_krw", "비교가치"),
        ("blog_comparison_supply_krw", "분양가"),
        ("reported_gap_krw", "안전마진"),
    ):
        match = re.search(rf"{label}\s*[:：]\s*({MONEY})", text)
        result[name] = _money(match[1])[0] if match else None
    gap = result["reported_gap_krw"]
    result["gap_status"] = (
        "reported_estimate"
        if gap is not None
        else "reported_none"
        if re.search(r"안전마진\s*[:：]\s*없음", text)
        else "not_reported"
    )
    units = re.findall(r"(?<!\d)(\d{2,3}[A-Z]*)\s*(?:㎡|타입)", text.split("분양가", 1)[0])
    result["comparison_unit"] = units[-1] if units else None
    return result


def extract_blog_claims(markup, published):
    sections = _sections(markup) if markup and len(markup) <= 256_000 else {}
    prices = []
    for line in sections.get("분양가및세대수", []):
        if re.match(r"^\W*참고", line):
            break
        for p in PRICE.finditer(line):
            amount, precision = _money(p["amount"])
            units = re.search(r"(\d{1,4})세대", p["detail"])
            prices.append(
                {
                    "unit": p["unit"],
                    "address": _address(p["detail"]),
                    "floor": p["floor"],
                    "amount_krw": amount,
                    "precision_krw": precision,
                    "reported_units": int(units[1]) if units else None,
                }
            )
    supply = " ".join(sections.get("공급규모", []))
    count_pattern = r"(?<![\d,])(\d{1,5}(?:,\d{3})?)\s*세대"
    supply_counts = [int(m.replace(",", "")) for m in re.findall(count_pattern, supply)][:8]
    current_count = re.findall(count_pattern + r"\s*(?:잔여공급|일반분양)", supply)
    analysis = " ".join(sections.get("분석", []))
    lending = " ".join(sections.get("대출조건", []))
    schedule = _schedule(sections.get("청약일정", []), published)
    occupancy = schedule.get("occupancy", [""])[0]
    return {
        "detail_status": "parsed" if sections else "unavailable",
        "schedule": schedule,
        "occupancy_month": occupancy[:7] or None,
        "reported_supply_counts": supply_counts,
        "reported_current_count": int(current_count[-1].replace(",", ""))
        if current_count
        else None,
        "prices": prices[:30],
        "valuation": _valuation(sections.get("비교단지", [])),
        "analysis_topics": [topic for topic in TOPICS if topic in analysis],
        "reported_lending_percentages": [
            int(m) for m in re.findall(r"(?<!\d)(\d{1,3})\s*%", lending)
        ][:10],
    }


def find_notice(project, category, dates, notices):
    names = {_name(project)}
    names.update(ALIASES[n] for n in tuple(names) if n in ALIASES)
    explicit_round = re.search(r"\((\d+)차\)\s*$", project)
    matches = []
    for row in notices:
        if (
            row["source_key"] != "applyhome"
            or row["category"] != category
            or _name(row["title"]) not in names
        ):
            continue
        if explicit_round and f"({explicit_round[1]}차)" not in row["title"]:
            continue
        official = {row.get("application_start"), row.get("application_end")}
        for label, text in row.get("facts", []):
            if any(stage in label for stage in ("특별공급", "1순위", "일반공급")):
                official.update(re.findall(r"\d{4}-\d{2}-\d{2}", text))
        if official.intersection(dates):
            matches.append(row)
    return matches[0] if len(matches) == 1 else None


def _schedule_key(label):
    if "모집공고일" in label:
        return "original_notice" if "최초" in label else "notice"
    if "특별공급" in label:
        return "special"
    if "1순위" in label:
        return "first"
    if "2순위" in label:
        return "second"
    if "일반공급" in label and "접수" in label:
        return "general"
    if "청약접수" in label:
        return "application"
    if "당첨자발표" in label:
        return "winner"
    if "계약체결" in label:
        return "contract"
    return None


def _floor_bounds(value):
    match = re.fullmatch(r"(\d{1,2})(?:[-~～](\d{1,2}))?층(이상)?", re.sub(r"\s+", "", value))
    if match:
        lower = int(match[1])
        return lower, (max(100, lower) if match[3] else int(match[2] or lower))
    return None


def _pdf_amount(cell):
    cell = (cell or "").strip()
    if cell in {"-", "0"}:
        return 0
    return int(cell.replace(",", "")) if PDF_AMOUNT.fullmatch(cell) else None


def _pdf_address(row, headers):
    for label in ("동호수", "동호"):
        if label in headers:
            value = (row[headers.index(label)] or "").strip()
            return _address(value) if ADDRESS.fullmatch(value) else None
    if "동" in headers and "호" in headers:
        dong, ho = ((row[headers.index(label)] or "").strip() for label in ("동", "호"))
        if re.fullmatch(r"\d{1,4}동?", dong) and re.fullmatch(r"\d{1,4}호?", ho):
            return f"{dong.removesuffix('동')}동{ho.removesuffix('호')}호"
    return None


def official_table_facts(tables):
    schedule, prices = {}, []
    for raw in tables:
        cells = [[_compact(c or "") for c in row] for row in raw[:3]]
        if len(raw) >= 2 and "일정" in cells[1] and any("당첨자발표" in c for c in cells[0]):
            for label, value in zip(cells[0], raw[1], strict=False):
                key = _schedule_key(label)
                dates = [date(*map(int, m)).isoformat() for m in OFFICIAL_DATE.findall(value or "")]
                if key and dates:
                    schedule.setdefault(key, sorted(set(dates)))
        if len(cells) < 2 or not {"대지비", "건축비"}.issubset(cells[1]):
            continue
        indices = [i for i, c in enumerate(cells[1]) if c in {"계", "합계", "세대별분양가"}]
        unit_indices = [i for i, c in enumerate(cells[0]) if c.startswith("약식표기")]
        if len(indices) != 1 or len(unit_indices) != 1:
            continue
        total_index, unit_index = indices[0], unit_indices[0]
        component_indices = [
            i
            for i, label in enumerate(cells[1][:total_index])
            if label in {"대지비", "건축비", "부가세", "부가가치세", "재분양비"}
        ]
        if len(component_indices) < 2:
            continue
        unit = None
        for row in raw[2:]:
            if len(row) <= max(total_index, unit_index):
                continue
            name = (row[unit_index] or "").strip()
            if TYPE.fullmatch(name):
                unit = name
            address = _pdf_address(row[:total_index], cells[0][:total_index])
            amount = _pdf_amount(row[total_index])
            components = [_pdf_amount(row[i]) for i in component_indices]
            if (
                (unit or address)
                and amount
                and None not in components
                and sum(components) == amount
            ):
                prices.append(
                    {
                        "unit": unit,
                        "address": address,
                        "floor": next(
                            (c for c in row[:total_index] if c and _floor_bounds(c)), None
                        ),
                        "amount_krw": amount,
                    }
                )
    return {"schedule": schedule, "prices": prices}


def _matches_unit(claim, official):
    # Exact dong/ho is sufficient when the table's unit cell cannot be extracted.
    if claim["address"]:
        return claim["address"] == official["address"] and official["unit"] in {None, claim["unit"]}
    return claim["unit"] == official["unit"]


def compare_prices(claims, official):
    result = []
    for claim in claims:
        rows = [row for row in official if _matches_unit(claim, row)]
        floor = _floor_bounds(claim["floor"] or "")
        if floor and not claim["address"]:
            eligible = [
                row
                for row in rows
                if (limits := _floor_bounds(row["floor"] or ""))
                and limits[0] <= floor[0] <= limits[1]
            ]
            if not eligible and any(row["floor"] is None for row in rows):
                result.append(
                    {
                        "claim": claim,
                        "status": "floor_unavailable",
                        "official_amounts_krw": [],
                        "basis": None,
                        "matched_unit_type": False,
                    }
                )
                continue
            rows = eligible
        amounts = sorted({row["amount_krw"] for row in rows})
        amount = claim["amount_krw"]
        matches = [value for value in amounts if abs(value - amount) * 2 <= claim["precision_krw"]]
        if not amounts:
            status = "unit_unmatched" if official else "price_unavailable"
        elif amount in amounts:
            status = "match"
        elif matches:
            status = "rounded_match"
        else:
            status = "different"
        matching_type = bool(rows) and all(row["unit"] == claim["unit"] for row in rows)
        basis = None
        if rows:
            if claim["address"]:
                basis = "type_and_address" if matching_type else "address_only"
            else:
                basis = "type_and_floor" if floor else "type"
        result.append(
            {
                "claim": claim,
                "status": status,
                "official_amounts_krw": amounts,
                "basis": basis,
                "matched_unit_type": matching_type,
            }
        )
    return result


def _pdf_facts(payload):
    with pdfplumber.open(io.BytesIO(payload)) as document:
        tables = []
        for page in document.pages[:10]:
            text = _compact(page.extract_text() or "")
            if "당첨자발표" in text or ("대지비" in text and "건축비" in text):
                tables.extend(page.extract_tables())
        return official_table_facts(tables)


def _official_rows(run):
    from django.conf import settings

    from apps.local_content.bundles import BundleValidationError, _parse_strict_json_object
    from apps.local_content.views import _parse_run_name
    from wisdome_writer.portal.housing import (
        HOUSING_JSON_MAX_NODES,
        _project_document,
        _ReadOnlyBundleWriter,
        _run_candidates,
    )

    day = _parse_run_name(run) if run else None
    if day is None:
        return [], {}
    writer = _ReadOnlyBundleWriter(settings.LOCAL_ARTICLE_ROOT)

    def read(name, run_day):
        payload = writer.read_validated_run_file(run_day, "notices.json", run_directory=name)
        doc = _parse_strict_json_object(
            payload, "housing blog comparison", max_nodes=HOUSING_JSON_MAX_NODES
        )
        captured, _, _ = _project_document(doc, run_day)
        return captured, doc["notices"]

    cutoff, current = read(run, day)
    candidates = sorted(
        _run_candidates(settings.LOCAL_ARTICLE_ROOT), key=lambda r: r[1], reverse=True
    )
    history = []
    for name, run_day in candidates:
        if name == run or not day - timedelta(days=30) <= run_day <= day:
            continue
        if len(history) >= 24:
            break
        try:
            observed, rows = read(name, run_day)
        except (BundleValidationError, ValueError, OSError):
            continue
        if observed <= cutoff:
            history.append((observed, name, rows))
    history.sort(key=lambda r: r[0], reverse=True)
    rows, origins = [], {}
    for _, name, batch in [(cutoff, run, current), *history]:
        for row in batch:
            identity = row["external_id"]
            if row["source_key"] == "applyhome" and identity not in origins:
                origins[identity] = name
                if row.get("status") == "published":
                    rows.append(row)
    return rows, origins


def _reconcile(row, claims, run):
    from apps.policy_funding.contracts import content_hash
    from wisdome_writer.housing_documents.storage import document_root, read_document
    from wisdome_writer.notice_diagnosis.sources import notice_id

    selected = {
        "raw": row,
        "id": notice_id(row["source_key"], row["external_id"]),
        "base_digest": content_hash(row),
    }
    original, original_status = None, "pdf_not_cached"
    try:
        original = read_document(document_root(), selected, include_pdf=True)
        if original:
            original_status = "pdf_checked"
            parsed = _pdf_facts(original["primary_pdf"])
        else:
            parsed = {"schedule": {}, "prices": []}
    except (ValueError, OSError, RuntimeError, PDFException):
        parsed = {"schedule": {}, "prices": []}
        original_status = "pdf_unavailable"
    official_dates = parsed["schedule"]
    official_dates.setdefault("notice", [row["published_at"][:10]])
    dates = set(official_dates.get("application", []))
    for phase in ("special", "general", "first", "second"):
        dates.update(official_dates.get(phase, []))
    if dates:
        official_dates["application"] = sorted(dates)
    comparison = {}
    for key, values in claims["schedule"].items():
        official = official_dates.get(key, [])
        if key == "application" and not official:
            observed = sorted(
                {v for v in (row.get("application_start"), row.get("application_end")) if v}
            )
            comparison[key] = {
                "status": "listing_bounds_only" if observed else "unavailable",
                "official_dates": observed,
            }
            continue
        status = (
            "match"
            if official == values
            else "partial"
            if set(values) < set(official)
            else "different"
            if official
            else "unavailable"
        )
        comparison[key] = {"status": status, "official_dates": official}
    official_count = row.get("supply_count")
    breakdown = [price["reported_units"] for price in claims["prices"]]
    claimed_counts = {
        "overview": claims["reported_current_count"],
        "price_breakdown": sum(breakdown) if breakdown and all(breakdown) else None,
    }
    supply_comparison = {
        key: "unavailable"
        if value is None or official_count is None
        else "match"
        if value == official_count
        else "different"
        for key, value in claimed_counts.items()
    }
    return {
        "run": run,
        "external_id": row["external_id"],
        "url": row["canonical_url"],
        "source_status": original_status,
        "listed_supply_count": official_count,
        "supply_comparison": supply_comparison,
        "official_dates": official_dates,
        "schedule_comparison": comparison,
        "price_comparison": compare_prices(claims["prices"], parsed["prices"]),
        "pdf": {key: original["documents"][0][key] for key in ("url", "sha256")}
        if original
        else None,
    }


def build_reviews(items, markup_by_url, run):
    from apps.local_content.bundles import BundleValidationError
    from apps.local_content.dates import SEOUL

    blog_items = [item for item in items if item["source_id"] == SOURCE_ID]
    if not blog_items:
        return []
    try:
        official, origins = _official_rows(run)
    except (BundleValidationError, OSError, ValueError):
        official, origins = [], {}
    reviews = []
    for item in blog_items:
        parsed = POST.match(item["title"])
        published = datetime.fromisoformat(item["published_at"]).astimezone(SEOUL).date()
        if not parsed:
            claims = extract_blog_claims("", published)
            claims["detail_status"] = "multi_project"
            reviews.append(
                {"url": item["url"], "project": item["title"], "claims": claims, "official": None}
            )
            continue
        try:
            claims = extract_blog_claims(markup_by_url.get(item["url"], ""), published)
        except (ValueError, LxmlError, OverflowError):
            claims = extract_blog_claims("", published)
        project = parsed[2].strip()
        category = "remaining" if parsed[1] == "줍줍" else "apt"
        row = find_notice(project, category, claims["schedule"].get("application", []), official)
        source = _reconcile(row, claims, origins[row["external_id"]]) if row else None
        reviews.append(
            {"url": item["url"], "project": project, "claims": claims, "official": source}
        )
    return reviews
