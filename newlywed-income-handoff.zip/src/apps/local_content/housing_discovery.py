"""Article-assisted housing discovery, isolated from official notice snapshots."""

from __future__ import annotations

import hashlib
import json
import re
import uuid
from collections import Counter
from datetime import UTC, date, datetime, timedelta
from itertools import islice
from urllib.parse import quote

from defusedxml import ElementTree
from defusedxml.common import DefusedXmlException
from django.conf import settings

from apps.ai_information.catalog import validate_url
from apps.ai_information.feeds import plain_text, publication
from apps.ai_information.transport import FeedFetcher
from apps.local_content.bundles import ArticleBundleWriter, _parse_strict_json_object
from apps.local_content.dates import SEOUL
from apps.local_content.housing_blog import CONTENT as BLOG_CONTENT
from apps.local_content.housing_blog import POST as BLOG_POST
from apps.local_content.housing_blog import ROUNDUP as BLOG_ROUNDUP
from apps.local_content.housing_blog import SOURCE_ID as BLOG_SOURCE_ID
from apps.local_content.housing_blog import STATUS as BLOG_STATUS
from apps.local_content.housing_blog import build_reviews
from wisdome_writer.infrastructure.http_safety import HttpSafetyError
from wisdome_writer.portal.news_archive import (
    ExclusiveLock,
    RequestBudget,
    _ReadOnlyWriter,
    _safe_root,
)

RUN = re.compile(r"(\d{4}-\d{2}-\d{2})(?:--run-[a-f0-9]{12})?")
ITEM_KEYS = {"title", "url", "publisher", "published_at", "source_id", "status"}
STATUS = "기사 기반 후보 · 공식 공고 확인 필요"
ADVANCE_STATUS = "지자체 사전안내 · 최종 모집공고 확인 필요"
SOURCE_HOSTS = {
    "news.seoul.go.kr",
    "newsroom.hdec.kr",
    "the-h-banpo124.com",
    "m.newsis.com",
    "www.newsis.com",
    "www.applyhome.co.kr",
    "static.applyhome.co.kr",
    "www.wikitree.co.kr",
    "raemian.co.kr",
    "www.raemian.co.kr",
    "www.lottecastle.co.kr",
    "www.fnnews.com",
    "breview.co.kr",
    "www.fsc.go.kr",
}


def _encoded(value):
    return json.dumps(value, ensure_ascii=False, sort_keys=True, allow_nan=False).encode()


def _digest(value):
    return hashlib.sha256(_encoded(value)).hexdigest()


def _text(value, maximum=500):
    if not isinstance(value, str) or not 1 <= len(value) <= maximum:
        raise ValueError("invalid_discovery_text")
    if any(ord(c) < 32 for c in value):
        raise ValueError("invalid_discovery_text")
    return value


def _aware(value):
    parsed = datetime.fromisoformat(_text(value, 40))
    if parsed.tzinfo is None or parsed.utcoffset() is None:
        raise ValueError("invalid_discovery_timestamp")
    return parsed


def _publication_key(row):
    return _aware(row["published_at"]) if row["published_at"] else datetime.min.replace(tzinfo=UTC)


def load_projects():
    """Reviewed research, with original verification dates rather than a live claim."""
    path = settings.REPOSITORY_ROOT / "config/housing-discovery/projects.json"
    data = _parse_strict_json_object(path.read_bytes(), "housing research")
    if set(data) != {"schema_version", "projects"} or data["schema_version"] != 1:
        raise ValueError("invalid_housing_research")
    projects = data["projects"]
    if not isinstance(projects, list) or not 1 <= len(projects) <= 8:
        raise ValueError("invalid_housing_projects")
    seen = set()
    for project in projects:
        if set(project) != {
            "slug",
            "title",
            "aliases",
            "region",
            "checked_on",
            "summary",
            "facts",
            "schedule",
            "sources",
            "unit_counts",
            "notice_match",
        }:
            raise ValueError("invalid_housing_project_fields")
        slug = _text(project["slug"], 60)
        if not re.fullmatch(r"[a-z0-9]+(?:-[a-z0-9]+)*", slug) or slug in seen:
            raise ValueError("invalid_housing_project_slug")
        seen.add(slug)
        for field in ("title", "region", "summary"):
            _text(project[field])
        date.fromisoformat(project["checked_on"])
        notice_match = project["notice_match"]
        if (
            not isinstance(notice_match, dict)
            or set(notice_match) != {"category", "published_from"}
            or not isinstance(notice_match["category"], str)
            or notice_match["category"] not in {"apt", "remaining"}
        ):
            raise ValueError("invalid_housing_notice_match")
        date.fromisoformat(_text(notice_match["published_from"], 10))
        aliases = project["aliases"]
        if not isinstance(aliases, list) or not 1 <= len(aliases) <= 5:
            raise ValueError("invalid_housing_aliases")
        for alias in aliases:
            _text(alias, 100)
        sources = project["sources"]
        if not isinstance(sources, list) or not 1 <= len(sources) <= 10:
            raise ValueError("invalid_housing_references")
        source_ids = set()
        for source in sources:
            if set(source) != {"id", "title", "url", "kind"}:
                raise ValueError("invalid_housing_reference")
            if source["id"] in source_ids:
                raise ValueError("duplicate_housing_reference")
            source_ids.add(_text(source["id"], 40))
            _text(source["title"], 150)
            if source["kind"] not in {"official", "media"}:
                raise ValueError("invalid_housing_reference_kind")
            validate_url(source["url"], hosts=SOURCE_HOSTS)
        for field in ("facts", "schedule"):
            if not isinstance(project[field], list) or not 1 <= len(project[field]) <= 30:
                raise ValueError("invalid_housing_facts")
            for fact in project[field]:
                expected = {"label", "text", "status", "sources"}
                if field == "schedule":
                    expected.add("date")
                if set(fact) != expected:
                    raise ValueError("invalid_housing_fact")
                _text(fact["label"], 80)
                _text(fact["text"], 700)
                if fact["status"] not in {
                    "공식 발표",
                    "공식 예정",
                    "언론 보도·확인 필요",
                    "미공개",
                    "별도 절차",
                    "확인 필요",
                    "공식 자료·과거 이력",
                }:
                    raise ValueError("invalid_housing_fact_status")
                if not isinstance(fact["sources"], list) or not fact["sources"]:
                    raise ValueError("missing_housing_evidence")
                if not set(fact["sources"]) <= source_ids:
                    raise ValueError("unknown_housing_evidence")
                if field == "schedule":
                    if fact["date"] is None:
                        if fact["status"] != "확인 필요":
                            raise ValueError("unknown_date_requires_verification_status")
                    else:
                        date.fromisoformat(_text(fact["date"], 10))
        units = project["unit_counts"]
        if not isinstance(units, list) or len(units) > 20:
            raise ValueError("invalid_housing_units")
        for row in units:
            if set(row) != {"area", "count"}:
                raise ValueError("invalid_housing_unit")
            _text(row["area"], 20)
            if type(row["count"]) is not int or row["count"] <= 0:
                raise ValueError("invalid_housing_unit_count")
    return projects


def discovery_sources():
    profiles = [
        (
            "housing_hankyung",
            "한국경제",
            "https://www.hankyung.com/feed/realestate",
            ["www.hankyung.com"],
            ["/article/"],
        ),
        (
            "housing_mk",
            "매일경제",
            "https://www.mk.co.kr/rss/50300009/",
            ["www.mk.co.kr"],
            ["/news/"],
        ),
        (
            "housing_fnnews",
            "파이낸셜뉴스",
            "https://www.fnnews.com/rss/r20/fn_realnews_realestate.xml",
            ["www.fnnews.com"],
            ["/news/"],
        ),
        (BLOG_SOURCE_ID, "부리남", "https://breview.co.kr/feed/", ["breview.co.kr"], ["/"]),
    ]
    news_sources = [
        {
            "source_id": key,
            "name": name + " 부동산 RSS",
            "publisher": name,
            "entry_url": url,
            "article_hosts": hosts,
            "article_paths": paths,
            "enabled": key != "housing_mk",
            "access_note": (
                "2026-11-17 robots 조회 HTTP403으로 자동 수집 중지; 재검토 전 요청하지 않음"
                if key == "housing_mk"
                else "공개 RSS에서 개별 공고 주장과 수치만 추출; 본문·이미지는 저장하지 않음"
                if key == BLOG_SOURCE_ID
                else "언론사 공개 RSS 제목·출처·링크만 저장; 기사 본문은 저장하지 않음"
            ),
            "poll_seconds": 900,
            "date_precision": "instant",
            "rights_status": "internal_metadata",
        }
        for key, name, url, hosts, paths in profiles
    ]
    # Published by Seoul on its tag page as the official RSS alternate link.
    # Several bounded pages include notices published before the final ApplyHome call.
    seoul_feed = (
        "https://news.seoul.go.kr/welfare/archives/tag/"
        + quote("장애인-특별공급").lower()
        + "/feed"
    )
    return news_sources + [
        {
            "source_id": f"housing_seoul_special_{page}",
            "name": f"서울시 특별공급 사전안내 RSS {page}페이지",
            "publisher": "서울특별시",
            "entry_url": seoul_feed + (f"?paged={page}" if page > 1 else ""),
            "article_hosts": ["news.seoul.go.kr"],
            "article_paths": ["/welfare/archives/"],
            "enabled": True,
            "access_note": "기관추천·일정변경 제목과 출처만 수집; 추천자명단·본문은 수집하지 않음",
            "poll_seconds": 900,
            "date_precision": "instant",
            "rights_status": "internal_metadata",
        }
        for page in range(1, 5)
    ]


def _source_status(source):
    if source["source_id"] == BLOG_SOURCE_ID:
        return BLOG_STATUS
    return ADVANCE_STATUS if source["publisher"] == "서울특별시" else STATUS


def parse_candidates(payload, source_id, *, captured_at, days=30, blog_markup=None):
    source = next((s for s in discovery_sources() if s["source_id"] == source_id), None)
    if source is None:
        raise ValueError("unknown_discovery_source")
    if len(payload) > 4 * 1024 * 1024:
        raise ValueError("discovery_feed_too_large")
    try:
        root = ElementTree.fromstring(payload)
    except (ElementTree.ParseError, DefusedXmlException) as exc:
        raise ValueError("discovery_feed_invalid") from exc
    if root.tag != "rss":
        raise ValueError("discovery_feed_not_rss")
    entries = root.findall("./channel/item")
    if len(entries) > 2000:
        raise ValueError("discovery_feed_item_limit")
    aliases = [re.sub(r"\s+", "", a) for p in load_projects() for a in p["aliases"]]
    rows, rejected = [], 0
    for entry in entries:
        title = plain_text(entry.findtext("title", ""), 350)
        compact = re.sub(r"\s+", "", title)
        relevant = (
            bool(re.search(r"청약|분양|아파트|주택", title))
            and bool(re.search(r"로또|시세차익|줍줍|무순위|계약취소", compact))
        ) or bool(re.search(r"분양|특별공급|일반공급|입주자모집공고|잔여세대|재공급", compact))
        relevant = relevant or any(a in compact for a in aliases)
        if re.search(r"상가|지식산업센터|호텔|물류센터|오피스빌딩", compact) and not (
            re.search(r"아파트|주택", compact) or any(a in compact for a in aliases)
        ):
            relevant = False
        if source["publisher"] == "서울특별시":
            relevant = "특별공급" in compact and "명단" not in compact
        if source_id == BLOG_SOURCE_ID:
            relevant = bool(BLOG_POST.match(title) or BLOG_ROUNDUP.match(title))
        if not title or not relevant:
            continue
        try:
            url = validate_url(
                entry.findtext("link", "").strip(),
                hosts=source["article_hosts"],
                paths=source["article_paths"],
            )
            published = publication(entry.findtext("pubDate", ""), "instant")
            if source_id == BLOG_SOURCE_ID and published is None:
                rejected += 1
                continue
            if published is not None:
                instant = _aware(published)
                if instant > captured_at or instant < captured_at - timedelta(days=days):
                    continue
            rows.append(
                {
                    "title": title,
                    "url": url,
                    "publisher": source["publisher"],
                    "published_at": published,
                    "source_id": source_id,
                    "status": _source_status(source),
                }
            )
            if source_id == BLOG_SOURCE_ID and blog_markup is not None:
                blog_markup.setdefault(url, entry.findtext(BLOG_CONTENT, ""))
        except (ValueError, TypeError):
            rejected += 1
    return rows, rejected


def _validate_record(row, *, sources, captured, days):
    if not isinstance(row, dict) or set(row) != ITEM_KEYS:
        raise ValueError("invalid_discovery_record")
    _text(row["title"], 350)
    _text(row["publisher"], 120)
    if not isinstance(row["source_id"], str) or row["source_id"] not in sources:
        raise ValueError("invalid_discovery_origin")
    source = sources[row["source_id"]]
    if row["status"] != _source_status(source):
        raise ValueError("invalid_discovery_evidence_status")
    if not source["enabled"]:
        raise ValueError("disabled_discovery_source_record")
    validate_url(row["url"], hosts=source["article_hosts"], paths=source["article_paths"])
    if row["publisher"] != source["publisher"]:
        raise ValueError("discovery_publisher_mismatch")
    if row["published_at"] is not None:
        instant = _aware(row["published_at"])
        if instant > captured or instant < captured - timedelta(days=days):
            raise ValueError("invalid_discovery_date")


def collect_housing_discovery(
    root,
    *,
    days=30,
    max_items=90,
    max_seconds=120,
    fetcher_factory=None,
    now=None,
    housing_run=None,
):
    if not settings.IS_LOCAL_RUNTIME:
        raise ValueError("housing_discovery_requires_local_runtime")
    if type(days) is not int or not 1 <= days <= 30:
        raise ValueError("invalid_discovery_days")
    if type(max_items) is not int or not 1 <= max_items <= 150:
        raise ValueError("invalid_discovery_item_limit")
    if type(max_seconds) is not int or not 1 <= max_seconds <= 300:
        raise ValueError("invalid_discovery_time_limit")
    fixture = fetcher_factory is not None
    if now is not None and not fixture:
        raise ValueError("live_discovery_time_cannot_be_overridden")
    captured = now or datetime.now(UTC)
    _aware(captured.isoformat())
    sources = discovery_sources()
    factory = fetcher_factory or FeedFetcher
    budget = RequestBudget(30, max_seconds)
    root = _safe_root(root, create=True)
    rows, seen, outcomes = [], set(), []
    blog_markup = {}
    per_source = max(1, max_items // max(1, sum(s["enabled"] for s in sources)))
    with ExclusiveLock(root / ".collection.lock"):
        for source in sources:
            fetcher = None
            outcome = {
                "source_id": source["source_id"],
                "status": "completed",
                "count": 0,
                "requests": 0,
                "error_code": None,
            }
            if not source["enabled"]:
                outcome["status"] = "disabled"
                outcomes.append(outcome)
                continue
            try:
                budget.remaining()
                fetcher = factory(
                    source,
                    state_root=settings.LOCAL_STATE_ROOT / "housing-discovery-http",
                    budget=budget,
                )
                candidates, rejected = parse_candidates(
                    fetcher.get(),
                    source["source_id"],
                    captured_at=captured,
                    days=days,
                    blog_markup=blog_markup,
                )
                candidates.sort(key=_publication_key, reverse=True)
                for row in candidates:
                    if len(rows) >= max_items:
                        break
                    if row["url"] not in seen and outcome["count"] < per_source:
                        rows.append(row)
                        seen.add(row["url"])
                        outcome["count"] += 1
                if rejected:
                    outcome.update(status="partial", error_code="invalid_feed_records")
            except (ValueError, OSError, RuntimeError, HttpSafetyError) as exc:
                code = getattr(exc, "code", str(exc))
                code = (
                    code
                    if isinstance(code, str) and re.fullmatch(r"[a-z0-9_]{1,100}", code)
                    else "discovery_source_failed"
                )
                outcome.update(status="failed", error_code=code)
            finally:
                if fetcher is not None:
                    outcome["requests"] = fetcher.request_count
                    fetcher.close()
            outcomes.append(outcome)
        rows.sort(key=_publication_key, reverse=True)
        blog_reviews = build_reviews(rows, blog_markup, housing_run)
        writer = ArticleBundleWriter(root)
        day = captured.astimezone(SEOUL).date()
        lease = writer.reserve_run_directory(day, workflow_id=uuid.uuid4().hex)
        records = {
            "schema_version": 2,
            "topic": "housing_discovery",
            "mode": "fixture" if fixture else "live",
            "run_name": lease.name,
            "captured_at": captured.isoformat(),
            "days": days,
            "sources": sources,
            "items": rows,
            "outcomes": outcomes,
            "coverage_limited": True,
            "blog_reviews": blog_reviews,
        }
        path = writer.write_run(
            day,
            "# Housing news discovery\n\nArticle candidates, not official notices.\n",
            run_directory=lease,
            run_files={
                "notices.json": _encoded(records),
                "raw-observations.json": _encoded({"records_hash": _digest(records)}),
            },
        )
    return {
        "run_name": lease.name,
        "run_path": str(path),
        "count": len(rows),
        "complete": all(o["status"] in {"completed", "disabled"} for o in outcomes),
        "outcomes": outcomes,
        "coverage_limited": True,
        "blog_count": len(blog_reviews),
        "blog_official_matches": sum(review["official"] is not None for review in blog_reviews),
    }


def read_discovery_run(root, name):
    if not isinstance(name, str):
        raise ValueError("invalid_discovery_run_name")
    match = RUN.fullmatch(name)
    if match is None:
        raise ValueError("invalid_discovery_run_name")
    day = date.fromisoformat(match[1])
    writer = _ReadOnlyWriter(root)
    doc = _parse_strict_json_object(
        writer.read_validated_run_file(day, "notices.json", run_directory=name), "housing news"
    )
    obs = _parse_strict_json_object(
        writer.read_validated_run_file(day, "raw-observations.json", run_directory=name),
        "housing news evidence",
    )
    version = doc.get("schema_version")
    keys = {
        "schema_version",
        "topic",
        "mode",
        "run_name",
        "captured_at",
        "days",
        "sources",
        "items",
        "outcomes",
        "coverage_limited",
    }
    if version == 2:
        keys.add("blog_reviews")
    if set(doc) != keys:
        raise ValueError("invalid_discovery_schema")
    if (
        type(doc["schema_version"]) is not int
        or version not in {1, 2}
        or doc["topic"] != "housing_discovery"
        or not isinstance(doc["mode"], str)
        or doc["mode"] not in {"live", "fixture"}
        or doc["run_name"] != name
        or doc["coverage_limited"] is not True
        or set(obs) != {"records_hash"}
        or obs["records_hash"] != _digest(doc)
    ):
        raise ValueError("invalid_discovery_identity")
    captured = _aware(doc["captured_at"])
    if (
        captured.astimezone(SEOUL).date() != day
        or type(doc["days"]) is not int
        or not 1 <= doc["days"] <= 30
    ):
        raise ValueError("invalid_discovery_window")
    from apps.ai_information.catalog import validate_catalog

    sources = {s["source_id"]: s for s in validate_catalog(doc["sources"])}
    if not isinstance(doc["items"], list) or len(doc["items"]) > 150:
        raise ValueError("invalid_discovery_records")
    seen = set()
    for row in doc["items"]:
        _validate_record(row, sources=sources, captured=captured, days=doc["days"])
        if row["url"] in seen:
            raise ValueError("duplicate_discovery_record")
        seen.add(row["url"])
    if version == 2:
        reviews = doc["blog_reviews"]
        expected = {r["url"] for r in doc["items"] if r["source_id"] == BLOG_SOURCE_ID}
        if not isinstance(reviews, list) or len(reviews) != len(expected):
            raise ValueError("invalid_blog_review_count")
        for review in reviews:
            if (
                not isinstance(review, dict)
                or set(review) != {"url", "project", "claims", "official"}
                or not isinstance(review["url"], str)
                or review["url"] not in expected
                or not isinstance(review["claims"], dict)
                or (review["official"] is not None and not isinstance(review["official"], dict))
            ):
                raise ValueError("invalid_blog_review")
            _text(review["project"], 350)
            expected.remove(review["url"])
    if not isinstance(doc["outcomes"], list) or len(doc["outcomes"]) != len(sources):
        raise ValueError("invalid_discovery_outcomes")
    reported = set()
    counts = Counter(row["source_id"] for row in doc["items"])
    for outcome in doc["outcomes"]:
        if (
            not isinstance(outcome, dict)
            or set(outcome) != {"source_id", "status", "count", "requests", "error_code"}
            or not isinstance(outcome["source_id"], str)
            or outcome["source_id"] not in sources
            or outcome["source_id"] in reported
            or not isinstance(outcome["status"], str)
            or outcome["status"] not in {"completed", "partial", "failed", "disabled"}
        ):
            raise ValueError("invalid_discovery_outcome")
        reported.add(outcome["source_id"])
        if any(
            type(outcome[k]) is not int or not 0 <= outcome[k] <= 150 for k in ("count", "requests")
        ):
            raise ValueError("invalid_discovery_counts")
        if outcome["count"] != counts[outcome["source_id"]]:
            raise ValueError("discovery_count_mismatch")
        if outcome["error_code"] is not None and (
            not isinstance(outcome["error_code"], str)
            or not re.fullmatch(r"[a-z0-9_]{1,100}", outcome["error_code"])
        ):
            raise ValueError("invalid_discovery_error")
    return doc


def load_discovery_inventory(root, *, query=""):
    if not isinstance(query, str) or len(query) > 200:
        raise ValueError("invalid_discovery_query")
    result = {
        "items": [],
        "captured_at": None,
        "outcomes": [],
        "message": "아직 수집된 기사 후보가 없습니다.",
        "available": True,
    }
    if not root.exists():
        return result
    try:
        root = _safe_root(root)
        entries = list(islice(root.iterdir(), 513))
        if len(entries) > 512:
            raise ValueError("discovery_history_bound")
        names = sorted([p.name for p in entries if RUN.fullmatch(p.name)], reverse=True)[:128]
        docs = [read_discovery_run(root, name) for name in names]
        docs = [d for d in docs if d["mode"] == "live"]
        docs.sort(key=lambda d: _aware(d["captured_at"]), reverse=True)
        if not docs:
            return result
        latest = docs[0]
        seen = set()
        rows = []
        cutoff = datetime.now(UTC) - timedelta(days=30)
        for doc in docs:
            if _aware(doc["captured_at"]) < cutoff:
                continue
            for row in doc["items"]:
                if row["url"] in seen:
                    continue
                seen.add(row["url"])
                if row["published_at"] is not None and _aware(row["published_at"]) < cutoff:
                    continue
                if query.casefold() not in (row["title"] + " " + row["publisher"]).casefold():
                    continue
                rows.append(row)
        rows.sort(key=_publication_key, reverse=True)
        result.update(
            items=rows[:150],
            captured_at=latest["captured_at"],
            outcomes=latest["outcomes"],
            message="기사·지자체 사전안내에서 찾은 후보입니다. 게시일과 청약 접수일은 다릅니다.",
        )
        if any(o["status"] not in {"completed", "disabled"} for o in latest["outcomes"]):
            result["message"] = (
                "최근 기사 수집이 일부 완료되지 않았습니다. 마지막 확인 자료를 함께 표시합니다."
            )
    except (ValueError, OSError):
        result.update(available=False, message="저장된 기사 수집 기록을 검증할 수 없습니다.")
    return result
