"""Replaceable external-system adapters."""

