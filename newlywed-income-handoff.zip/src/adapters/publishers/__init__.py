"""Official publisher API adapters."""

