"""Build the offline calculator from the same assets as the housing portal."""
import base64
from pathlib import Path

root = Path(__file__).resolve().parents[1]
assets = root / "src/static/income"
out = root / "docs/reference/housing-knowledge/tools/newlywed-income.html"
out.parent.mkdir(parents=True, exist_ok=True)
read = lambda name: (assets / name).read_text(encoding="utf-8-sig")
def blob(name):
    data = base64.b64encode((assets / name).read_bytes()).decode()
    return f"URL.createObjectURL(new Blob([Uint8Array.from(atob('{data}'),c=>c.charCodeAt(0))],{{type:'text/javascript'}}))"
js = read("calculator.mjs").replace("import {profiles,compare} from './rules.mjs';", read("rules.mjs").replace("export ", ""))
js = js.replace("()=>import('./vendor/pdf.min.mjs')", "()=>import(libURL)").replace("new URL('./vendor/pdf.worker.min.mjs',import.meta.url).href",blob("vendor/pdf.worker.min.mjs"))
js = "const libURL="+blob("vendor/pdf.min.mjs")+";\n"+js
page = read("index.html").replace("script-src 'self'", "script-src 'unsafe-inline' blob:").replace("connect-src 'self'", "connect-src blob:").replace('<script type="module" src="./calculator.mjs"></script>', '<script type="module">'+js+'</script>')
out.write_text(page,encoding="utf8")
