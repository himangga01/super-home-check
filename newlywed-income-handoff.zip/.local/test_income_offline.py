from pathlib import Path
import tempfile
import fitz
from playwright.sync_api import sync_playwright, expect

root=Path(__file__).resolve().parents[1]
url=(root/'docs/reference/housing-knowledge/tools/newlywed-income.html').as_uri()
with tempfile.TemporaryDirectory() as tmp, sync_playwright() as pw:
    receipt=Path(tmp)/'synthetic.pdf'
    with fitz.open() as doc:
        pg=doc.new_page()
        pg.insert_text((50,70),'21 총급여 72,000,000',fontname='korea')
        doc.save(receipt)
    b=pw.chromium.launch(channel='chrome',headless=True)
    p=b.new_page();errors=[];requests=[]
    p.on('pageerror',lambda e:errors.append(str(e)))
    p.on('request',lambda r:requests.append(r.url.split(':')[0]))
    p.add_init_script("window.origDigest=crypto.subtle.digest.bind(crypto.subtle);crypto.subtle.digest=async(...a)=>{let v=await window.origDigest(...a);console.log(Array.from(new Uint8Array(v),x=>x.toString(16).padStart(2,'0')).join(''));return v}");p.on("console",lambda x:print(x.text[:150]));p.goto(url);p.locator('.amount').wait_for()
    for prefix,expected in [('fdfba','잠실 소득 범위'),('d539','일반 단계 소득 범위'),('823ef','추첨 단계 소득 범위')]:
        p.locator('#notice').set_input_files(next((root/'output/housing-documents').glob(prefix+'*/**/document-1.pdf')))
        expect(p.locator("#noticeStatus")).to_contain_text("검증된")
        p.locator('#dual').check()
        if prefix!='823ef':
            p.locator('.pdf').first.set_input_files(receipt)
            expect(p.locator(".msg").first).not_to_be_empty()
            print('receipt:',p.locator('.msg').first.inner_text(),p.locator('.amount').first.input_value())
            assert p.locator('.amount').first.input_value()=='72000000',errors
            p.locator('.amount').nth(1).fill('60000000')
            for m in p.locator('.months').all():m.fill('12')
        else:
            for x,v in zip(p.locator('.amount').all(),['6000000','5000000']):x.fill(v)
        p.locator('#confirm').check();p.locator('#calc').click()
        print(p.locator('output').inner_text())
        assert expected in p.locator('output').inner_text()
    p.locator('#notice').set_input_files(receipt)
    expect(p.locator("#noticeStatus")).to_contain_text("미등록")
    assert p.locator('#manual').is_visible()
    assert not errors,errors
    assert not {'http','https'}&set(requests),requests
    b.close()
